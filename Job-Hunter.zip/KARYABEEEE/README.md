# KARYABEEEE - Autonomous Job Application Engine

KARYABEEEE is a production-grade, fully autonomous job application engine designed as a real, observable system (not a toy script). It continuously discovers, evaluates, and applies to high-signal roles on behalf of a candidate using a modular, cloud-native architecture.

Key capabilities:

- Continuous scraping of curated job platforms
- Semantic and rule-based scoring of roles
- ATS-optimized resume generation per opportunity
- Hyper-personalized cover letter generation
- Automated, Playwright-based form completion and submission
- Multi-profile/account management
- Follow-up scheduling, tracking, and analytics
- Metrics, logs, and dashboards for full observability

This repository is built to be:

- Modular: clear separation of scraping, intelligence, application, orchestration, monitoring
- Observable: health checks, Prometheus metrics, Grafana dashboards, structured logs
- Secure: environment-based configuration, no hard-coded secrets, least-privilege friendly
- Extensible: easy to add job boards, heuristics, models, channels, and strategies
- Deployment-ready: Docker + Docker Compose; portable to CI/CD, cloud, and Kubernetes

---

## Table of Contents

- [Architecture Overview](#architecture-overview)
- [Stack & Services](#stack--services)
- [Project Layout](#project-layout)
- [Quick Start (Docker-First)](#quick-start-docker-first)
- [Environment Configuration](#environment-configuration)
- [Running Components](#running-components)
- [Health, Monitoring & Observability](#health-monitoring--observability)
- [Development Workflow](#development-workflow)
- [Security Notes](#security-notes)
- [Roadmap / Status](#roadmap--status)
- [License](#license)

---

## Architecture Overview

At a high level, KARYABEEEE is composed of the following logical layers:

1. Scraping Engine
   - Structured scrapers for job platforms (e.g. JobVision, IranTalent, LinkedIn, etc.).
   - Uses HTTP clients and/or headless browsers.
   - Anti-detection patterns, realistic headers/agents, optional proxy integration.

2. Intelligence Core
   - Leverages Gemini (`google-generativeai`) and classical ML (LightGBM, scikit-learn).
   - Computes relevance scores, identifies gaps, and filters out low-signal roles.
   - Generates tailored profiles and narratives.

3. Application Engine
   - Automates job application forms using Playwright-based flows.
   - Generates and attaches per-role resumes and cover letters.

4. Profile & Account Management
   - Supports multiple identities/profiles, each with its own constraints and preferences.

5. Persistence & State
   - PostgreSQL as the main data store for jobs, applications, events, analytics.
   - Redis for caching, rate limiting, and fast transient state.

6. Orchestration
   - Celery workers execute async workloads (scrape, match, apply, notify).
   - Celery beat runs scheduled workflows and maintenance jobs.

7. Control Plane & API
   - FastAPI application exposing:
     - Health endpoints
     - Internal/admin endpoints
     - Hooks for bots and dashboards

8. Observability
   - Prometheus scraping metrics from the app.
   - Grafana dashboards over Prometheus.
   - Structured JSON logs ready for ELK/Sentry-style pipelines.

For a deeper architectural breakdown, see [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

---

## Stack & Services

Defined in [`docker-compose.yml`](docker-compose.yml):

- `app`
  - FastAPI application (`karyabee.api.main:app`)
  - Exposed on `:8000`
  - Includes health checks and metrics support

- `celery_worker`
  - Runs Celery workers using `karyabee.orchestration.celery_app.celery_app`
  - Handles scraping, scoring, document generation, and application tasks

- `celery_beat`
  - Celery beat scheduler for periodic tasks:
    - Scheduled scraping
    - Re-scoring, follow-ups
    - System health checks

- `db`
  - PostgreSQL 15
  - Config via environment variables

- `redis`
  - Redis 7
  - Used for caching / support functionality

- `rabbitmq`
  - Message broker for Celery (with management UI on `:15672`)

- `prometheus`
  - Scrapes metrics from the app
  - Configured via [`monitoring/prometheus/prometheus.yml`](monitoring/prometheus/prometheus.yml)

- `grafana`
  - Grafana dashboards on `:3001`
  - Auto-provisioning ready via [`monitoring/grafana/provisioning`](monitoring/grafana/provisioning)

- `nginx`
  - Reverse-proxy on `:80`
  - Proxies traffic to `app:8000` using [`nginx/nginx.conf`](nginx/nginx.conf) / `default.conf`

All services are attached to `karyabee_net` for clean internal networking.

---

## Project Layout

Key elements of the repository:

- [`docker-compose.yml`](docker-compose.yml)
  - Full multi-service stack definition.

- [`Dockerfile`](Dockerfile)
  - Single, production-focused Python 3.11-slim base image.
  - Supports:
    - FastAPI app
    - Celery worker/beat
    - Scraping/automation code
  - Runs as non-root user.

- [`requirements.txt`](requirements.txt)
  - Pinned runtime dependencies:
    - FastAPI, Uvicorn
    - SQLAlchemy, Alembic, psycopg2-binary
    - Celery, Redis client
    - httpx, BeautifulSoup, lxml, fake-useragent
    - Playwright
    - google-generativeai, LightGBM, scikit-learn, NumPy, pandas
    - prometheus-client, structlog, sentry-sdk
    - telegram bot, email utilities
    - pytest, mypy, etc.

- [`setup.sh`](setup.sh)
  - Opinionated bootstrap script:
    - Ensures directory structure
    - Ensures `__init__.py` files
    - Verifies presence of critical modules
    - Checks for `env/.env`
    - Creates baseline Nginx and Prometheus configs if missing
    - Rebuilds and starts docker-compose stack

Core Python package (indicative, may evolve):

- [`karyabee/__init__.py`](karyabee/__init__.py)
- [`karyabee/config.py`](karyabee/config.py)
- [`karyabee/db.py`](karyabee/db.py)
- [`karyabee/logging_config.py`](karyabee/logging_config.py)
- [`karyabee/metrics.py`](karyabee/metrics.py)
- [`karyabee/models.py`](karyabee/models.py)
- [`karyabee/schemas.py`](karyabee/schemas.py)

AI & intelligence:

- `karyabee/ai/gemini_client.py`
- `karyabee/ai/matching.py`
- `karyabee/ai/resume_builder.py`
- `karyabee/ai/cover_letter.py`
- `karyabee/ai/interview_predictor.py`

Scraping:

- `karyabee/scrapers/base.py`
- `karyabee/scrapers/jobvision.py`
- `karyabee/scrapers/irantalent.py`
- `karyabee/scrapers/linkedin.py`
- Additional scrapers can be plugged in with a common interface.

Application engine:

- `karyabee/applier/base.py`
- `karyabee/applier/playwright_engine.py`

Orchestration:

- `karyabee/orchestration/celery_app.py`
- `karyabee/orchestration/tasks.py`

Interfaces & monitoring:

- `karyabee/api/main.py`
- `karyabee/bot/telegram_bot.py`
- `karyabee/monitoring/health.py`
- `karyabee/monitoring/prometheus_exporter.py`

Testing and docs (if present):

- `tests/`
- `docs/ARCHITECTURE.md`
- `docs/DEPLOYMENT.md`
- `docs/OPERATIONS.md`

---

## Quick Start (Docker-First)

Recommended path for trying this project.

Prerequisites:

- Docker
- Docker Compose v2
- Valid configuration in `env/.env`

Steps:

1. Prepare environment:

   - Create `env/` directory if it does not exist.
   - Add `env/.env` based on your secrets and infra.
     (If you have an `env/.env.example`, copy and adapt it.)

2. Build and start the full stack:

   ```bash
   docker-compose up -d --build
   ```

3. Wait for services to become healthy, then verify:

   - API Health:
     - `GET http://localhost:8000/api/health`
   - Nginx (if enabled):
     - `http://localhost/`
   - RabbitMQ Management:
     - `http://localhost:15672` (default `guest/guest` unless overridden)
   - Prometheus:
     - `http://localhost:9090`
   - Grafana:
     - `http://localhost:3001`
   - PostgreSQL:
     - exposed on `localhost:5433` for local access

4. (Optional) Use the helper script for a complete bootstrap:

   ```bash
   chmod +x setup.sh
   ./setup.sh
   ```

---

## Environment Configuration

Configuration is loaded via environment variables (12-factor style). Common variables (names may vary depending on your local version):

- Core:
  - `APP_ENV` / `ENV`
  - `LOG_LEVEL`
- Database:
  - `POSTGRES_DB`
  - `POSTGRES_USER`
  - `POSTGRES_PASSWORD`
  - `POSTGRES_HOST`
  - `POSTGRES_PORT`
- Broker / Cache:
  - `RABBITMQ_DEFAULT_USER`
  - `RABBITMQ_DEFAULT_PASS`
  - `REDIS_URL` (if used by code)
- AI / External Services:
  - `GEMINI_API_KEY` (or equivalent)
  - Keys/tokens for any other integrated API
- Bot / Notifications:
  - `TELEGRAM_BOT_TOKEN`
  - `TELEGRAM_CHAT_ID` / control channel IDs
- Scraping / Anti-detection:
  - Proxy URLs, rate-limit configs, etc.

Secrets must NOT be committed. Keep all sensitive values in `env/.env` or your deployment secret store.

---

## Running Components

Inside the Compose stack:

- App service:

  ```bash
  docker-compose logs -f app
  ```

- Celery worker:

  ```bash
  docker-compose logs -f celery_worker
  ```

- Celery beat:

  ```bash
  docker-compose logs -f celery_beat
  ```

To restart:

```bash
docker-compose restart app celery_worker celery_beat
```

To tear down everything (including volumes):

```bash
docker-compose down -v
```

---

## Health, Monitoring & Observability

- Health:
  - `GET /api/health` on the app.
- OpenAPI / Docs (if exposed):
  - `GET /api/docs` on the app.
- Metrics:
  - Exposed via `karyabee.metrics` and scraped by Prometheus.
- Dashboards:
  - Configure Grafana to use Prometheus (`karyabee_prometheus`) as data source.
  - Add dashboards for:
    - Job discovery rate
    - Application rate
    - Success/failure per board
    - Task queue latency and failures
    - Error rates (app + workers)

Logs:

- All containers log to stdout and can be tailed via `docker-compose logs`.
- The `logs/` directory is mounted from the app/worker for persistent logs.

---

## Development Workflow

For local development without full stack (optional, advanced):

1. Create and activate a virtual environment.
2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Ensure local Postgres, Redis, RabbitMQ or adjust config to point to your running stack.
4. Run the FastAPI app:

   ```bash
   uvicorn karyabee.api.main:app --reload --host 0.0.0.0 --port 8000
   ```

5. Run Celery worker:

   ```bash
   celery -A karyabee.orchestration.celery_app.celery_app worker --loglevel=INFO
   ```

6. Run Celery beat:

   ```bash
   celery -A karyabee.orchestration.celery_app.celery_app beat --loglevel=INFO
   ```

Align logging, metrics, and config with the Docker setup for parity between dev and prod.

---

## Security Notes

- No secrets in the repository.
- All credentials must come from environment variables / secret managers.
- Avoid logging PII or highly sensitive payloads.
- If you integrate real accounts for auto-apply:
  - Use dedicated accounts and explicit consent.
  - Respect platform ToS.
  - Implement limits and controls to avoid abusive behavior.

---

## Roadmap / Status

Initial phase goals:

- [x] Containerized, reproducible stack (Docker + Compose)
- [x] Core configuration, logging, metrics wiring
- [x] Database + basic models
- [x] Core scrapers bootstrapped
- [x] Celery-based orchestration skeleton
- [ ] Full auto-apply flows with robust fallbacks
- [ ] Rich Grafana dashboards & alerts
- [ ] Advanced scoring, A/B testing, interview predictor
- [ ] Extended analytics & reporting

---

## License

Specify your chosen license in a `LICENSE` file (e.g. MIT/Apache-2.0) to clarify usage and contributions.
