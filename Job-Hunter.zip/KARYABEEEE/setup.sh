#!/bin/bash
set -euo pipefail

echo "🚀 Setting up KARYABEEEE..."

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

cd "$ROOT_DIR"

echo "📁 Creating directory structure..."
mkdir -p \
  karyabee/ai \
  karyabee/api \
  karyabee/applier \
  karyabee/bot \
  karyabee/monitoring \
  karyabee/orchestration \
  karyabee/scrapers \
  karyabee/utils \
  logs \
  data \
  env \
  monitoring/prometheus \
  nginx

echo "📝 Ensuring __init__.py files..."
touch \
  karyabee/__init__.py \
  karyabee/ai/__init__.py \
  karyabee/api/__init__.py \
  karyabee/applier/__init__.py \
  karyabee/bot/__init__.py \
  karyabee/monitoring/__init__.py \
  karyabee/orchestration/__init__.py \
  karyabee/scrapers/__init__.py \
  karyabee/utils/__init__.py

echo "🧩 Verifying core Python modules..."
REQUIRED_FILES=(
  "karyabee/config.py"
  "karyabee/db.py"
  "karyabee/logging_config.py"
  "karyabee/metrics.py"
  "karyabee/models.py"
  "karyabee/schemas.py"
  "karyabee/api/main.py"
  "karyabee/orchestration/celery_app.py"
  "karyabee/orchestration/tasks.py"
  "karyabee/utils/cache.py"
  "karyabee/utils/rate_limiter.py"
  "karyabee/utils/validators.py"
)
for f in "${REQUIRED_FILES[@]}"; do
  if [ ! -f "$f" ]; then
    echo "❌ Missing required file: $f"
    MISSING=1
  fi
done
if [ "${MISSING:-0}" -eq 1 ]; then
  echo "❌ One or more required files are missing. Please fix before running Docker."
  exit 1
fi

echo "🔐 Checking env/.env..."
if [ ! -f "env/.env" ]; then
  echo "❌ ERROR: env/.env not found."
  echo "Create it from env/.env.example and fill required secrets."
  exit 1
fi

echo "🌐 Ensuring nginx config..."
if [ ! -d "nginx/nginx.conf" ] && [ ! -f "nginx/nginx.conf/default.conf" ]; then
  mkdir -p nginx
  cat > nginx/nginx.conf <<'EOF'
events {
    worker_connections 1024;
}

http {
    upstream karyabee_app {
        server app:8000;
    }

    server {
        listen 80;
        server_name _;
        client_max_body_size 10M;

        location / {
            proxy_pass http://karyabee_app;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }

        location /api/health {
            proxy_pass http://karyabee_app/api/health;
            access_log off;
        }
    }
}
EOF
fi

echo "📊 Ensuring Prometheus config placeholder..."
if [ ! -f "monitoring/prometheus/prometheus.yml" ]; then
  cat > monitoring/prometheus/prometheus.yml <<'EOF'
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: "karyabee_app"
    static_configs:
      - targets: ["app:8000"]
  - job_name: "karyabee_celery_worker"
    static_configs:
      - targets: ["app:8000"]
EOF
fi

echo "🧹 Cleaning existing Docker stack (if any)..."
docker-compose down -v 2>/dev/null || true

echo "🏗️ Building and starting services..."
docker-compose up -d --build

echo "⏳ Waiting for services to warm up..."
sleep 25

echo "✅ Current service status:"
docker-compose ps

echo ""
echo "🎉 Setup complete."
echo "Endpoints:"
echo "  - API:           http://localhost:8000"
echo "  - API Docs:      http://localhost:8000/api/docs"
echo "  - Health:        http://localhost:8000/api/health"
echo "  - RabbitMQ:      http://localhost:15672 (guest/guest)"
echo "  - Grafana:       http://localhost:3001"
echo "  - Prometheus:    http://localhost:9090"
echo ""
echo "Logs:"
echo "  - docker-compose logs -f app"
echo "  - docker-compose logs -f celery_worker"
echo "  - docker-compose logs -f celery_beat"
echo ""
echo "Stop all:"
echo "  - docker-compose down"