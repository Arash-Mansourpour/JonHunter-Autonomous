"""
Pydantic schemas for KARYABEEEE.

Covers:
- Job
- Application
- Analytics
- FollowUp
- Shared responses and filters
"""

from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, EmailStr, Field, HttpUrl, field_validator

from karyabee.utils.validators import (
    is_valid_phone,
    validate_salary_range,
    sanitize_text,
)


# ---------------------------------------------------------------------------
# Base helpers
# ---------------------------------------------------------------------------


class ORMBaseModel(BaseModel):
    """Base model configured for ORM mode and sensible JSON."""

    class Config:
        from_attributes = True
        populate_by_name = True
        str_strip_whitespace = True


# ---------------------------------------------------------------------------
# Job Schemas
# ---------------------------------------------------------------------------


class JobBase(ORMBaseModel):
    """Common fields for job entities."""

    title: str = Field(..., max_length=255)
    company: str = Field(..., max_length=255)
    location: Optional[str] = Field(None, max_length=255)
    salary_min: Optional[int] = Field(None, ge=0)
    salary_max: Optional[int] = Field(None, ge=0)
    currency: Optional[str] = Field(None, max_length=10)
    description: Optional[str] = None
    requirements: Optional[Dict[str, Any]] = None
    tech_stack: Optional[List[str]] = None
    benefits: Optional[List[str]] = None
    company_size: Optional[str] = Field(None, max_length=50)
    posted_date: Optional[date] = None
    application_url: Optional[HttpUrl] = None
    source: Optional[str] = Field(None, max_length=50)

    @field_validator("description")
    @classmethod
    def _sanitize_description(cls, v: Optional[str]) -> Optional[str]:
        return sanitize_text(v) if v is not None else v

    @field_validator("salary_max")
    @classmethod
    def _validate_salary_range(cls, v: Optional[int], info) -> Optional[int]:
        values = info.data
        salary_min = values.get("salary_min")
        if not validate_salary_range(salary_min, v):
            raise ValueError("Invalid salary range")
        return v


class JobCreate(JobBase):
    """Schema for creating a Job from scraper or admin."""
    pass


class JobUpdate(ORMBaseModel):
    """Partial update for Job."""

    match_score: Optional[float] = Field(None, ge=0, le=100)
    skill_gaps: Optional[Dict[str, Any]] = None
    apply_decision: Optional[bool] = None
    status: Optional[str] = Field(None, max_length=50)


class JobResponse(JobBase):
    """Job response schema."""

    id: uuid.UUID
    created_at: datetime
    updated_at: datetime
    scraped_at: datetime
    match_score: Optional[float] = None
    skill_gaps: Optional[Dict[str, Any]] = None
    apply_decision: Optional[bool] = None
    status: str


class JobListResponse(ORMBaseModel):
    """Paginated list of jobs."""

    total: int
    page: int
    page_size: int
    items: List[JobResponse]


# ---------------------------------------------------------------------------
# Application Schemas
# ---------------------------------------------------------------------------


class ApplicationBase(ORMBaseModel):
    """Base application fields."""

    job_id: uuid.UUID
    resume_version: Optional[str] = None
    cover_letter: Optional[str] = None
    account_used: Optional[str] = None
    confirmation_number: Optional[str] = None
    screenshot_path: Optional[str] = None

    @field_validator("cover_letter")
    @classmethod
    def _sanitize_cover_letter(cls, v: Optional[str]) -> Optional[str]:
        return sanitize_text(v) if v is not None else v


class ApplicationCreate(ApplicationBase):
    """Create application schema."""
    pass


class ApplicationUpdate(ORMBaseModel):
    """Update application status/response."""

    response_received: Optional[bool] = None
    response_date: Optional[datetime] = None
    response_type: Optional[str] = None
    interview_scheduled: Optional[bool] = None
    interview_date: Optional[datetime] = None
    outcome: Optional[str] = None
    notes: Optional[str] = None

    @field_validator("notes")
    @classmethod
    def _sanitize_notes(cls, v: Optional[str]) -> Optional[str]:
        return sanitize_text(v) if v is not None else v


class ApplicationResponse(ApplicationBase):
    """Application response schema."""

    id: uuid.UUID
    created_at: datetime
    updated_at: datetime
    applied_at: datetime
    response_received: bool
    response_date: Optional[datetime]
    response_type: Optional[str]
    interview_scheduled: bool
    interview_date: Optional[datetime]
    outcome: str
    notes: Optional[str]


class ApplicationListResponse(ORMBaseModel):
    """Paginated list of applications."""

    total: int
    page: int
    page_size: int
    items: List[ApplicationResponse]


# ---------------------------------------------------------------------------
# Analytics Schemas
# ---------------------------------------------------------------------------


class AnalyticsBase(ORMBaseModel):
    """Base analytics fields."""

    date: date
    jobs_scraped: int = 0
    applications_sent: int = 0
    responses_received: int = 0
    interviews_scheduled: int = 0
    offers_received: int = 0
    rejection_rate: Optional[float] = None
    avg_response_time_hours: Optional[float] = None
    top_skills_demanded: Optional[Dict[str, Any]] = None
    top_companies_hiring: Optional[Dict[str, Any]] = None
    avg_salary_offered: Optional[int] = None
    success_rate_by_platform: Optional[Dict[str, Any]] = None


class AnalyticsResponse(AnalyticsBase):
    """Analytics response schema."""

    id: uuid.UUID
    created_at: datetime
    updated_at: datetime


class AnalyticsListResponse(ORMBaseModel):
    """List of analytics records."""

    items: List[AnalyticsResponse]


# ---------------------------------------------------------------------------
# Follow-up Schemas
# ---------------------------------------------------------------------------


class FollowUpBase(ORMBaseModel):
    """Base follow-up fields."""

    application_id: uuid.UUID
    scheduled_for: Optional[datetime] = None
    sent_at: Optional[datetime] = None
    message: Optional[str] = None
    response_received: bool = False

    @field_validator("message")
    @classmethod
    def _sanitize_message(cls, v: Optional[str]) -> Optional[str]:
        return sanitize_text(v) if v is not None else v


class FollowUpCreate(FollowUpBase):
    """Create follow-up schema."""
    pass


class FollowUpResponse(FollowUpBase):
    """Follow-up response schema."""

    id: uuid.UUID
    created_at: datetime
    updated_at: datetime


# ---------------------------------------------------------------------------
# Filters / Misc
# ---------------------------------------------------------------------------


class JobsFilter(ORMBaseModel):
    """Query params for listing jobs."""

    status: Optional[str] = None
    match_score_min: Optional[float] = Field(None, ge=0, le=100)
    source: Optional[str] = None
    page: int = Field(1, ge=1)
    page_size: int = Field(20, ge=1, le=200)
    sort_by: Optional[str] = Field(
        None, description="Field to sort by, e.g., 'match_score', 'posted_date'"
    )
    sort_order: Optional[str] = Field(
        None, description="asc or desc", pattern="^(asc|desc)$"
    )


class ApplicationsFilter(ORMBaseModel):
    """Query params for listing applications."""

    outcome: Optional[str] = None
    date_from: Optional[date] = None
    date_to: Optional[date] = None
    page: int = Field(1, ge=1)
    page_size: int = Field(20, ge=1, le=200)


class AnalyticsRange(ORMBaseModel):
    """Date range query for analytics."""

    period: str = Field(
        "daily",
        description="Aggregation level: daily|weekly|monthly",
        pattern="^(daily|weekly|monthly)$",
    )
    start_date: Optional[date] = None
    end_date: Optional[date] = None


# ---------------------------------------------------------------------------
# Admin / Settings schemas (for /api/admin endpoints, Telegram bot)
# ---------------------------------------------------------------------------


class SystemSettingsUpdate(ORMBaseModel):
    """
    Runtime-tunable settings exposed via admin API or Telegram bot.

    Only safe/high-level knobs; underlying secure config remains in env.
    """

    match_threshold: Optional[int] = Field(
        None, ge=0, le=100, description="Minimum match_score to auto-apply"
    )
    apply_limit: Optional[int] = Field(
        None, ge=1, le=500, description="Max auto applications per cycle"
    )
    follow_up_delay_days: Optional[int] = Field(
        None, ge=1, le=60, description="Days before follow-up is sent"
    )
    paused_until: Optional[datetime] = Field(
        None, description="If set, automation paused until this timestamp"
    )


class SystemStats(ORMBaseModel):
    """High-level system stats for /api/stats, /stats bot cmd."""

    jobs_scraped_today: int
    applications_sent_today: int
    responses_today: int
    interviews_today: int
    offers_today: int
    total_jobs: int
    total_applications: int
    total_offers: int
    response_rate: float
    interview_rate: float
    offer_rate: float