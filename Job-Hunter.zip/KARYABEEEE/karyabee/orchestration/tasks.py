"""
Celery task definitions for KARYABEEEE.

Implements scheduled and on-demand tasks:

- scrape_all_sources:
    Parallel scraping of all job sources.
    - Uses dedicated queues via Celery routing.
    - Stores new jobs into DB.
- match_and_score_jobs:
    Compute match scores for pending/unscored jobs.
- auto_apply_top_matches:
    Select top jobs (score >= threshold) and auto-apply (limit 25).
- check_responses:
    Placeholder IMAP-based inbox scanner for responses.
- send_follow_ups:
    Send follow-up emails for stale applications.
- generate_daily_report:
    Compose and send HTML report (email + Telegram).
- weekly_deep_analysis:
    7-day trends and model/strategy diagnostics.
- system_health_check:
    Check DB/Redis/Gemini/worker health, emit alerts.

All tasks:
- Use robust logging with context.
- Avoid leaking PII (respect logging_config sanitization).
- Are testable via dependency injection of sessions/services.
"""

from __future__ import annotations

import datetime as dt
import imaplib
import email
from email.header import decode_header
from typing import List, Optional, Tuple

from celery import group
from celery.schedules import crontab
from sqlalchemy import and_, func, select
from sqlalchemy.orm import Session

from karyabee.ai.matching import calculate_match_score
from karyabee.ai.resume_builder import generate_resumes
from karyabee.ai.cover_letter import (
    CoverLetterContext,
    generate_cover_letter,
)
from karyabee.ai.interview_predictor import (
    InterviewFeatures,
    interview_predictor,
)
from karyabee.applier.account_manager import get_account_manager
from karyabee.applier.playwright_engine import playwright_applier
from karyabee.config import settings
from karyabee.db import SessionLocal
from karyabee.logging_config import get_logger
from karyabee.metrics import inc_jobs_scraped, inc_applications_sent
from karyabee.models import Analytics, Application, FollowUp, Job
from karyabee.notifications.email_sender import EmailSender
from karyabee.notifications.telegram_notifier import TelegramNotifier
from karyabee.orchestration.celery_app import celery_app
from karyabee.scrapers.irantalent import scrape_irantalent
from karyabee.scrapers.jobvision import scrape_jobvision
from karyabee.scrapers.linkedin import scrape_linkedin
from karyabee.scrapers.quera import scrape_quera

logger = get_logger(__name__)

email_sender = EmailSender()
telegram_notifier = TelegramNotifier()


# ---------------------------------------------------------------------------
# Helper context manager
# ---------------------------------------------------------------------------


def _db_session() -> Session:
    """Return a new SQLAlchemy session."""
    return SessionLocal()


# ---------------------------------------------------------------------------
# Scraping tasks
# ---------------------------------------------------------------------------


@celery_app.task(name="karyabee.orchestration.tasks.scrape_source")
def scrape_source_task(source: str) -> int:
    """
    Scrape a single source and persist jobs.

    Args:
        source: One of ("jobvision", "irantalent", "linkedin", "quera").

    Returns:
        Number of jobs stored.
    """
    db = _db_session()
    stored = 0
    try:
        if source == "jobvision":
            jobs = scrape_jobvision()
        elif source == "irantalent":
            jobs = scrape_irantalent()
        elif source == "linkedin":
            jobs = scrape_linkedin()
        elif source == "quera":
            jobs = scrape_quera()
        else:
            logger.error("scrape_source_unknown", source=source)
            return 0

        for j in jobs:
            # Upsert by application_url
            if not j.get("application_url"):
                continue
            existing = db.execute(
                select(Job).where(Job.application_url == j["application_url"])
            ).scalar_one_or_none()
            if existing:
                continue
            job = Job(
                title=j["title"],
                company=j["company"],
                location=j.get("location"),
                salary_min=j.get("salary_min"),
                salary_max=j.get("salary_max"),
                currency=j.get("currency"),
                description=j.get("description"),
                requirements=j.get("requirements"),
                posted_date=j.get("posted_date"),
                application_url=j["application_url"],
                source=source,
                status="pending",
            )
            db.add(job)
            stored += 1

        db.commit()
        inc_jobs_scraped(source, stored)
        logger.info(
            "scrape_source_completed",
            source=source,
            stored=stored,
        )
        return stored
    except Exception as exc:
        db.rollback()
        logger.error(
            "scrape_source_failed",
            source=source,
            error=str(exc),
        )
        return 0
    finally:
        db.close()


@celery_app.task(name="karyabee.orchestration.tasks.scrape_all_sources")
def scrape_all_sources() -> None:
    """
    Scrape all configured sources in parallel using Celery groups.

    Scheduled:
        0 */4 * * *  (every 4 hours)
    """
    sources = ["jobvision", "irantalent", "linkedin", "quera"]
    job = group(scrape_source_task.s(src) for src in sources)
    job.apply_async()
    logger.info("scrape_all_sources_enqueued", sources=sources)


# ---------------------------------------------------------------------------
# Matching / scoring
# ---------------------------------------------------------------------------


@celery_app.task(name="karyabee.orchestration.tasks.match_and_score_jobs")
def match_and_score_jobs() -> None:
    """
    Compute match scores for all unscored or pending jobs.

    Scheduled:
        15 mins after scraping cycles.
    """
    db = _db_session()
    updated = 0
    try:
        jobs: List[Job] = (
            db.execute(
                select(Job).where(
                    and_(
                        Job.status.in_(("pending", "new")),
                    )
                )
            )
            .scalars()
            .all()
        )
        for job in jobs:
            result = calculate_match_score(job)
            job.match_score = result.final_score
            job.skill_gaps = result.skill_gaps
            job.apply_decision = result.apply_decision
            updated += 1

        db.commit()
        logger.info(
            "match_and_score_completed",
            jobs=len(jobs),
            updated=updated,
        )
    except Exception as exc:
        db.rollback()
        logger.error("match_and_score_failed", error=str(exc))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Auto apply
# ---------------------------------------------------------------------------


@celery_app.task(name="karyabee.orchestration.tasks.auto_apply_top_matches")
def auto_apply_top_matches() -> None:
    """
    Auto-apply to top jobs based on match_score and predictor.

    Rules:
    - Filter jobs with apply_decision == True and match_score >= threshold.
    - Use InterviewPredictor to further refine; apply if prob > 0.25.
    - Limit to top 25 per cycle.
    - Use PlaywrightApplier and AccountManager for execution.

    Scheduled:
        45 mins after scraping cycles.
    """
    threshold = float(settings.match_score_threshold)
    limit = int(settings.apply_limit_per_cycle)

    db = _db_session()
    applied = 0
    try:
        jobs: List[Job] = (
            db.execute(
                select(Job)
                .where(
                    and_(
                        Job.apply_decision.is_(True),
                        Job.match_score >= threshold,
                        Job.status == "pending",
                    )
                )
                .order_by(Job.match_score.desc())
                .limit(limit)
            )
            .scalars()
            .all()
        )

        for job in jobs:
            # Build InterviewFeatures
            skills_overlap = 0.8 if (job.skill_gaps or {}).get("gaps") == [] else 0.6
            features = InterviewFeatures(
                match_score=job.match_score or 0.0,
                skills_overlap=skills_overlap,
                experience_gap=0.0,
                company_size=job.company_size or "",
                salary_delta=None,
                location_match=1.0 if (job.location or "").lower().find("remote") >= 0 else 0.6,
                application_speed_hours=_hours_since(job.posted_date),
            )
            prediction = interview_predictor.predict(features)
            if not prediction.recommend_apply:
                logger.info(
                    "auto_apply_skipped_by_predictor",
                    job_id=str(job.id),
                    score=job.match_score,
                    prob=prediction.probability,
                )
                continue

            platform = (job.source or "generic").lower()
            acc_mgr = get_account_manager(platform)
            account = acc_mgr.get_next_account()
            if not account:
                logger.error(
                    "auto_apply_no_account",
                    platform=platform,
                    job_id=str(job.id),
                )
                continue

            # Generate resume and cover letter
            resumes = generate_resumes(job.title, job.company, job.description or "")
            std_pdf = resumes["standard"]["pdf"]
            resume_path = _persist_resume(job.id, std_pdf)

            ctx = CoverLetterContext(
                company=job.company,
                role_title=job.title,
                job_description=job.description or "",
                source=job.source or "",
            )
            cover_letter = generate_cover_letter(ctx)

            from karyabee.applier.base import ApplicationPayload

            payload = ApplicationPayload(
                job=job,
                resume_path=resume_path,
                cover_letter_text=cover_letter,
                portfolio_url="https://arshava.framer.ai",
                extra_fields={},
            )

            result = playwright_applier.apply(payload)

            application = Application(
                job_id=job.id,
                resume_version="standard",
                cover_letter=cover_letter,
                account_used=account.username,
                confirmation_number=result.confirmation_number,
                screenshot_path=result.screenshot_path,
                outcome="pending" if result.success else "failed",
            )
            db.add(application)

            if result.success:
                job.status = "applied"
                acc_mgr.mark_application_used(account)
                applied += 1
                inc_applications_sent(job.source or "unknown", 1)
                telegram_notifier.notify_application_sent(job, application)
            else:
                logger.error(
                    "auto_apply_failed",
                    job_id=str(job.id),
                    error=result.error or "",
                )

        db.commit()
        logger.info(
            "auto_apply_top_matches_completed",
            considered=len(jobs),
            applied=applied,
        )
    except Exception as exc:
        db.rollback()
        logger.error("auto_apply_top_matches_failed", error=str(exc))
    finally:
        db.close()


def _persist_resume(job_id, pdf_bytes: bytes) -> str:
    """Persist generated resume PDF and return filesystem path."""
    resumes_dir = Path("data/resumes")
    resumes_dir.mkdir(parents=True, exist_ok=True)
    path = resumes_dir / f"{job_id}_standard.pdf"
    with path.open("wb") as f:
        f.write(pdf_bytes)
    return str(path)


def _hours_since(d: Optional[dt.date]) -> Optional[float]:
    if not d:
        return None
    delta = dt.datetime.now().date() - d
    return float(delta.days * 24)


# ---------------------------------------------------------------------------
# Response checking / follow-ups
# ---------------------------------------------------------------------------


@celery_app.task(name="karyabee.orchestration.tasks.check_responses")
def check_responses() -> None:
    """
    Poll IMAP inbox for responses and update applications.

    Scheduled:
        0 */12 * * * (every 12 hours)
    """
    if not (settings.email_user and settings.email_password):
        logger.warn("check_responses_email_not_configured")
        return

    db = _db_session()
    try:
        imap = imaplib.IMAP4_SSL(settings.email_host, settings.email_port)
        imap.login(settings.email_user, settings.email_password.get_secret_value())  # type: ignore[union-attr]
        imap.select("INBOX")

        # Basic search for recent messages
        typ, data = imap.search(None, "SINCE", (dt.date.today() - dt.timedelta(days=7)).strftime("%d-%b-%Y"))
        if typ != "OK":
            logger.error("imap_search_failed", typ=typ)
            imap.logout()
            return

        id_list = data[0].split()
        for num in id_list:
            typ, msg_data = imap.fetch(num, "(RFC822)")
            if typ != "OK":
                continue
            msg = email.message_from_bytes(msg_data[0][1])
            subject = _decode_mime_header(msg.get("Subject", ""))
            body = _extract_email_body(msg)

            # Heuristic match: look for application id / job title in subject/body
            _handle_email_response(db, subject, body)

        db.commit()
        imap.logout()
        logger.info("check_responses_completed")
    except Exception as exc:
        db.rollback()
        logger.error("check_responses_failed", error=str(exc))
    finally:
        db.close()


def _decode_mime_header(value: str) -> str:
    parts = decode_header(value)
    decoded = ""
    for text, enc in parts:
        if isinstance(text, bytes):
            decoded += text.decode(enc or "utf-8", errors="ignore")
        else:
            decoded += text
    return decoded


def _extract_email_body(msg) -> str:
    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            if ctype == "text/plain":
                try:
                    return part.get_payload(decode=True).decode(
                        part.get_content_charset() or "utf-8",
                        errors="ignore",
                    )
                except Exception:
                    continue
    else:
        if msg.get_content_type() == "text/plain":
            try:
                return msg.get_payload(decode=True).decode(
                    msg.get_content_charset() or "utf-8",
                    errors="ignore",
                )
            except Exception:
                pass
    return ""


def _handle_email_response(db: Session, subject: str, body: str) -> None:
    """
    Heuristic mapping from email to Application record.

    Uses job titles and confirmation numbers if available.
    """
    snippet = (subject + " " + body)[:500].lower()
    if "interview" in snippet or "مصاحبه" in snippet:
        outcome = "interview"
    elif "offer" in snippet:
        outcome = "offer"
    elif "reject" in snippet or "unfortunately" in snippet or "regret" in snippet:
        outcome = "rejected"
    else:
        outcome = "response"

    # Best-effort: update latest application
    application = (
        db.execute(
            select(Application)
            .order_by(Application.applied_at.desc())
            .limit(1)
        )
        .scalars()
        .first()
    )
    if not application:
        return

    application.response_received = True
    application.response_date = dt.datetime.utcnow()
    application.response_type = outcome
    application.outcome = outcome
    logger.info(
        "application_response_detected",
        application_id=str(application.id),
        outcome=outcome,
    )
    telegram_notifier.notify_response(application)


@celery_app.task(name="karyabee.orchestration.tasks.send_follow_ups")
def send_follow_ups() -> None:
    """
    Send follow-up emails for stale applications.

    Logic:
    - Applications where:
        - applied_at > 7 days ago
        - no response_received
    - One follow-up per application, tracked via FollowUp table.

    Scheduled:
        0 10 * * * (daily at 10 AM)
    """
    db = _db_session()
    try:
        cutoff = dt.datetime.utcnow() - dt.timedelta(days=7)
        apps: List[Application] = (
            db.execute(
                select(Application).where(
                    and_(
                        Application.applied_at <= cutoff,
                        Application.response_received.is_(False),
                    )
                )
            )
            .scalars()
            .all()
        )

        for app in apps:
            existing = (
                db.execute(
                    select(FollowUp).where(FollowUp.application_id == app.id)
                )
                .scalars()
                .first()
            )
            if existing:
                continue

            job: Job = app.job
            subject = f"Follow-up on {job.title} application"
            body = (
                f"Dear {job.company} hiring team,\n\n"
                "I wanted to briefly follow up on my application submitted last week for the "
                f"{job.title} role. I remain very interested in the position and would be glad to "
                "discuss how my experience in AI/LLM systems can help your team.\n\n"
                "Best regards,\nArash Mansourpour"
            )

            try:
                email_sender.send_email(
                    to_address=None,
                    subject=subject,
                    html_body=body.replace("\n", "<br>"),
                )
                follow = FollowUp(
                    application_id=app.id,
                    scheduled_for=cutoff,
                    sent_at=dt.datetime.utcnow(),
                    message=body,
                    response_received=False,
                )
                db.add(follow)
                logger.info(
                    "follow_up_sent",
                    application_id=str(app.id),
                )
            except Exception as exc:
                logger.error(
                    "follow_up_send_failed",
                    application_id=str(app.id),
                    error=str(exc),
                )

        db.commit()
    except Exception as exc:
        db.rollback()
        logger.error("send_follow_ups_failed", error=str(exc))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Reporting / analytics
# ---------------------------------------------------------------------------


@celery_app.task(name="karyabee.orchestration.tasks.generate_daily_report")
def generate_daily_report() -> None:
    """
    Generate and send daily performance report.

    Scheduled:
        0 9,21 * * * (9 AM and 9 PM)
    """
    from karyabee.analytics.report_generator import build_daily_report

    db = _db_session()
    try:
        today = dt.date.today()
        html, summary = build_daily_report(db, today)
        email_sender.send_email(
            to_address=None,
            subject=f"[KARYABEEEE] Daily Report - {today.isoformat()}",
            html_body=html,
        )
        telegram_notifier.send_markdown(
            f"📊 Daily report generated.\n\n{summary}",
        )
        logger.info("generate_daily_report_completed")
    except Exception as exc:
        logger.error("generate_daily_report_failed", error=str(exc))
    finally:
        db.close()


@celery_app.task(name="karyabee.orchestration.tasks.weekly_deep_analysis")
def weekly_deep_analysis() -> None:
    """
    Perform 7-day deep market and performance analysis.

    Scheduled:
        0 10 * * 0 (Sunday 10 AM)
    """
    from karyabee.analytics.market_intelligence import (
        build_weekly_market_intel,
    )

    db = _db_session()
    try:
        end = dt.date.today()
        start = end - dt.timedelta(days=7)
        intel_html, summary = build_weekly_market_intel(db, start, end)
        email_sender.send_email(
            to_address=None,
            subject=f"[KARYABEEEE] Weekly Deep Analysis ({start} - {end})",
            html_body=intel_html,
        )
        telegram_notifier.send_markdown(
            f"📈 Weekly deep analysis ready.\n\n{summary}",
        )
        logger.info("weekly_deep_analysis_completed")
    except Exception as exc:
        logger.error("weekly_deep_analysis_failed", error=str(exc))
    finally:
        db.close()


# ---------------------------------------------------------------------------
# System health
# ---------------------------------------------------------------------------


@celery_app.task(name="karyabee.orchestration.tasks.system_health_check")
def system_health_check() -> None:
    """
    Check core components and emit alerts.

    Scheduled:
        */30 * * * * (every 30 minutes)
    """
    from karyabee.monitoring.health import get_system_health

    try:
        health = get_system_health()
        if not health.get("all_healthy", False):
            logger.error("system_health_check_failed", health=health)
            telegram_notifier.send_alert(
                "🚨 System health issue detected",
                details=health,
            )
        else:
            logger.info("system_health_check_ok")
    except Exception as exc:
        logger.error("system_health_check_exception", error=str(exc))


# ---------------------------------------------------------------------------
# Beat schedule (for Celery beat)
# ---------------------------------------------------------------------------

celery_app.conf.beat_schedule = {
    "scrape_all_sources_every_4h": {
        "task": "karyabee.orchestration.tasks.scrape_all_sources",
        "schedule": crontab(minute=0, hour="*/4"),
    },
    "match_and_score_after_scrape": {
        "task": "karyabee.orchestration.tasks.match_and_score_jobs",
        "schedule": crontab(minute=15, hour="*/4"),
    },
    "auto_apply_after_scrape": {
        "task": "karyabee.orchestration.tasks.auto_apply_top_matches",
        "schedule": crontab(minute=45, hour="*/4"),
    },
    "check_responses_12h": {
        "task": "karyabee.orchestration.tasks.check_responses",
        "schedule": crontab(minute=0, hour="*/12"),
    },
    "send_follow_ups_daily": {
        "task": "karyabee.orchestration.tasks.send_follow_ups",
        "schedule": crontab(minute=0, hour=10),
    },
    "generate_daily_report": {
        "task": "karyabee.orchestration.tasks.generate_daily_report",
        "schedule": crontab(minute=0, hour="9,21"),
    },
    "weekly_deep_analysis": {
        "task": "karyabee.orchestration.tasks.weekly_deep_analysis",
        "schedule": crontab(minute=0, hour=10, day_of_week="0"),
    },
    "system_health_check": {
        "task": "karyabee.orchestration.tasks.system_health_check",
        "schedule": crontab(minute="*/30"),
    },
}