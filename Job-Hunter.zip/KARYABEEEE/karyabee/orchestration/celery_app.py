"""
Celery application factory and configuration for KARYABEEEE.

Features:
- RabbitMQ broker (from settings.effective_celery_broker_url)
- Redis result backend
- JSON serialization only
- Sensible worker configuration for production
- Task routing for scraping, matching, applying, analytics, monitoring
"""

from __future__ import annotations

import os
from typing import Any, Dict

from celery import Celery

from karyabee.config import settings
from karyabee.logging_config import get_logger

logger = get_logger(__name__)

CELERY_APP_NAME = "karyabee"


def _celery_config() -> Dict[str, Any]:
    """
    Build Celery configuration dictionary from settings.

    Returns:
        Celery configuration mapping.
    """
    return {
        "broker_url": settings.effective_celery_broker_url,
        "result_backend": settings.celery_result_backend,
        "task_serializer": "json",
        "result_serializer": "json",
        "accept_content": ["json"],
        "timezone": "Asia/Tehran",
        "enable_utc": True,
        "worker_prefetch_multiplier": 4,
        "worker_max_tasks_per_child": 1000,
        "task_acks_late": True,
        "broker_heartbeat": 30,
        "result_expires": 60 * 60 * 6,  # 6 hours
        "task_routes": {
            "karyabee.orchestration.tasks.scrape_all_sources": {
                "queue": "scraping"
            },
            "karyabee.orchestration.tasks.match_and_score_jobs": {
                "queue": "matching"
            },
            "karyabee.orchestration.tasks.auto_apply_top_matches": {
                "queue": "applying"
            },
            "karyabee.orchestration.tasks.check_responses": {
                "queue": "inbox"
            },
            "karyabee.orchestration.tasks.send_follow_ups": {
                "queue": "followups"
            },
            "karyabee.orchestration.tasks.generate_daily_report": {
                "queue": "reports"
            },
            "karyabee.orchestration.tasks.weekly_deep_analysis": {
                "queue": "reports"
            },
            "karyabee.orchestration.tasks.system_health_check": {
                "queue": "monitoring"
            },
        },
    }


def create_celery_app() -> Celery:
    """
    Create and configure Celery application.

    Returns:
        Configured Celery app.
    """
    app = Celery(CELERY_APP_NAME)
    config = _celery_config()
    app.conf.update(config)

    # Autodiscover tasks within karyabee.orchestration
    app.autodiscover_tasks(
        packages=["karyabee.orchestration"],
        related_name="tasks",
    )

    logger.info(
        "celery_app_initialized",
        broker=app.conf.broker_url,
        backend=app.conf.result_backend,
    )
    return app


# Eager singleton to match docker-compose entrypoints
celery_app: Celery = create_celery_app()


@celery_app.task(name="karyabee.orchestration.debug_ping")
def debug_ping() -> str:
    """
    Lightweight task to verify Celery wiring.

    Returns:
        "pong" string.
    """
    logger.info("celery_debug_ping_invoked")
    return "pong"