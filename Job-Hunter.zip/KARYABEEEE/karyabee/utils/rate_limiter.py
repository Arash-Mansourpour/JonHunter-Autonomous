"""
Redis-backed token bucket rate limiter for KARYABEEEE.

Features:
- Per-key (e.g., per-endpoint, per-user, per-IP) limits
- Token bucket algorithm with refill based on time
- Uses Redis for distributed, multi-process safety via Lua script
- Graceful degradation when Redis is unavailable (no hard fail)
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

import redis

from karyabee.config import settings
from karyabee.logging_config import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True)
class RateLimitConfig:
    """Configuration for a token bucket."""

    capacity: int
    refill_rate_per_sec: float  # tokens per second


class RateLimiter:
    """
    Redis-backed token bucket rate limiter.

    The limiter stores a JSON-like structure in Redis:
    - tokens: current token count
    - ts: last update timestamp (epoch seconds)
    """

    LUA_SCRIPT = """
    local key = KEYS[1]
    local capacity = tonumber(ARGV[1])
    local refill_rate = tonumber(ARGV[2])
    local now = tonumber(ARGV[3])

    local data = redis.call("HMGET", key, "tokens", "ts")
    local tokens = tonumber(data[1])
    local ts = tonumber(data[2])

    if tokens == nil or ts == nil then
        tokens = capacity
        ts = now
    else
        local delta = math.max(0, now - ts)
        local refill = delta * refill_rate
        tokens = math.min(capacity, tokens + refill)
        ts = now
    end

    local allowed = 0
    if tokens >= 1 then
        tokens = tokens - 1
        allowed = 1
    end

    redis.call("HMSET", key, "tokens", tokens, "ts", ts)
    -- Set TTL to 2x time to drain capacity at refill rate (avoid stale keys)
    local ttl = math.ceil(capacity / refill_rate * 2)
    if ttl > 0 then
        redis.call("EXPIRE", key, ttl)
    end

    return allowed
    """

    def __init__(self, redis_url: Optional[str] = None, prefix: str = "karyabee:rl:") -> None:
        """
        Initialize RateLimiter.

        Args:
            redis_url: Redis URL, defaults to settings.redis_url.
            prefix: Key namespace prefix for all rate-limit entries.
        """
        self._redis_url = redis_url or settings.redis_url
        self._prefix = prefix
        # Lazy client + script; keep memory/FD usage minimal.
        self._client: Optional[redis.Redis] = None
        self._script_sha: Optional[str] = None

    @property
    def client(self) -> Optional[redis.Redis]:
        """Return Redis client or None if connection fails."""
        if self._client is not None:
            return self._client
        try:
            client = redis.Redis.from_url(self._redis_url)
            client.ping()
            self._client = client
            logger.info("rate_limiter_redis_connected", url=self._redis_url)
            return self._client
        except Exception as exc:  # pragma: no cover - connectivity is environment-specific
            logger.error("rate_limiter_redis_connection_failed", error=str(exc))
            self._client = None
            return None

    def _load_script(self) -> None:
        """Load Lua script into Redis and store SHA (idempotent)."""
        client = self.client
        if not client or self._script_sha:
            return
        try:
            self._script_sha = client.script_load(self.LUA_SCRIPT)
        except Exception as exc:  # pragma: no cover
            logger.error("rate_limiter_script_load_failed", error=str(exc))
            self._script_sha = None

    def _key(self, name: str) -> str:
        """Compose Redis key for a given logical name."""
        return f"{self._prefix}{name}"

    def allow(self, name: str, config: RateLimitConfig) -> bool:
        """
        Attempt to consume a token for the given name.

        Args:
            name: Logical limiter key (e.g., "api_jobs", "ai_gemini", "ip:1.2.3.4").
            config: RateLimitConfig specifying capacity and refill rate.

        Returns:
            True if allowed, False if rate-limited.
        """
        client = self.client
        if not client:
            # If Redis is down, fail-open to avoid breaking production flows.
            logger.warn(
                "rate_limiter_no_redis_fail_open",
                name=name,
                capacity=config.capacity,
            )
            return True

        self._load_script()
        now = int(time.time())
        key = self._key(name)

        try:
            if self._script_sha:
                # Use cached script
                allowed = client.evalsha(
                    self._script_sha,
                    1,
                    key,
                    config.capacity,
                    config.refill_rate_per_sec,
                    now,
                )
            else:
                # Fallback to direct EVAL if SHA missing
                allowed = client.eval(
                    self.LUA_SCRIPT,
                    1,
                    key,
                    config.capacity,
                    config.refill_rate_per_sec,
                    now,
                )
            return bool(int(allowed))
        except redis.exceptions.ResponseError as exc:  # pragma: no cover
            # Script may be flushed; reload and retry once.
            logger.error("rate_limiter_evalsha_failed", error=str(exc))
            try:
                self._script_sha = client.script_load(self.LUA_SCRIPT)
                allowed = client.evalsha(
                    self._script_sha,
                    1,
                    key,
                    config.capacity,
                    config.refill_rate_per_sec,
                    now,
                )
                return bool(int(allowed))
            except Exception as exc2:  # pragma: no cover
                logger.error("rate_limiter_eval_fallback_failed", error=str(exc2))
                # Fail-open to avoid breaking core flows.
                return True
        except Exception as exc:  # pragma: no cover
            logger.error("rate_limiter_unexpected_error", error=str(exc))
            # Fail-open on unexpected limiter errors.
            return True


# Shared global limiter instance for convenience
rate_limiter = RateLimiter()