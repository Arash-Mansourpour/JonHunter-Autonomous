"""
Validation and sanitization utilities for KARYABEEEE.

Provides:
- Email, phone, URL validation
- Salary range validation
- Generic text sanitization for logs and HTML contexts
"""

from __future__ import annotations

import html
import re
from typing import Optional
from urllib.parse import urlparse

from karyabee.logging_config import get_logger

logger = get_logger(__name__)

EMAIL_REGEX = re.compile(
    r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*$"
)
PHONE_REGEX = re.compile(r"^\+?[0-9\s\-()]{7,20}$")


def is_valid_email(email: str) -> bool:
    """
    Validate email address format.

    Args:
        email: Email string.

    Returns:
        True if syntactically valid, False otherwise.
    """
    if not email:
        return False
    return bool(EMAIL_REGEX.match(email))


def is_valid_phone(phone: str) -> bool:
    """
    Validate phone number format (lenient, international, supports Persian usage).

    Args:
        phone: Phone string.

    Returns:
        True if syntactically plausible, False otherwise.
    """
    if not phone:
        return False
    return bool(PHONE_REGEX.match(phone))


def is_valid_url(url: str) -> bool:
    """
    Validate URL format (scheme + netloc required).

    Args:
        url: URL string.

    Returns:
        True if syntactically valid, False otherwise.
    """
    if not url:
        return False
    try:
        parsed = urlparse(url)
        return parsed.scheme in {"http", "https"} and bool(parsed.netloc)
    except Exception:
        return False


def validate_salary_range(
    salary_min: Optional[int],
    salary_max: Optional[int],
) -> bool:
    """
    Validate salary range where present.

    Rules:
    - Both None: valid (not provided)
    - One provided: must be positive
    - Both provided: min > 0, max > 0, min <= max

    Args:
        salary_min: Minimum salary.
        salary_max: Maximum salary.

    Returns:
        True if logically consistent, False otherwise.
    """
    if salary_min is None and salary_max is None:
        return True
    if salary_min is not None and salary_min <= 0:
        return False
    if salary_max is not None and salary_max <= 0:
        return False
    if salary_min is not None and salary_max is not None:
        return salary_min <= salary_max
    return True


def sanitize_text(text: Optional[str], max_length: int = 10_000) -> str:
    """
    Sanitize free-form text input.

    - Ensure UTF-8 safe
    - Escape HTML entities
    - Strip control characters
    - Truncate to max_length

    Args:
        text: Raw text (possibly None).
        max_length: Maximum allowed length.

    Returns:
        Sanitized text (possibly empty).
    """
    if not text:
        return ""
    # Normalize line endings and strip dangerous control chars excluding \n, \t
    cleaned = "".join(ch for ch in text if ch.isprintable() or ch in ("\n", "\t"))
    cleaned = cleaned.strip()
    if len(cleaned) > max_length:
        logger.warn(
            "sanitize_text_truncated",
            original_length=len(cleaned),
            max_length=max_length,
        )
        cleaned = cleaned[:max_length]
    # Escape HTML to prevent injection in email / web contexts
    return html.escape(cleaned, quote=False)