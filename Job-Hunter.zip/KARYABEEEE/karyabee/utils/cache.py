"""
Redis cache utilities for KARYABEEEE.

Features:
- Typed, JSON-serialized get/set/delete helpers
- Graceful degradation when Redis is unavailable
- Namespaced keys to avoid collisions
"""

from __future__ import annotations

import json
import time
from typing import Any, Callable, Dict, Optional, TypeVar

import redis

from karyabee.config import settings
from karyabee.logging_config import get_logger

logger = get_logger(__name__)

T = TypeVar("T")


class RedisCache:
    """
    Redis-backed cache with JSON serialization and safe fallbacks.

    Design:
    - Lazy, shared connection (per-instance) to minimize connection overhead.
    - Fail-quietly if Redis is unavailable (no hard dependency for core flows).
    - Used as generic building block for:
      - HTML snapshots
      - AI prompt/result caching
      - Session / cookie persistence (zero-cost optimization)
    """

    def __init__(
        self,
        url: str | None = None,
        prefix: str = "karyabee:",
        client_factory: Callable[[str], redis.Redis] | None = None,
    ) -> None:
        self._url = url or settings.redis_url
        self._prefix = prefix
        # Allow test injection or reuse; default uses from_url with pooling.
        self._client_factory = client_factory or (lambda u: redis.Redis.from_url(u))
        self._client: Optional[redis.Redis] = None

    @property
    def client(self) -> Optional[redis.Redis]:
        """Return a Redis client instance, or None on failure."""
        if self._client is not None:
            return self._client
        try:
            client = self._client_factory(self._url)
            # Lightweight connectivity check
            client.ping()
            self._client = client
            logger.info("redis_cache_connected", url=self._url)
            return self._client
        except Exception as exc:  # pragma: no cover - best-effort
            logger.error("redis_cache_connection_failed", error=str(exc))
            self._client = None
            return None

    def _k(self, key: str) -> str:
        """Compose a namespaced cache key."""
        return f"{self._prefix}{key}"

    def get(self, key: str) -> Optional[T]:
        """
        Get a value from cache.

        Args:
            key: Cache key (without prefix).

        Returns:
            Deserialized value or None.
        """
        client = self.client
        if not client:
            return None
        try:
            raw = client.get(self._k(key))
            if raw is None:
                return None
            return json.loads(raw)
        except Exception as exc:  # pragma: no cover
            logger.error("redis_cache_get_failed", key=key, error=str(exc))
            return None

    def set(self, key: str, value: Any, ttl_seconds: int) -> None:
        """
        Set a value in cache.

        Args:
            key: Cache key.
            value: JSON-serializable value.
            ttl_seconds: Time-to-live in seconds.
        """
        client = self.client
        if not client:
            return
        try:
            payload = json.dumps(value, ensure_ascii=False)
            client.set(self._k(key), payload, ex=ttl_seconds)
        except Exception as exc:  # pragma: no cover
            logger.error(
                "redis_cache_set_failed",
                key=key,
                error=str(exc),
                ttl_seconds=ttl_seconds,
            )

    def delete(self, key: str) -> None:
        """
        Delete a key from cache.

        Args:
            key: Cache key.
        """
        client = self.client
        if not client:
            return
        try:
            client.delete(self._k(key))
        except Exception as exc:  # pragma: no cover
            logger.error("redis_cache_delete_failed", key=key, error=str(exc))

    def cached_call(
        self,
        key: str,
        ttl_seconds: int,
        producer: Callable[[], T],
        refresh_on_error: bool = False,
    ) -> T:
        """
        Get-or-set wrapper using cache.

        Behavior:
        - On cache hit: returns cached value.
        - On miss: computes via producer(), caches if not None.
        - On Redis error: degrades to direct producer() without raising.

        Args:
            key: Cache key.
            ttl_seconds: TTL for cached value.
            producer: Callable to compute value on miss.
            refresh_on_error: If True, recompute on deserialization error.

        Returns:
            Cached or newly produced value.
        """
        cached = self.get(key)
        if cached is not None:
            return cached

        value = producer()
        if value is None and not refresh_on_error:
            return value

        self.set(key, value, ttl_seconds)
        return value


# Eager global for convenience; reuse one lightweight client per process.
default_cache = RedisCache()


class AICache:
    """
    Lightweight 2-level cache for AI/matching results.

    - L1: in-process dict (fast, ephemeral)
    - L2: Redis via RedisCache (7d TTL by default)
    - Keyed deterministically by (job_id, stable profile hash)

    This is intentionally simple and zero-cost: no extra services, just Redis.
    """

    def __init__(self, redis_cache: RedisCache | None = None) -> None:
        self._redis = redis_cache or RedisCache(prefix="karyabee:ai:")
        self._local: Dict[str, Any] = {}

    @staticmethod
    def _profile_hash(profile_payload: Any) -> str:
        # Stable, order-independent hash for profile-like structures.
        raw = json.dumps(profile_payload, sort_keys=True, ensure_ascii=False)
        return raw  # may be hashed by caller for additional compactness

    @staticmethod
    def _key(job_id: Any, profile_hash: str) -> str:
        return f"match:{job_id}:{profile_hash}"

    def get(self, job_id: Any, profile_payload: Any) -> Any | None:
        profile_hash = self._profile_hash(profile_payload)
        key = self._key(job_id, profile_hash)

        # L1
        if key in self._local:
            return self._local[key]

        # L2
        cached = self._redis.get(key)
        if cached is not None:
            self._local[key] = cached
            return cached

        return None

    def set(self, job_id: Any, profile_payload: Any, result: Any, ttl_seconds: int = 7 * 24 * 60 * 60) -> None:
        profile_hash = self._profile_hash(profile_payload)
        key = self._key(job_id, profile_hash)
        self._local[key] = result
        self._redis.set(key, result, ttl_seconds)


# Shared AI cache instance
ai_cache = AICache(default_cache)