"""
Analytics report generator for KARYABEEEE.

Generates:
- Daily HTML report
- Weekly HTML report / summary
Used by:
- Celery tasks (generate_daily_report, weekly_deep_analysis)
- Telegram bot /report commands

Content:
- Executive summary (2-3 sentences)
- Metrics table (applied, responses, interviews, offers, rates)
- Top applications (5 jobs with links)
- Responses received
- Market intelligence hook (import from market_intelligence)
- Charts (matplotlib PNG embedded as base64)
"""

from __future__ import annotations

import base64
import io
from datetime import date, datetime, timedelta
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt
from sqlalchemy import and_
from sqlalchemy.orm import Session

from karyabee.logging_config import get_logger
from karyabee.models import Analytics, Application, Job

logger = get_logger(__name__)


def _encode_plot_png() -> str:
    """Render current matplotlib figure to base64 PNG data URI."""
    buf = io.BytesIO()
    plt.savefig(buf, format="png", bbox_inches="tight")
    plt.close()
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def _get_period_analytics(
    db: Session,
    start: date,
    end: date,
) -> List[Analytics]:
    """Fetch Analytics rows for [start, end]."""
    return (
        db.query(Analytics)
        .filter(and_(Analytics.date >= start, Analytics.date <= end))
        .order_by(Analytics.date.asc())
        .all()
    )


def _build_summary_from_rows(rows: List[Analytics]) -> Dict[str, float]:
    """Aggregate totals and derive rates."""
    if not rows:
        return {
            "jobs_scraped": 0,
            "applications_sent": 0,
            "responses_received": 0,
            "interviews_scheduled": 0,
            "offers_received": 0,
            "response_rate": 0.0,
            "interview_rate": 0.0,
            "offer_rate": 0.0,
        }

    jobs_scraped = sum(r.jobs_scraped or 0 for r in rows)
    apps = sum(r.applications_sent or 0 for r in rows)
    responses = sum(r.responses_received or 0 for r in rows)
    interviews = sum(r.interviews_scheduled or 0 for r in rows)
    offers = sum(r.offers_received or 0 for r in rows)

    def rate(x: int, y: int) -> float:
        return float(x) / float(y) if y > 0 else 0.0

    return {
        "jobs_scraped": float(jobs_scraped),
        "applications_sent": float(apps),
        "responses_received": float(responses),
        "interviews_scheduled": float(interviews),
        "offers_received": float(offers),
        "response_rate": rate(responses, apps),
        "interview_rate": rate(interviews, apps),
        "offer_rate": rate(offers, apps),
    }


def _top_applications(db: Session, limit: int = 5) -> List[Dict[str, str]]:
    """Return top applications by match_score with links."""
    rows = (
        db.query(Application, Job)
        .join(Job, Application.job_id == Job.id)
        .order_by(Job.match_score.desc().nullslast())
        .limit(limit)
        .all()
    )
    results: List[Dict[str, str]] = []
    for app, job in rows:
        results.append(
            {
                "job_title": job.title,
                "company": job.company,
                "source": job.source or "",
                "match_score": f"{job.match_score:.1f}" if job.match_score else "",
                "application_id": str(app.id),
                "job_url": job.application_url or "",
            }
        )
    return results


def _recent_responses(db: Session, days: int = 7) -> List[Dict[str, str]]:
    """Return recent responses within N days."""
    cutoff = datetime.utcnow() - timedelta(days=days)
    rows = (
        db.query(Application, Job)
        .join(Job, Application.job_id == Job.id)
        .filter(
            Application.response_received.is_(True),
            Application.response_date >= cutoff,
        )
        .order_by(Application.response_date.desc())
        .limit(20)
        .all()
    )
    results: List[Dict[str, str]] = []
    for app, job in rows:
        results.append(
            {
                "job_title": job.title,
                "company": job.company,
                "outcome": app.outcome,
                "response_date": app.response_date.isoformat()
                if app.response_date
                else "",
            }
        )
    return results


def _build_chart(rows: List[Analytics]) -> str:
    """Build simple line chart (applications_sent vs offers_received)."""
    if not rows:
        return ""
    dates = [r.date for r in rows]
    apps = [r.applications_sent or 0 for r in rows]
    offers = [r.offers_received or 0 for r in rows]

    plt.figure(figsize=(8, 3))
    plt.plot(dates, apps, label="Applications", marker="o")
    plt.plot(dates, offers, label="Offers", marker="s")
    plt.xticks(rotation=45)
    plt.legend()
    plt.tight_layout()
    return _encode_plot_png()


def build_daily_report(db: Session, day: date) -> Tuple[str, str]:
    """
    Build daily HTML report for given day.

    Returns:
        (html, summary_text)
    """
    rows = _get_period_analytics(db, day, day)
    summary = _build_summary_from_rows(rows)
    top_apps = _top_applications(db)
    responses = _recent_responses(db, days=7)
    chart = _build_chart(rows)

    exec_summary = (
        f"On {day.isoformat()}, {int(summary['applications_sent'])} applications were sent "
        f"with a response rate of {summary['response_rate']:.1%} and "
        f"{int(summary['offers_received'])} new offers."
    )

    html_parts = [
        "<html><body>",
        f"<h2>KARYABEEEE Daily Report - {day.isoformat()}</h2>",
        f"<p>{exec_summary}</p>",
        "<h3>Key Metrics</h3>",
        "<table border='1' cellspacing='0' cellpadding='4'>",
        "<tr><th>Metric</th><th>Value</th></tr>",
        f"<tr><td>Jobs Scraped</td><td>{int(summary['jobs_scraped'])}</td></tr>",
        f"<tr><td>Applications Sent</td><td>{int(summary['applications_sent'])}</td></tr>",
        f"<tr><td>Responses</td><td>{int(summary['responses_received'])}</td></tr>",
        f"<tr><td>Interviews</td><td>{int(summary['interviews_scheduled'])}</td></tr>",
        f"<tr><td>Offers</td><td>{int(summary['offers_received'])}</td></tr>",
        f"<tr><td>Response Rate</td><td>{summary['response_rate']:.1%}</td></tr>",
        f"<tr><td>Offer Rate</td><td>{summary['offer_rate']:.1%}</td></tr>",
        "</table>",
    ]

    if chart:
        html_parts.append("<h3>Applications vs Offers</h3>")
        html_parts.append(f"<img src='{chart}' alt='Trend Chart' />")

    if top_apps:
        html_parts.append("<h3>Top Applications</h3><ul>")
        for t in top_apps:
            link = t["job_url"] or "#"
            html_parts.append(
                f"<li><a href='{link}'>{t['job_title']} at {t['company']}</a> "
                f"(Score: {t['match_score']})</li>"
            )
        html_parts.append("</ul>")

    if responses:
        html_parts.append("<h3>Recent Responses</h3><ul>")
        for r in responses:
            html_parts.append(
                f"<li>{r['response_date']}: {r['job_title']} at {r['company']} "
                f"({r['outcome']})</li>"
            )
        html_parts.append("</ul>")

    html_parts.append("</body></html>")
    html = "\n".join(html_parts)

    return html, exec_summary


def build_weekly_summary(
    db: Session,
    start: date,
    end: date,
) -> Tuple[str, str]:
    """
    Build weekly HTML summary between [start, end].

    Returns:
        (html, summary)
    """
    rows = _get_period_analytics(db, start, end)
    summary = _build_summary_from_rows(rows)
    chart = _build_chart(rows)
    top_apps = _top_applications(db)
    responses = _recent_responses(db, days=14)

    exec_summary = (
        f"Between {start.isoformat()} and {end.isoformat()}, "
        f"{int(summary['applications_sent'])} applications were sent with a "
        f"{summary['response_rate']:.1%} response rate and "
        f"{int(summary['offers_received'])} offers."
    )

    html_parts = [
        "<html><body>",
        f"<h2>KARYABEEEE Weekly Report - {start} to {end}</h2>",
        f"<p>{exec_summary}</p>",
        "<h3>Key Metrics (Weekly)</h3>",
        "<table border='1' cellspacing='0' cellpadding='4'>",
        "<tr><th>Metric</th><th>Value</th></tr>",
        f"<tr><td>Jobs Scraped</td><td>{int(summary['jobs_scraped'])}</td></tr>",
        f"<tr><td>Applications Sent</td><td>{int(summary['applications_sent'])}</td></tr>",
        f"<tr><td>Responses</td><td>{int(summary['responses_received'])}</td></tr>",
        f"<tr><td>Interviews</td><td>{int(summary['interviews_scheduled'])}</td></tr>",
        f"<tr><td>Offers</td><td>{int(summary['offers_received'])}</td></tr>",
        f"<tr><td>Response Rate</td><td>{summary['response_rate']:.1%}</td></tr>",
        f"<tr><td>Offer Rate</td><td>{summary['offer_rate']:.1%}</td></tr>",
        "</table>",
    ]

    if chart:
        html_parts.append("<h3>Weekly Trend</h3>")
        html_parts.append(f"<img src='{chart}' alt='Weekly Trend' />")

    if top_apps:
        html_parts.append("<h3>Top Applications</h3><ul>")
        for t in top_apps:
            link = t["job_url"] or "#"
            html_parts.append(
                f"<li><a href='{link}'>{t['job_title']} at {t['company']}</a> "
                f"(Score: {t['match_score']})</li>"
            )
        html_parts.append("</ul>")

    if responses:
        html_parts.append("<h3>Recent Responses</h3><ul>")
        for r in responses:
            html_parts.append(
                f"<li>{r['response_date']}: {r['job_title']} at {r['company']} "
                f"({r['outcome']})</li>"
            )
        html_parts.append("</ul>")

    html_parts.append("</body></html>")
    html = "\n".join(html_parts)
    return html, exec_summary