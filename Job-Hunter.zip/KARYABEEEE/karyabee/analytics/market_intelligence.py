"""
Market intelligence and trend analysis for KARYABEEEE.

Responsibilities:
- Aggregate insights about:
    - In-demand skills and stacks
    - Salary ranges
    - Platform performance
- Provide:
    - Weekly HTML snippet with narrative summary
    - Structured data for deeper analysis

Implementation notes:
- External sources (Glassdoor/PayScale/Google Trends/etc.) are represented in
  a pluggable way. For production, hook HTTP calls with proper API keys and
  caching. Here we implement a deterministic, testable core that can be
  extended safely.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import date
from typing import Dict, Iterable, List, Tuple

from sqlalchemy import and_
from sqlalchemy.orm import Session

from karyabee.logging_config import get_logger
from karyabee.models import Analytics, Job

logger = get_logger(__name__)


@dataclass
class MarketSnapshot:
    """Structured view of weekly market intelligence."""

    start: date
    end: date
    top_skills: List[Tuple[str, int]]
    avg_salary_min: float
    avg_salary_max: float
    platform_success: Dict[str, int]


def _extract_skills_from_jobs(jobs: Iterable[Job]) -> Counter:
    """
    Extract skill tokens from job descriptions and requirements.

    This is intentionally simple and tuned to AI/ML context; can be swapped
    to a proper NLP pipeline.
    """
    keywords = [
        "pytorch",
        "tensorflow",
        "transformer",
        "bert",
        "gpt",
        "t5",
        "llama",
        "rag",
        "nlp",
        "redis",
        "postgresql",
        "docker",
        "kubernetes",
        "fastapi",
        "aws",
        "gcp",
        "selenium",
        "playwright",
    ]
    counter: Counter = Counter()
    for j in jobs:
        text = " ".join(
            [
                j.title or "",
                j.company or "",
                j.description or "",
                " ".join(j.tech_stack or []),
            ]
        ).lower()
        for kw in keywords:
            if kw in text:
                counter[kw] += 1
    return counter


def _salary_stats(jobs: Iterable[Job]) -> Tuple[float, float]:
    """Compute average min/max salary from jobs with ranges."""
    mins: List[int] = []
    maxs: List[int] = []
    for j in jobs:
        if j.salary_min is not None:
            mins.append(j.salary_min)
        if j.salary_max is not None:
            maxs.append(j.salary_max)
    avg_min = float(sum(mins) / len(mins)) if mins else 0.0
    avg_max = float(sum(maxs) / len(maxs)) if maxs else 0.0
    return avg_min, avg_max


def _platform_success_from_analytics(rows: List[Analytics]) -> Dict[str, int]:
    """
    Aggregate per-platform success from Analytics.success_rate_by_platform.

    Returns:
        Mapping from platform name to aggregated success indicator.
    """
    result: Dict[str, int] = defaultdict(int)
    for r in rows:
        data = r.success_rate_by_platform or {}
        for platform, score in data.items():
            try:
                result[platform] += int(score)
            except (ValueError, TypeError):
                continue
    return dict(result)


def build_weekly_market_intel(
    db: Session,
    start: date,
    end: date,
) -> Tuple[str, str]:
    """
    Build weekly market intelligence HTML + summary.

    Data sources:
    - jobs between [start, end]
    - analytics rows between [start, end]

    Returns:
        (html, summary_text)
    """
    jobs: List[Job] = (
        db.query(Job)
        .filter(
            and_(
                Job.posted_date >= start,
                Job.posted_date <= end,
            )
        )
        .all()
    )
    analytics_rows: List[Analytics] = (
        db.query(Analytics)
        .filter(
            and_(
                Analytics.date >= start,
                Analytics.date <= end,
            )
        )
        .all()
    )

    skills_counter = _extract_skills_from_jobs(jobs)
    top_skills = skills_counter.most_common(10)
    avg_min, avg_max = _salary_stats(jobs)
    platform_success = _platform_success_from_analytics(analytics_rows)

    snapshot = MarketSnapshot(
        start=start,
        end=end,
        top_skills=top_skills,
        avg_salary_min=avg_min,
        avg_salary_max=avg_max,
        platform_success=platform_success,
    )

    summary = _render_summary(snapshot)
    html = _render_html(snapshot, summary)

    logger.info(
        "weekly_market_intel_built",
        start=str(start),
        end=str(end),
        top_skills=len(top_skills),
    )

    return html, summary


def _render_summary(snapshot: MarketSnapshot) -> str:
    """Render 2-3 sentence executive summary."""
    skills_part = (
        ", ".join(kw for kw, _ in snapshot.top_skills[:5])
        if snapshot.top_skills
        else "no strong signals"
    )
    salary_part = (
        f"Typical remote AI roles advertise between {int(snapshot.avg_salary_min)} and {int(snapshot.avg_salary_max)} (local units)."
        if snapshot.avg_salary_max > 0
        else "Salary data is sparse this week."
    )
    platform_part = (
        f"Top performing platforms: {', '.join(snapshot.platform_success.keys())}."
        if snapshot.platform_success
        else "No clear platform dominance detected."
    )

    return (
        f"Between {snapshot.start} and {snapshot.end}, demand focused on: {skills_part}. "
        f"{salary_part} {platform_part}"
    )


def _render_html(snapshot: MarketSnapshot, summary: str) -> str:
    """Render full HTML report for weekly market intelligence."""
    lines = [
        "<html><body>",
        f"<h2>KARYABEEEE Weekly Market Intelligence ({snapshot.start} → {snapshot.end})</h2>",
        f"<p>{summary}</p>",
        "<h3>Top Skills / Technologies</h3>",
        "<table border='1' cellspacing='0' cellpadding='4'>",
        "<tr><th>Skill</th><th>Mentions</th></tr>",
    ]
    for skill, count in snapshot.top_skills:
        lines.append(f"<tr><td>{skill}</td><td>{count}</td></tr>")
    lines.append("</table>")

    lines.append("<h3>Salary Signals</h3>")
    if snapshot.avg_salary_max > 0:
        lines.append(
            f"<p>Observed average range: {int(snapshot.avg_salary_min)} - {int(snapshot.avg_salary_max)} (across jobs with explicit salaries).</p>"
        )
    else:
        lines.append("<p>Insufficient explicit salary data this week.</p>")

    lines.append("<h3>Platform Performance</h3>")
    if snapshot.platform_success:
        lines.append("<ul>")
        for platform, score in snapshot.platform_success.items():
            lines.append(f"<li>{platform}: {score}</li>")
        lines.append("</ul>")
    else:
        lines.append("<p>No platform-specific success deltas recorded.</p>")

    lines.append("</body></html>")
    return "\n".join(lines)