"""
Telegram notification helper for KARYABEEEE.

Features:
- Thin wrapper over python-telegram-bot for:
    - Real-time alerts (errors, health issues)
    - Pipeline events:
        * New high-match job
        * Application sent
        * Response received
        * Interview scheduled
        * Offer received
- Handles:
    - Optional configuration (no-ops when token/chat_id missing)
    - Basic rate limiting via in-memory counters (per-process)
"""

from __future__ import annotations

import threading
import time
from typing import Any, Dict, Optional

from telegram import Bot
from telegram.constants import ParseMode

from karyabee.config import settings
from karyabee.logging_config import get_logger

logger = get_logger(__name__)


class TelegramNotifier:
    """Encapsulates Telegram bot notifications."""

    def __init__(self) -> None:
        token = settings.telegram_bot_token.get_secret_value() if settings.telegram_bot_token else None
        chat_id = settings.telegram_chat_id
        self._enabled = bool(token and chat_id)
        self._chat_id = chat_id
        self._lock = threading.Lock()
        self._last_sent_ts = 0.0
        self._min_interval = 1.0  # seconds between messages (soft rate limit)
        self._bot: Optional[Bot] = Bot(token=token) if token else None

        if self._enabled:
            logger.info("telegram_notifier_enabled")
        else:
            logger.warn("telegram_notifier_disabled")

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _can_send(self) -> bool:
        """Check simple per-process rate limit."""
        with self._lock:
            now = time.time()
            if now - self._last_sent_ts < self._min_interval:
                return False
            self._last_sent_ts = now
            return True

    def _safe_send(self, text: str, parse_mode: Optional[str] = None) -> None:
        """Send message if enabled; swallow errors."""
        if not self._enabled or not self._bot or not self._chat_id:
            return
        if not self._can_send():
            return
        try:
            self._bot.send_message(
                chat_id=self._chat_id,
                text=text,
                parse_mode=parse_mode,
                disable_web_page_preview=True,
            )
        except Exception as exc:  # pragma: no cover
            logger.error("telegram_send_failed", error=str(exc))

    # ------------------------------------------------------------------ #
    # Public methods
    # ------------------------------------------------------------------ #

    def send_markdown(self, text: str) -> None:
        """Send a markdown-formatted message."""
        self._safe_send(text, parse_mode=ParseMode.MARKDOWN)

    def send_alert(self, title: str, details: Optional[Dict[str, Any]] = None) -> None:
        """
        Send high-priority alert.

        Args:
            title: Short alert title.
            details: Optional dictionary with context.
        """
        body = f"🚨 {title}"
        if details:
            snippet = "\n".join(f"- {k}: {v}" for k, v in details.items())
            body += f"\n{snippet}"
        self._safe_send(body, parse_mode=ParseMode.MARKDOWN)

    # Domain-specific helpers

    def notify_new_high_match_job(self, job_id: str, title: str, company: str, score: float) -> None:
        """Notify about a newly scraped high-match job."""
        msg = (
            f"🌟 High-match job detected!\n"
            f"*{title}* at *{company}*\n"
            f"Score: `{score}`\n"
            f"/apply {job_id}"
        )
        self.send_markdown(msg)

    def notify_application_sent(self, job, application) -> None:
        """Notify that an application has been submitted."""
        msg = (
            f"✅ Application sent\n"
            f"*{job.title}* at *{job.company}*\n"
            f"Source: `{job.source}` | Match: `{job.match_score}`\n"
            f"Application ID: `{application.id}`"
        )
        self.send_markdown(msg)

    def notify_response(self, application) -> None:
        """Notify when a response is received for an application."""
        job = application.job
        status_emoji = {
            "offer": "💚",
            "interview": "📅",
            "rejected": "❌",
        }.get(application.outcome, "📨")
        msg = (
            f"{status_emoji} Response for *{job.title}* at *{job.company}*\n"
            f"Outcome: `{application.outcome}`"
        )
        self.send_markdown(msg)

    def notify_error(self, context: str, error: str) -> None:
        """Notify about significant errors."""
        msg = f"⚠️ Error in *{context}*\n`{error}`"
        self.send_markdown(msg)


# Eager singleton
telegram_notifier = TelegramNotifier()