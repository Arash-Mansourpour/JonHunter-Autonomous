"""
Asynchronous HTML email sender for KARYABEEEE.

Features:
- Uses aiosmtplib with settings-based SMTP configuration.
- Jinja2 templating support for rich HTML emails.
- Embeds PNG charts (pre-rendered by analytics modules) via CID.
- Robust error handling and structured logging.
"""

from __future__ import annotations

import asyncio
import mimetypes
import os
from email.message import EmailMessage
from pathlib import Path
from typing import Dict, Iterable, Optional, Tuple

import aiosmtplib
from jinja2 import Environment, FileSystemLoader, select_autoescape

from karyabee.config import settings
from karyabee.logging_config import get_logger

logger = get_logger(__name__)

TEMPLATES_DIR = Path("templates/email")
_env = Environment(
    loader=FileSystemLoader(str(TEMPLATES_DIR)),
    autoescape=select_autoescape(["html", "xml"]),
)


class EmailSender:
    """
    Asynchronous HTML email sender.

    This class is safe to use from sync contexts via send_email() wrapper
    which manages its own event loop if necessary.
    """

    def __init__(self) -> None:
        self._host = settings.email_host
        self._port = settings.email_port
        self._use_tls = settings.email_use_tls
        self._username = settings.email_user
        self._password = (
            settings.email_password.get_secret_value()
            if settings.email_password
            else None
        )
        self._from = settings.email_from or self._username
        if not self._from:
            logger.warn("email_sender_no_from_address_configured")

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def send_email(
        self,
        to_address: Optional[str],
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        attachments: Optional[Iterable[Tuple[str, bytes, str]]] = None,
    ) -> None:
        """
        Send an email (sync wrapper).

        Args:
            to_address: Recipient email. If None, defaults to settings.email_user.
            subject: Subject line.
            html_body: HTML content.
            text_body: Optional plain-text body (auto-generated if None).
            attachments: Iterable of (filename, content_bytes, mime_type).
        """
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        coro = self._send_email_async(
            to_address=to_address,
            subject=subject,
            html_body=html_body,
            text_body=text_body,
            attachments=attachments,
        )
        if loop.is_running():
            asyncio.create_task(coro)
        else:
            loop.run_until_complete(coro)

    async def _send_email_async(
        self,
        to_address: Optional[str],
        subject: str,
        html_body: str,
        text_body: Optional[str] = None,
        attachments: Optional[Iterable[Tuple[str, bytes, str]]] = None,
    ) -> None:
        """Async implementation of sending an email."""
        recipient = to_address or settings.email_user or settings.email_from
        if not recipient:
            logger.warn(
                "email_sender_missing_recipient",
                subject=subject,
            )
            return

        msg = EmailMessage()
        msg["From"] = self._from
        msg["To"] = recipient
        msg["Subject"] = subject

        if not text_body:
            # Basic text fallback by stripping tags
            stripped = "".join(
                ch for ch in html_body if ch.isprintable() or ch in ("\n", "\t")
            )
            text_body = stripped

        msg.set_content(text_body)
        msg.add_alternative(html_body, subtype="html")

        # Attachments (e.g., charts)
        if attachments:
            for filename, content, mime in attachments:
                maintype, subtype = mime.split("/", 1)
                msg.add_attachment(
                    content,
                    maintype=maintype,
                    subtype=subtype,
                    filename=filename,
                )

        try:
            if not self._username or not self._password:
                logger.error("email_sender_credentials_missing")
                return

            if self._use_tls:
                await aiosmtplib.send(
                    msg,
                    hostname=self._host,
                    port=self._port,
                    start_tls=True,
                    username=self._username,
                    password=self._password,
                    timeout=20,
                )
            else:
                await aiosmtplib.send(
                    msg,
                    hostname=self._host,
                    port=self._port,
                    start_tls=False,
                    username=self._username,
                    password=self._password,
                    timeout=20,
                )
            logger.info(
                "email_sent",
                to=recipient,
                subject=subject,
            )
        except Exception as exc:  # pragma: no cover
            logger.error(
                "email_send_failed",
                to=recipient,
                subject=subject,
                error=str(exc),
            )

    # ------------------------------------------------------------------ #
    # Template helpers
    # ------------------------------------------------------------------ #

    def render_template(
        self,
        template_name: str,
        context: Dict[str, object],
    ) -> str:
        """
        Render an email HTML template.

        Args:
            template_name: Filename under templates/email.
            context: Context variables.

        Returns:
            Rendered HTML string.
        """
        try:
            template = _env.get_template(template_name)
            return template.render(**context)
        except Exception as exc:
            logger.error(
                "email_template_render_failed",
                template=template_name,
                error=str(exc),
            )
            # Fallback: simple HTML with context dump
            return (
                "<html><body><pre>"
                + str({k: str(v) for k, v in context.items()})
                + "</pre></body></html>"
            )

    @staticmethod
    def guess_mime_type(filename: str) -> str:
        """
        Guess MIME type for attachment.

        Args:
            filename: Name of attachment.

        Returns:
            MIME type string.
        """
        mime, _ = mimetypes.guess_type(filename)
        return mime or "application/octet-stream"