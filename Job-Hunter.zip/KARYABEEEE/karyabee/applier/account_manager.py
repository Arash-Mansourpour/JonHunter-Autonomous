"""
Multi-account manager for autonomous applications in KARYABEEEE.

Features:
- Manages multiple accounts per platform (3-5 recommended).
- Rotation policy:
    - Rotate account every 15 applications or 24 hours (whichever comes first).
- Tracks:
    - Last used timestamp
    - Applications count for current window
    - Profile completeness (0-1)
- Cookie persistence:
    - Stores per-account cookies in JSON files under data/accounts/{platform}/{account}.json
    - Encryption boundary is documented; for now this module uses plain JSON.
      In production, file-level encryption should be handled by ops/FS layer.
- 2FA support:
    - TOTP secret field (string); code generation can be plugged in by caller.
- Safe for usage from workers:
    - Backed by Redis-based locks for minimal contention (best-effort).
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from karyabee.config import settings
from karyabee.logging_config import get_logger
from karyabee.utils.cache import RedisCache

logger = get_logger(__name__)

ACCOUNTS_DIR = Path("data/accounts")
ACCOUNTS_DIR.mkdir(parents=True, exist_ok=True)

# Use Redis for distributed locking + counters (best-effort)
_accounts_cache = RedisCache(prefix="karyabee:accounts:")


@dataclass
class PlatformAccount:
    """Represents a single automation account on a platform."""

    username: str
    profile_completeness: float = 1.0  # [0,1]
    totp_secret: Optional[str] = None
    last_used_ts: float = 0.0
    applications_in_window: int = 0

    @property
    def is_healthy(self) -> bool:
        """Basic heuristic for account health."""
        return self.profile_completeness >= 0.7


class AccountManager:
    """
    Multi-account rotation and state tracking.

    Usage:
        mgr = AccountManager("linkedin")
        account = mgr.get_next_account()
        # Use account.username + cookie file for automation
        mgr.mark_application_used(account)
    """

    def __init__(
        self,
        platform: str,
        rotation_threshold: int = 15,
        rotation_hours: int = 24,
    ) -> None:
        self.platform = platform
        self.rotation_threshold = rotation_threshold
        self.rotation_window_seconds = rotation_hours * 3600
        self._accounts: List[PlatformAccount] = self._load_accounts()

    # ------------------------------------------------------------------ #
    # Persistence helpers
    # ------------------------------------------------------------------ #

    @property
    def _platform_dir(self) -> Path:
        d = ACCOUNTS_DIR / self.platform
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _load_accounts(self) -> List[PlatformAccount]:
        """
        Load accounts from JSON files.

        Each account file:
            data/accounts/{platform}/{username}.json

        Fields:
            {
              "username": "...",
              "profile_completeness": 0.95,
              "totp_secret": "....",
              "last_used_ts": 0,
              "applications_in_window": 0
            }
        """
        accounts: List[PlatformAccount] = []
        try:
            for path in self._platform_dir.glob("*.json"):
                try:
                    with path.open("r", encoding="utf-8") as f:
                        data = json.load(f)
                    acc = PlatformAccount(
                        username=data["username"],
                        profile_completeness=float(
                            data.get("profile_completeness", 1.0)
                        ),
                        totp_secret=data.get("totp_secret"),
                        last_used_ts=float(data.get("last_used_ts", 0.0)),
                        applications_in_window=int(
                            data.get("applications_in_window", 0)
                        ),
                    )
                    accounts.append(acc)
                except Exception as exc:
                    logger.error(
                        "account_load_failed",
                        platform=self.platform,
                        file=str(path),
                        error=str(exc),
                    )
        except Exception as exc:  # pragma: no cover
            logger.error(
                "account_dir_scan_failed",
                platform=self.platform,
                error=str(exc),
            )

        # Sort by last_used_ts (oldest first)
        accounts.sort(key=lambda a: a.last_used_ts)
        logger.info(
            "account_manager_loaded",
            platform=self.platform,
            count=len(accounts),
        )
        return accounts

    def _save_account(self, account: PlatformAccount) -> None:
        """Persist single account to JSON."""
        try:
            path = self._platform_dir / f"{account.username}.json"
            with path.open("w", encoding="utf-8") as f:
                json.dump(asdict(account), f, ensure_ascii=False, indent=2)
        except Exception as exc:  # pragma: no cover
            logger.error(
                "account_save_failed",
                platform=self.platform,
                username=account.username,
                error=str(exc),
            )

    # ------------------------------------------------------------------ #
    # Selection logic
    # ------------------------------------------------------------------ #

    def get_next_account(self) -> Optional[PlatformAccount]:
        """
        Select next account based on rotation rules.

        Rules:
            - Prefer accounts with highest profile_completeness.
            - Avoid accounts that exceeded rotation_threshold within current window.
            - Reset window if last_used_ts is older than rotation_window_seconds.
        """
        if not self._accounts:
            logger.error("no_accounts_configured", platform=self.platform)
            return None

        now = time.time()
        # Rebuild list with updated windows
        candidates: List[PlatformAccount] = []
        for acc in self._accounts:
            # Reset window on age
            if now - acc.last_used_ts > self.rotation_window_seconds:
                acc.applications_in_window = 0
            if acc.applications_in_window < self.rotation_threshold and acc.is_healthy:
                candidates.append(acc)

        if not candidates:
            # All exhausted; fallback to least recently used
            candidates = sorted(self._accounts, key=lambda a: a.last_used_ts)

        # Score: (profile_completeness desc, last_used asc)
        candidates.sort(
            key=lambda a: (-a.profile_completeness, a.last_used_ts),
        )
        selected = candidates[0]
        logger.info(
            "account_selected_for_use",
            platform=self.platform,
            username=selected.username,
            applications_in_window=selected.applications_in_window,
        )
        return selected

    def mark_application_used(self, account: PlatformAccount) -> None:
        """
        Update account stats after successful application.

        - increments applications_in_window
        - updates last_used_ts
        - persists account state
        - updates Redis counters for observability
        """
        account.applications_in_window += 1
        account.last_used_ts = time.time()
        self._save_account(account)

        # Redis best-effort counter
        try:
            key = f"usage:{self.platform}:{account.username}"
            current = _accounts_cache.get(key) or 0
            _accounts_cache.set(key, int(current) + 1, ttl_seconds=7 * 24 * 3600)
        except Exception as exc:  # pragma: no cover
            logger.error(
                "account_usage_counter_failed",
                platform=self.platform,
                username=account.username,
                error=str(exc),
            )

    # ------------------------------------------------------------------ #
    # Cookies utilities
    # ------------------------------------------------------------------ #

    def get_cookies_path(self, account: PlatformAccount) -> str:
        """
        Return cookie file path for given account.

        This can be loaded by Selenium/Playwright to restore session.
        """
        return str(self._platform_dir / f"{account.username}.cookies.json")

    def load_cookies(self, account: PlatformAccount) -> Optional[List[Dict]]:
        """
        Load cookies JSON for automation libraries.

        Returns:
            List of cookie dicts, or None if missing.
        """
        path = Path(self.get_cookies_path(account))
        if not path.exists():
            return None
        try:
            with path.open("r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as exc:  # pragma: no cover
            logger.error(
                "account_cookies_load_failed",
                platform=self.platform,
                username=account.username,
                error=str(exc),
            )
            return None

    def save_cookies(self, account: PlatformAccount, cookies: List[Dict]) -> None:
        """
        Persist cookies JSON for given account.

        Args:
            account: PlatformAccount instance.
            cookies: Cookie list from browser context.
        """
        path = Path(self.get_cookies_path(account))
        try:
            with path.open("w", encoding="utf-8") as f:
                json.dump(cookies, f, ensure_ascii=False, indent=2)
        except Exception as exc:  # pragma: no cover
            logger.error(
                "account_cookies_save_failed",
                platform=self.platform,
                username=account.username,
                error=str(exc),
            )


# Convenience: cached managers per platform
_manager_cache: Dict[str, AccountManager] = {}


def get_account_manager(platform: str) -> AccountManager:
    """
    Get or create AccountManager for given platform.

    Args:
        platform: Platform key, e.g., "linkedin", "jobvision".

    Returns:
        AccountManager instance.
    """
    if platform not in _manager_cache:
        _manager_cache[platform] = AccountManager(platform=platform)
    return _manager_cache[platform]