"""
2Captcha-based CAPTCHA solver integration for KARYABEEEE.

Features:
- Supports:
    - Detection helper (frontends can call detect_captcha)
    - 2Captcha API integration (reCAPTCHA v2/v3 compatible)
- Enforces:
    - Daily spend limit (TWOCAPTCHA_MAX_DAILY_SPEND_USD)
    - Max number of solves per day (MAX_CAPTCHA_SOLVES_PER_DAY)
- Robust error handling:
    - Timeouts
    - API errors
    - Graceful degradation (fall back to manual notification)

Notes:
- No hardcoded API keys. Uses settings.twocaptcha_api_key.
- This module is intentionally conservative to avoid abuse and cost overruns.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Optional

import httpx

from karyabee.config import settings
from karyabee.logging_config import get_logger
from karyabee.utils.cache import RedisCache

logger = get_logger(__name__)

CAPTCHA_CACHE = RedisCache(prefix="karyabee:captcha:")
TWOCAPTCHA_ENDPOINT = "https://2captcha.com"
SOLVE_COST_USD = 0.002  # approximate per captcha; adjust if pricing changes


@dataclass
class CaptchaSolution:
    """Result of a CAPTCHA solving attempt."""

    success: bool
    token: Optional[str]
    error: Optional[str]


def _daily_spend_key() -> str:
    """Return Redis key for today's spend tracking."""
    day = time.strftime("%Y-%m-%d")
    return f"spend:{day}"


def _increment_daily_spend(amount_usd: float) -> float:
    """
    Increment estimated daily spend and return new total.

    Uses Redis to track spend; falls back to in-memory approximation disabled if Redis fails.
    """
    key = _daily_spend_key()
    try:
        current = CAPTCHA_CACHE.get(key) or 0.0
        new_total = float(current) + float(amount_usd)
        # TTL until end of day (~24h max)
        CAPTCHA_CACHE.set(key, new_total, ttl_seconds=24 * 60 * 60)
        return new_total
    except Exception as exc:  # pragma: no cover
        logger.error("captcha_spend_tracking_failed", error=str(exc))
        return 0.0  # fail-open; limit also enforced by count tracking


def _daily_solve_count_key() -> str:
    day = time.strftime("%Y-%m-%d")
    return f"count:{day}"


def _increment_daily_count() -> int:
    """Increment number of CAPTCHAs solved today."""
    key = _daily_solve_count_key()
    try:
        current = CAPTCHA_CACHE.get(key) or 0
        new_total = int(current) + 1
        CAPTCHA_CACHE.set(key, new_total, ttl_seconds=24 * 60 * 60)
        return new_total
    except Exception as exc:  # pragma: no cover
        logger.error("captcha_count_tracking_failed", error=str(exc))
        return 0


def _check_budget() -> bool:
    """
    Check if we are allowed to solve another captcha.

    Enforces:
    - Max daily spend from settings.twocaptcha_max_daily_spend_usd
    - Max daily solves from settings.max_captcha_solves_per_day
    """
    # Check count
    try:
        count = int(CAPTCHA_CACHE.get(_daily_solve_count_key()) or 0)
        if count >= settings.max_captcha_solves_per_day:
            logger.error(
                "captcha_daily_limit_reached",
                count=count,
                max=settings.max_captcha_solves_per_day,
            )
            return False
    except Exception:
        # On failure, be conservative: allow but log; this is rare.
        pass

    # Check spend
    try:
        spend = float(CAPTCHA_CACHE.get(_daily_spend_key()) or 0.0)
        if spend + SOLVE_COST_USD > settings.twocaptcha_max_daily_spend_usd:
            logger.error(
                "captcha_daily_spend_limit_reached",
                spend=spend,
                max=settings.twocaptcha_max_daily_spend_usd,
            )
            return False
    except Exception:
        pass

    return True


def detect_captcha(page) -> bool:
    """
    Naive CAPTCHA presence detector for Playwright/Selenium pages.

    Checks for:
    - Elements containing 'g-recaptcha', 'recaptcha', 'hcaptcha'
    - Iframes pointing to Google reCAPTCHA

    Args:
        page: Playwright or Selenium page object with .content() method.

    Returns:
        True if CAPTCHA likely present.
    """
    try:
        html = page.content()
        if any(s in html for s in ("g-recaptcha", "recaptcha/api.js", "hcaptcha.com")):
            return True
    except Exception:
        return False
    return False


def solve_recaptcha_v2(
    site_key: str,
    page_url: str,
    invisible: bool = False,
    timeout_seconds: int = 120,
) -> CaptchaSolution:
    """
    Solve reCAPTCHA v2 using 2Captcha.

    Args:
        site_key: Public reCAPTCHA site key.
        page_url: URL where CAPTCHA is located.
        invisible: Whether it's invisible reCAPTCHA.
        timeout_seconds: Max time to wait for solution.

    Returns:
        CaptchaSolution with token or error.
    """
    if not settings.twocaptcha_api_key:
        return CaptchaSolution(
            success=False,
            token=None,
            error="2Captcha API key not configured",
        )

    if not _check_budget():
        return CaptchaSolution(
            success=False,
            token=None,
            error="Daily CAPTCHA budget exhausted",
        )

    api_key = settings.twocaptcha_api_key.get_secret_value()
    client = httpx.Client(timeout=15.0)

    try:
        # Submit CAPTCHA
        params = {
            "key": api_key,
            "method": "userrecaptcha",
            "googlekey": site_key,
            "pageurl": page_url,
            "invisible": 1 if invisible else 0,
            "json": 1,
        }
        resp = client.get(f"{TWOCAPTCHA_ENDPOINT}/in.php", params=params)
        data = resp.json()
        if data.get("status") != 1:
            return CaptchaSolution(
                success=False,
                token=None,
                error=f"2Captcha in.php error: {data.get('request')}",
            )

        request_id = data["request"]
        # Poll for result
        start = time.time()
        while time.time() - start < timeout_seconds:
            time.sleep(5)
            res = client.get(
                f"{TWOCAPTCHA_ENDPOINT}/res.php",
                params={
                    "key": api_key,
                    "action": "get",
                    "id": request_id,
                    "json": 1,
                },
            )
            rdata = res.json()
            if rdata.get("status") == 1:
                token = rdata.get("request")
                # Update budget on success
                _increment_daily_spend(SOLVE_COST_USD)
                _increment_daily_count()
                logger.info("captcha_solved_successfully")
                return CaptchaSolution(
                    success=True,
                    token=token,
                    error=None,
                )
            if rdata.get("request") not in ("CAPCHA_NOT_READY", "CAPTCHA_NOT_READY"):
                # Permanent error
                logger.error(
                    "captcha_solve_failed_permanent",
                    error=str(rdata.get("request")),
                )
                return CaptchaSolution(
                    success=False,
                    token=None,
                    error=f"2Captcha error: {rdata.get('request')}",
                )

        # Timeout
        logger.error("captcha_solve_timeout", page_url=page_url)
        return CaptchaSolution(
            success=False,
            token=None,
            error="2Captcha solve timeout",
        )
    except Exception as exc:
        logger.error("captcha_solve_exception", error=str(exc))
        return CaptchaSolution(
            success=False,
            token=None,
            error=str(exc),
        )
    finally:
        try:
            client.close()
        except Exception:
            pass