"""
Playwright-based autonomous application engine for KARYABEEEE.

Features:
- Stealthy browser automation for job applications.
- Form detection by labels/names/placeholders for:
    - full name
    - email
    - phone
    - resume upload
    - cover letter
    - portfolio/website
- Handles dynamic forms (React/Vue) with robust selectors.
- Randomized delays (2-5s) between critical actions.
- Retries (up to 3 attempts) on transient failures.
- Screenshot capture on error.
- Basic CAPTCHA detection (delegated to captcha_solver).
- Integrates with BaseApplier and ApplicationPayload/ApplicationResult.

This module is designed for headless operation inside Docker and for
easy mocking in tests. All hard-coded secrets are avoided; configuration
comes from env (via settings, if needed later).
"""

from __future__ import annotations

import os
import random
import time
from pathlib import Path
from typing import List, Optional

from playwright.sync_api import Browser, Error, Page, Playwright, sync_playwright

from karyabee.applier.base import ApplicationPayload, ApplicationResult, BaseApplier
from karyabee.applier.captcha_solver import detect_captcha
from karyabee.config import settings
from karyabee.logging_config import get_logger
from karyabee.utils.validators import sanitize_text

logger = get_logger(__name__)

SCREENSHOT_DIR = Path("screenshots")
SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)


class PlaywrightApplier(BaseApplier):
    """
    Generic Playwright-based applier.

    For each job's application_url:
    - Launch a stealthy Chromium instance.
    - Navigate to URL.
    - Try to locate common form fields and submit.
    - Capture screenshot and logs.
    """

    def __init__(self, platform: str = "generic") -> None:
        super().__init__(platform=platform)

    # ------------------------------------------------------------------ #
    # Public main entry
    # ------------------------------------------------------------------ #

    def apply(self, payload: ApplicationPayload) -> ApplicationResult:
        """
        Apply to a job using Playwright automation.

        Args:
            payload: ApplicationPayload with job, resume, cover_letter, etc.

        Returns:
            ApplicationResult describing outcome.
        """
        application_url = payload.job.application_url
        if not application_url:
            return ApplicationResult(
                success=False,
                confirmation_number=None,
                screenshot_path=None,
                error="Missing application URL",
            )

        for attempt in range(1, 4):
            try:
                logger.info(
                    "playwright_apply_attempt",
                    attempt=attempt,
                    job_id=str(payload.job.id),
                    url=application_url,
                )
                return self._apply_once(payload, application_url)
            except Exception as exc:  # pragma: no cover - robust retry
                logger.error(
                    "playwright_apply_attempt_failed",
                    attempt=attempt,
                    job_id=str(payload.job.id),
                    url=application_url,
                    error=str(exc),
                )
                time.sleep(random.uniform(2.0, 4.0))

        # If we reach here, all attempts failed
        screenshot = self._error_screenshot_name(payload.job.id, suffix="fatal")
        return ApplicationResult(
            success=False,
            confirmation_number=None,
            screenshot_path=screenshot,
            error="All Playwright attempts failed",
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    def _apply_once(
        self,
        payload: ApplicationPayload,
        url: str,
    ) -> ApplicationResult:
        """Run a single application attempt."""
        with sync_playwright() as p:
            browser = self._launch_browser(p)
            page = browser.new_page()
            try:
                page.goto(url, wait_until="domcontentloaded", timeout=30000)
                self._random_delay()

                if detect_captcha(page):
                    screenshot = self._capture_screenshot(page, payload.job.id, "captcha")
                    return ApplicationResult(
                        success=False,
                        confirmation_number=None,
                        screenshot_path=screenshot,
                        error="CAPTCHA detected; manual intervention required",
                    )

                self._fill_form(page, payload)
                self._submit_form(page)

                # Wait briefly for any confirmation content
                self._random_delay()
                confirmation = self._extract_confirmation(page)

                screenshot = self._capture_screenshot(
                    page,
                    payload.job.id,
                    "success" if confirmation else "submitted",
                )

                logger.info(
                    "playwright_apply_success",
                    job_id=str(payload.job.id),
                    url=url,
                    confirmation=confirmation or "",
                )
                return ApplicationResult(
                    success=True,
                    confirmation_number=confirmation,
                    screenshot_path=screenshot,
                    error=None,
                )
            except Exception as exc:
                screenshot = self._capture_screenshot(page, payload.job.id, "error")
                logger.error(
                    "playwright_apply_error",
                    job_id=str(payload.job.id),
                    url=url,
                    error=str(exc),
                    screenshot=screenshot,
                )
                return ApplicationResult(
                    success=False,
                    confirmation_number=None,
                    screenshot_path=screenshot,
                    error=str(exc),
                )
            finally:
                try:
                    browser.close()
                except Exception:
                    pass

    def _launch_browser(self, p: Playwright) -> Browser:
        """Launch Chromium with stealth-like options."""
        args: List[str] = [
            "--disable-blink-features=AutomationControlled",
            "--disable-dev-shm-usage",
            "--no-sandbox",
        ]
        browser = p.chromium.launch(
            headless=True,
            args=args,
        )
        return browser

    @staticmethod
    def _random_delay() -> None:
        """Sleep 2-5 seconds to mimic human interaction."""
        time.sleep(random.uniform(2.0, 5.0))

    def _fill_form(self, page: Page, payload: ApplicationPayload) -> None:
        """
        Fill out common form fields using heuristic locators.

        This is intentionally generic; platform-specific overrides can refine.
        """
        job = payload.job

        # Text helpers
        def safe_fill(selector: str, value: str) -> None:
            try:
                if not value:
                    return
                el = page.query_selector(selector)
                if el:
                    el.fill(value)
                    self._random_delay()
            except Error:
                # Non-fatal
                return

        # Heuristic: locate by label, placeholder, name, or id
        def fill_candidates(candidates, value: str) -> None:
            for c in candidates:
                try:
                    el = page.query_selector(c)
                    if el:
                        el.fill(value)
                        self._random_delay()
                        return
                except Error:
                    continue

        candidate_name = "Arash Mansourpour"
        candidate_email = "arash_mansourpour@proton.me"
        candidate_phone = "+989203600363"
        portfolio_url = payload.portfolio_url or "https://arshava.framer.ai"

        # Name
        fill_candidates(
            [
                "input[name*='name']",
                "input[id*='name']",
                "input[placeholder*='Name']",
                "input[placeholder*='نام']",
            ],
            candidate_name,
        )

        # Email
        fill_candidates(
            [
                "input[type='email']",
                "input[name*='email']",
                "input[id*='email']",
                "input[placeholder*='Email']",
            ],
            candidate_email,
        )

        # Phone
        fill_candidates(
            [
                "input[type='tel']",
                "input[name*='phone']",
                "input[id*='phone']",
                "input[placeholder*='Phone']",
                "input[placeholder*='موبایل']",
            ],
            candidate_phone,
        )

        # Portfolio / website
        fill_candidates(
            [
                "input[name*='website']",
                "input[name*='portfolio']",
                "input[placeholder*='Portfolio']",
                "input[placeholder*='Website']",
            ],
            portfolio_url,
        )

        # Cover letter / message
        if payload.cover_letter_text:
            cover = sanitize_text(payload.cover_letter_text, max_length=5000)
            fill_candidates(
                [
                    "textarea[name*='cover']",
                    "textarea[name*='message']",
                    "textarea[placeholder*='Cover']",
                    "textarea[placeholder*='چرا']",
                ],
                cover,
            )

        # Extra fields
        for key, value in payload.extra_fields.items():
            if not value:
                continue
            # simplistic mapping: try to find input/textarea with matching name/id substring
            selector = f"input[name*='{key}'], input[id*='{key}'], textarea[name*='{key}']"
            try:
                el = page.query_selector(selector)
                if el:
                    el.fill(str(value))
                    self._random_delay()
            except Error:
                continue

        # Resume upload
        self._upload_resume(page, payload.resume_path)

    def _upload_resume(self, page: Page, resume_path: str) -> None:
        """Upload resume file if file input is present."""
        if not resume_path or not os.path.exists(resume_path):
            logger.error("playwright_resume_missing", resume_path=resume_path)
            return
        try:
            file_inputs = page.query_selector_all("input[type='file']")
            if not file_inputs:
                # Try common labels that trigger hidden file inputs
                upload_triggers = page.query_selector_all(
                    "button:has-text('Upload'), button:has-text('رزومه'), label:has-text('Upload')"
                )
                for t in upload_triggers:
                    try:
                        t.click()
                        time.sleep(1.0)
                        file_inputs = page.query_selector_all("input[type='file']")
                        if file_inputs:
                            break
                    except Error:
                        continue
            for fi in file_inputs:
                try:
                    fi.set_input_files(resume_path)
                    self._random_delay()
                    logger.info("playwright_resume_uploaded", path=resume_path)
                    return
                except Error:
                    continue
        except Error as exc:
            logger.error("playwright_resume_upload_error", error=str(exc))

    def _submit_form(self, page: Page) -> None:
        """Attempt to submit the application form."""
        # Look for common submit button patterns
        selectors = [
            "button[type='submit']",
            "button:has-text('Apply')",
            "button:has-text('Submit')",
            "button:has-text('ارسال')",
            "button:has-text('درخواست')",
            "input[type='submit']",
        ]
        for sel in selectors:
            try:
                btn = page.query_selector(sel)
                if btn:
                    btn.click()
                    self._random_delay()
                    return
            except Error:
                continue
        # If nothing clicked, best-effort: do nothing; caller will handle failure.

    def _extract_confirmation(self, page: Page) -> Optional[str]:
        """
        Extract a confirmation message or number if present.

        Returns:
            String confirmation or None.
        """
        try:
            html = page.content()
            soup = None
            try:
                from bs4 import BeautifulSoup as _BS

                soup = _BS(html, "lxml")
            except Exception:
                pass

            if soup:
                text = soup.get_text(" ", strip=True)
            else:
                text = html

            # Simple heuristics
            for token in [
                "confirmation",
                "submitted",
                "thank you",
                "application received",
                "با موفقیت ثبت شد",
            ]:
                if token.lower() in text.lower():
                    return "auto-detected"
        except Exception as exc:
            logger.error("playwright_extract_confirmation_failed", error=str(exc))
        return None

    def _capture_screenshot(
        self,
        page: Page,
        job_id,
        suffix: str,
    ) -> Optional[str]:
        """
        Capture a screenshot to aid debugging.

        Returns:
            Relative path to screenshot, or None on failure.
        """
        try:
            filename = self._error_screenshot_name(job_id, suffix)
            page.screenshot(path=filename, full_page=True)
            return filename
        except Exception as exc:  # pragma: no cover
            logger.error("playwright_screenshot_failed", error=str(exc))
            return None

    @staticmethod
    def _error_screenshot_name(job_id, suffix: str) -> str:
        return str(SCREENSHOT_DIR / f"job_{job_id}_{suffix}.png")


# Singleton instance for reuse
playwright_applier = PlaywrightApplier(platform="generic")