"""
Base application engine abstractions for KARYABEEEE.

Provides:
- Standardized interface for all platform-specific appliers.
- Common context object including job, resume, cover letter, account info.
- Robust logging hooks and error contracts.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Dict, Optional

from karyabee.logging_config import get_logger
from karyabee.models import Application, Job

logger = get_logger(__name__)


@dataclass
class ApplicationPayload:
    """
    Encapsulates all information needed to submit an application form.

    Fields:
        job: Job ORM object.
        resume_path: Filesystem path to resume to upload.
        cover_letter_text: Generated cover letter text (if required).
        portfolio_url: Optional portfolio URL.
        extra_fields: Platform-specific extra data.
    """

    job: Job
    resume_path: str
    cover_letter_text: Optional[str]
    portfolio_url: Optional[str]
    extra_fields: Dict[str, str]


@dataclass
class ApplicationResult:
    """
    Result of an application attempt.

    Fields:
        success: Whether submission appears successful.
        confirmation_number: Reference code if any.
        screenshot_path: Path to screenshot captured during/after submission.
        error: Error message if failed.
    """

    success: bool
    confirmation_number: Optional[str]
    screenshot_path: Optional[str]
    error: Optional[str]


class BaseApplier(ABC):
    """
    Abstract base for automatic job appliers.

    Implementations should:
    - Be idempotent (safe to retry with same payload).
    - Avoid leaking PII in logs.
    """

    platform: str

    def __init__(self, platform: str) -> None:
        self.platform = platform

    @abstractmethod
    def apply(self, payload: ApplicationPayload) -> ApplicationResult:
        """
        Execute the application flow for a given job.

        Implementations must:
        - Handle browser automation / HTTP flows.
        - Capture screenshot on error.
        - Return ApplicationResult with as much detail as possible.
        """
        raise NotImplementedError

    @staticmethod
    def update_application_model(
        application: Application,
        result: ApplicationResult,
        account_used: str,
    ) -> None:
        """
        Update an Application ORM instance with result info.

        Args:
            application: Application model to update.
            result: ApplicationResult from applier.
            account_used: Identifier of the account/profile used.

        Side effects:
            Mutates `application` fields; caller is responsible for committing session.
        """
        application.account_used = account_used
        application.confirmation_number = result.confirmation_number
        application.screenshot_path = result.screenshot_path
        application.notes = (
            (application.notes or "") + f"\nApplied via {account_used} on {application.applied_at}."
        ).strip()
        if not result.success and result.error:
            application.notes = (
                (application.notes or "") + f"\nError: {result.error}"
            ).strip()

        logger.info(
            "application_model_updated_from_result",
            application_id=str(application.id),
            job_id=str(application.job_id),
            success=result.success,
            platform=account_used,
        )