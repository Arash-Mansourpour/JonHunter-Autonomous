"""
LinkedIn Jobs scraper for KARYABEEEE.

Requirements:
- Uses Selenium with cookie persistence to handle authenticated scraping.
- Supports:
    - Logged-in session via saved cookies (encrypted store can be added later).
    - Extraction of:
        - title
        - company
        - location
        - description
        - posted_date (best-effort)
        - application_url
        - easy_apply (bool)
- Respects:
    - Anti-detection basics (delays, scrolling, randomized waits).
    - Max 200 jobs per run (via BaseJobScraper limits).
- Fallback:
    - If Selenium / environment is unavailable, logs error and returns [].

Security:
- No credentials stored in code.
- Relies on external cookie file or Selenium session prepared by ops.
"""

from __future__ import annotations

import datetime as dt
import json
import os
import random
import time
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional

from bs4 import BeautifulSoup

from karyabee.config import settings
from karyabee.logging_config import get_logger
from karyabee.scrapers.base import BaseJobScraper, parse_text

logger = get_logger(__name__)

# Optional Selenium imports guarded to avoid runtime errors if not installed
try:  # pragma: no cover - environment dependent
    from selenium import webdriver
    from selenium.common.exceptions import WebDriverException
    from selenium.webdriver.chrome.options import Options as ChromeOptions
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
except Exception:  # pragma: no cover
    webdriver = None  # type: ignore[assignment]
    WebDriverException = Exception  # type: ignore[assignment]
    ChromeOptions = object  # type: ignore[assignment]
    By = object  # type: ignore[assignment]
    WebDriverWait = object  # type: ignore[assignment]
    EC = object  # type: ignore[assignment]


@dataclass
class LinkedInConfig:
    """LinkedIn scraping configuration."""

    cookies_path: str = "data/linkedin_cookies.json"
    jobs_url: str = "https://www.linkedin.com/jobs/search/?keywords=ai%20engineer"
    max_pages: int = 5


class LinkedInScraper(BaseJobScraper):
    """
    LinkedIn job scraper using Selenium.

    Uses BaseJobScraper only for normalizing output and dedupe logic.
    HTTP fetching is driven by Selenium-rendered HTML.
    """

    source = "linkedin"

    def __init__(self, config: Optional[LinkedInConfig] = None) -> None:
        self._cfg = config or LinkedInConfig()
        super().__init__(max_jobs_per_run=settings.rate_limit_jobs_per_source_per_run)

    # ------------------------------------------------------------------ #
    # LinkedIn-specific internals
    # ------------------------------------------------------------------ #

    def _init_driver(self):
        """
        Initialize Selenium WebDriver in headless/stealth mode.

        Returns:
            WebDriver instance.

        Raises:
            RuntimeError: If selenium/webdriver not available.
        """
        if webdriver is None:
            raise RuntimeError("selenium is not installed in this environment")

        try:
            options = ChromeOptions()
            options.add_argument("--headless=new")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--disable-blink-features=AutomationControlled")
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            options.add_experimental_option("useAutomationExtension", False)

            driver = webdriver.Chrome(options=options)  # type: ignore[call-arg]
            driver.set_window_size(1400, 900)
            # Small random delay to reduce fingerprint consistency
            time.sleep(random.uniform(1.5, 3.0))
            return driver
        except Exception as exc:
            logger.error("linkedin_driver_init_failed", error=str(exc))
            raise RuntimeError("Failed to initialize Selenium driver") from exc

    def _load_cookies(self, driver) -> None:
        """
        Load LinkedIn cookies from JSON file to maintain logged-in session.

        Expects cookies exported in standard Selenium format.
        """
        path = self._cfg.cookies_path
        if not os.path.exists(path):
            logger.warn(
                "linkedin_cookies_missing",
                path=path,
            )
            return

        try:
            with open(path, "r", encoding="utf-8") as f:
                cookies = json.load(f)
            driver.get("https://www.linkedin.com")
            time.sleep(2.0)
            for cookie in cookies:
                # Ensure required fields exist
                if "name" in cookie and "value" in cookie:
                    cookie_data = {
                        "name": cookie["name"],
                        "value": cookie["value"],
                        "domain": cookie.get("domain", ".linkedin.com"),
                        "path": cookie.get("path", "/"),
                    }
                    if cookie.get("secure") is not None:
                        cookie_data["secure"] = cookie["secure"]
                    if cookie.get("expiry") is not None:
                        cookie_data["expiry"] = cookie["expiry"]
                    try:
                        driver.add_cookie(cookie_data)
                    except Exception:
                        continue
            logger.info("linkedin_cookies_loaded", path=path)
        except Exception as exc:
            logger.error("linkedin_cookies_load_failed", error=str(exc))

    # ------------------------------------------------------------------ #
    # BaseJobScraper abstract implementations
    # ------------------------------------------------------------------ #

    def _listing_urls(self) -> Iterable[str]:
        """
        Listing URLs driven via LinkedIn search query.

        For Selenium, we navigate and paginate instead of using httpx here.
        """
        # We won't use this in Selenium-based flow; required by abstract base.
        yield self._cfg.jobs_url

    def _parse_listings(self, html: str) -> List[Dict[str, Optional[str]]]:
        """
        Not used in Selenium-driven flow; defined to satisfy abstract contract.
        """
        soup = BeautifulSoup(html, "lxml")
        items: List[Dict[str, Optional[str]]] = []
        for card in soup.select("li.jobs-search-results__list-item"):
            try:
                title_el = card.select_one("a.job-card-list__title")
                company_el = card.select_one("a.job-card-container__company-name")
                loc_el = card.select_one("span.job-card-container__metadata-item")

                title = title_el.get_text(strip=True) if title_el else None
                company = company_el.get_text(strip=True) if company_el else None
                location = loc_el.get_text(strip=True) if loc_el else None

                href = (
                    title_el["href"]
                    if title_el is not None and title_el.has_attr("href")
                    else None
                )
                if href and not href.startswith("http"):
                    href = "https://www.linkedin.com" + href

                if not (title and company and href):
                    continue

                items.append(
                    {
                        "title": title,
                        "company": company,
                        "location": location,
                        "description": None,
                        "requirements": None,
                        "posted_date": None,
                        "application_url": href,
                    }
                )
            except Exception as exc:
                logger.error("linkedin_parse_listings_html_failed", error=str(exc))
        return items

    # ------------------------------------------------------------------ #
    # Selenium-driven scraping
    # ------------------------------------------------------------------ #

    def scrape(self) -> List[Dict[str, object]]:  # type: ignore[override]
        """
        Selenium-based scraping pipeline.

        Returns:
            List of normalized job dicts, capped by max_jobs_per_run.

        Behavior:
        - Attempts to use cookies for authenticated session.
        - Scrolls/paginates search results.
        - Extracts job cards and full descriptions for selected subset.
        """
        if webdriver is None:
            logger.error(
                "linkedin_selenium_not_available",
                detail="Install selenium and a webdriver to enable LinkedIn scraping.",
            )
            return []

        driver = None
        jobs: List[Dict[str, object]] = []
        try:
            driver = self._init_driver()
            self._load_cookies(driver)

            driver.get(self._cfg.jobs_url)
            # Wait for listings container
            try:
                WebDriverWait(driver, 15).until(  # type: ignore[attr-defined]
                    EC.presence_of_element_located(  # type: ignore[attr-defined]
                        (By.CSS_SELECTOR, "ul.scaffold-layout__list-container")
                    )
                )
            except Exception as exc:
                logger.error("linkedin_initial_load_timeout", error=str(exc))

            page = 1
            while page <= self._cfg.max_pages and len(jobs) < self.max_jobs_per_run:
                time.sleep(random.uniform(2.0, 4.0))
                self._scroll_results(driver)

                html = driver.page_source
                soup = BeautifulSoup(html, "lxml")
                cards = soup.select("li.jobs-search-results__list-item")

                for card in cards:
                    if len(jobs) >= self.max_jobs_per_run:
                        break
                    job = self._extract_job_from_card(driver, card)
                    if job:
                        jobs.append(job)

                # Try to go to next page
                if not self._goto_next_page(driver):
                    break
                page += 1

            logger.info("linkedin_scraper_completed", jobs=len(jobs), pages=page)
            return jobs
        except WebDriverException as exc:  # pragma: no cover
            logger.error("linkedin_webdriver_exception", error=str(exc))
            return []
        except Exception as exc:  # pragma: no cover
            logger.error("linkedin_scraper_unexpected_error", error=str(exc))
            return []
        finally:
            if driver is not None:
                try:
                    driver.quit()
                except Exception:
                    pass

    def _scroll_results(self, driver) -> None:
        """
        Scroll the results panel slowly to load more jobs.
        """
        try:
            for _ in range(5):
                driver.execute_script(
                    "window.scrollTo(0, document.body.scrollHeight);"
                )
                time.sleep(random.uniform(0.8, 1.5))
        except Exception as exc:  # pragma: no cover
            logger.error("linkedin_scroll_failed", error=str(exc))

    def _goto_next_page(self, driver) -> bool:
        """
        Attempt to click Next pagination button.

        Returns:
            True if navigation attempted, False otherwise.
        """
        try:
            next_buttons = driver.find_elements(
                By.CSS_SELECTOR, "button[aria-label='Next'],button[aria-label='بعدی']"
            )
            for btn in next_buttons:
                if btn.is_enabled():
                    btn.click()
                    return True
        except Exception as exc:  # pragma: no cover
            logger.error("linkedin_next_page_failed", error=str(exc))
        return False

    def _extract_job_from_card(self, driver, card) -> Optional[Dict[str, object]]:
        """
        Extract job fields from a LinkedIn job card.

        Also detects Easy Apply jobs.
        """
        try:
            title_el = card.select_one("a.job-card-list__title")
            company_el = card.select_one("a.job-card-container__company-name")
            loc_el = card.select_one("span.job-card-container__metadata-item")

            title = title_el.get_text(strip=True) if title_el else None
            company = company_el.get_text(strip=True) if company_el else None
            location = loc_el.get_text(strip=True) if loc_el else None

            href = (
                title_el["href"]
                if title_el is not None and title_el.has_attr("href")
                else None
            )
            if href and not href.startswith("http"):
                href = "https://www.linkedin.com" + href
            application_url = href

            if not (title and company and application_url):
                return None

            easy_apply = bool(
                card.select_one("span[aria-label*='Easy Apply'],span[aria-label*='درخواست آسان']")
            )

            # Click card to load side panel for full description (best-effort)
            description_text = None
            try:
                if title_el:
                    driver.execute_script("arguments[0].click();", title_el)
                    time.sleep(random.uniform(1.0, 2.0))
                    panel_html = driver.page_source
                    panel_soup = BeautifulSoup(panel_html, "lxml")
                    desc_panel = panel_soup.select_one(
                        "div.jobs-description__content"
                    ) or panel_soup.select_one(
                        "div.jobs-box__html-content"
                    )
                    if desc_panel:
                        description_text = parse_text(str(desc_panel))
            except Exception:
                # Non-fatal; leave description as None
                pass

            posted_date = self._best_effort_posted_date(card)

            job = {
                "title": title,
                "company": company,
                "location": location,
                "salary_min": None,
                "salary_max": None,
                "currency": None,
                "description": description_text,
                "requirements": {"easy_apply": easy_apply},
                "posted_date": posted_date,
                "application_url": application_url,
                "source": self.source,
            }
            return job
        except Exception as exc:  # pragma: no cover
            logger.error("linkedin_extract_job_failed", error=str(exc))
            return None

    @staticmethod
    def _best_effort_posted_date(card) -> Optional[dt.date]:
        """
        Roughly parse posted date from card text.
        """
        try:
            text = card.get_text(" ", strip=True).lower()
            today = dt.date.today()
            if "today" in text or "امروز" in text:
                return today
            if "yesterday" in text or "دیروز" in text:
                return today - dt.timedelta(days=1)
            # Patterns like "3 days ago"
            import re

            m = re.search(r"(\d+)\s+day", text)
            if m:
                days = int(m.group(1))
                return today - dt.timedelta(days=days)
        except Exception:
            pass
        return None


def scrape_linkedin() -> List[Dict[str, object]]:
    """
    Convenience entrypoint for Celery tasks.

    Returns:
        List of normalized job dictionaries.
    """
    scraper = LinkedInScraper()
    return scraper.scrape()