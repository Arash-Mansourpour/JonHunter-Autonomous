"""
Quera Jobs scraper for KARYABEEEE.

Scrapes:
- https://quera.org/jobs (engineering/AI roles)
Extracts:
- title
- company
- location
- description
- posted_date (best-effort)
- application_url

Notes:
- Uses BaseJobScraper utilities (anti-detection, dedupe, raw HTML caching).
- Uses ProxyManager for optional proxy routing.
"""

from __future__ import annotations

import datetime as dt
from typing import Dict, Iterable, List, Optional

from bs4 import BeautifulSoup

from karyabee.logging_config import get_logger
from karyabee.scrapers.base import BaseJobScraper, parse_text
from karyabee.scrapers.proxy_manager import proxy_manager

logger = get_logger(__name__)


class QueraScraper(BaseJobScraper):
    """Concrete scraper for Quera Jobs."""

    source = "quera"
    BASE_URL = "https://quera.org/jobs"

    def _listing_urls(self) -> Iterable[str]:
        """
        Generate listing URLs.

        Quera uses infinite scroll / pagination. For simplicity,
        request the first 10 pages via ?page=N if supported.
        """
        yield self.BASE_URL
        for page in range(2, 11):
            yield f"{self.BASE_URL}?page={page}"

    def _parse_listings(self, html: str) -> List[Dict[str, Optional[str]]]:
        """
        Parse Quera jobs listing HTML.

        Returns:
            List of raw job dictionaries.
        """
        soup = BeautifulSoup(html, "lxml")
        cards = (
            soup.select("div.job-card")
            or soup.select("div.job-item")
            or soup.select("a[href*='/job/']")
        )
        results: List[Dict[str, Optional[str]]] = []

        for card in cards:
            try:
                # Title
                title_el = (
                    card.select_one(".job-title")
                    or card.select_one("h2")
                    or (card if card.name == "a" else None)
                )
                title = (title_el.get_text(strip=True) if title_el else "") or None

                # Company
                company_el = (
                    card.select_one(".company-name")
                    or card.select_one(".company")
                )
                company = (
                    company_el.get_text(strip=True) if company_el else ""
                ) or "Quera Partner"

                # Location
                loc_el = (
                    card.select_one(".job-location")
                    or card.select_one(".location")
                )
                location = loc_el.get_text(strip=True) if loc_el else None

                # Link
                href = None
                link_el = (
                    card.select_one("a[href*='/job/']")
                    if card.name != "a"
                    else card
                )
                if link_el is not None and link_el.has_attr("href"):
                    href = link_el["href"]
                if href and not href.startswith("http"):
                    href = "https://quera.org" + href
                application_url = href

                # Short description
                desc_el = (
                    card.select_one(".job-description")
                    or card.select_one(".description")
                )
                description = (
                    desc_el.get_text(" ", strip=True) if desc_el else None
                )

                # Date
                date_el = (
                    card.select_one(".job-date")
                    or card.select_one(".date")
                )
                posted_date = self._parse_posted_date(
                    date_el.get_text(strip=True) if date_el else ""
                )

                if not (title and application_url):
                    continue

                full_desc, requirements = self._fetch_detail(application_url)

                results.append(
                    {
                        "title": title,
                        "company": company,
                        "location": location,
                        "salary_min": None,
                        "salary_max": None,
                        "currency": None,
                        "description": full_desc or description,
                        "requirements": requirements,
                        "posted_date": posted_date,
                        "application_url": application_url,
                    }
                )
            except Exception as exc:
                logger.error("quera_parse_card_failed", error=str(exc))

        return results

    @staticmethod
    def _parse_posted_date(text: str) -> Optional[dt.date]:
        """
        Best-effort parse posted date.

        Supports:
        - 'today', 'دیروز'
        - simple dd/mm/yyyy formats
        """
        if not text:
            return None
        t = text.strip().lower()
        today = dt.date.today()
        if "امروز" in t or "today" in t:
            return today
        if "دیروز" in t or "yesterday" in t:
            return today - dt.timedelta(days=1)
        for fmt in ("%Y/%m/%d", "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
            try:
                return dt.datetime.strptime(t, fmt).date()
            except ValueError:
                continue
        return None

    def _fetch_detail(
        self,
        url: str,
    ) -> (Optional[str], Optional[Dict[str, str]]):
        """
        Fetch job detail page for full description.

        Returns:
            (description_text, requirements_dict)
        """
        try:
            proxy = proxy_manager.get_proxy()
            html = self._get(url, proxy=proxy)
            text = parse_text(html)
            return text, {"raw": text[:2000]}
        except Exception as exc:
            logger.error(
                "quera_detail_fetch_failed",
                url=url,
                error=str(exc),
            )
            return None, None


def scrape_quera() -> List[Dict[str, object]]:
    """
    Convenience wrapper to run QueraScraper.

    Returns:
        List of normalized job dicts.
    """
    scraper = QueraScraper()
    return scraper.scrape()