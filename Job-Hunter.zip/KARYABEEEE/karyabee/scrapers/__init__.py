"""Job board scrapers for KARYABEEEE.

This package exposes:
- BaseJobScraper: common scraper base with anti-detection and robustness
- Concrete scrapers for major job platforms
"""

from karyabee.scrapers.base import BaseJobScraper
from karyabee.scrapers.jobvision import JobVisionScraper, scrape_jobvision
from karyabee.scrapers.irantalent import IranTalentScraper, scrape_irantalent
from karyabee.scrapers.linkedin import LinkedInScraper, scrape_linkedin
from karyabee.scrapers.quera import QueraScraper, scrape_quera

__all__ = [
    "BaseJobScraper",
    "JobVisionScraper",
    "scrape_jobvision",
    "IranTalentScraper",
    "scrape_irantalent",
    "LinkedInScraper",
    "scrape_linkedin",
    "QueraScraper",
    "scrape_quera",
]