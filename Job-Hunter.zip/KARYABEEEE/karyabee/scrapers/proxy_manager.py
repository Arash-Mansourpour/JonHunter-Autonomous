"""
Proxy manager for KARYABEEEE scrapers.

Features:
- Uses residential proxy URL from settings.proxy_url when configured
- Rotates proxy selection every N requests (settings.proxy_rotation_requests)
- Health checks proxies before use
- Falls back to direct connection on repeated failures
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

import httpx

from karyabee.config import settings
from karyabee.logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class ProxyState:
    """Internal state for proxy rotation."""

    current_proxy: Optional[str]
    use_direct: bool
    request_count: int
    last_checked: float
    failures: int


class ProxyManager:
    """
    Simple proxy manager.

    Assumes a single upstream proxy endpoint (residential gateway) provided via settings.proxy_url.
    """

    def __init__(self) -> None:
        self._enabled: bool = bool(settings.proxy_url and settings.proxy_rotation)
        self._rotation_every: int = max(1, settings.proxy_rotation_requests)
        self._state = ProxyState(
            current_proxy=settings.proxy_url if self._enabled else None,
            use_direct=not self._enabled,
            request_count=0,
            last_checked=0.0,
            failures=0,
        )
        logger.info(
            "proxy_manager_initialized",
            enabled=self._enabled,
            proxy_url="configured" if settings.proxy_url else "none",
        )

    def _health_check(self, proxy: str, timeout: float = 5.0) -> bool:
        """
        Lightweight proxy health check.

        Args:
            proxy: Proxy URL.
            timeout: Max time for HEAD request.

        Returns:
            True if proxy appears healthy, False otherwise.
        """
        test_url = "https://www.google.com/generate_204"
        try:
            with httpx.Client(
                proxies={"http://": proxy, "https://": proxy},
                timeout=timeout,
                follow_redirects=True,
            ) as client:
                resp = client.get(test_url)
                ok = resp.status_code in (200, 204)
                if not ok:
                    logger.warn(
                        "proxy_health_check_bad_status",
                        proxy="hidden",
                        status=resp.status_code,
                    )
                return ok
        except Exception as exc:  # pragma: no cover - environment dependent
            logger.error(
                "proxy_health_check_failed",
                proxy="hidden",
                error=str(exc),
            )
            return False

    def _maybe_rotate(self) -> None:
        """
        Rotate or validate proxy based on request count and failures.
        """
        if self._state.use_direct or not self._enabled:
            return

        self._state.request_count += 1

        if self._state.request_count % self._rotation_every != 0:
            return

        now = time.time()
        # Throttle health checks to avoid spamming
        if now - self._state.last_checked < 10:
            return

        self._state.last_checked = now
        proxy = self._state.current_proxy
        if not proxy:
            self._state.use_direct = True
            return

        if not self._health_check(proxy):
            self._state.failures += 1
            if self._state.failures >= 3:
                logger.error(
                    "proxy_marked_unhealthy_fallback_to_direct",
                    failures=self._state.failures,
                )
                self._state.use_direct = True
                self._state.current_proxy = None
        else:
            # Reset failures on success
            self._state.failures = 0

    def report_failure(self) -> None:
        """
        Report downstream failure when using proxy.

        Used by scrapers when they detect proxy-related issues.
        """
        if not self._enabled or self._state.use_direct:
            return
        self._state.failures += 1
        if self._state.failures >= 3:
            logger.error(
                "proxy_consecutive_failures_switch_to_direct",
                failures=self._state.failures,
            )
            self._state.use_direct = True
            self._state.current_proxy = None

    def get_proxy(self) -> Optional[str]:
        """
        Get proxy URL to use for the next request, or None for direct.

        Performs lazy rotation/health-check as needed.

        Returns:
            Proxy URL or None.
        """
        if not self._enabled:
            return None
        self._maybe_rotate()
        if self._state.use_direct:
            return None
        return self._state.current_proxy


# Eager singleton
proxy_manager = ProxyManager()