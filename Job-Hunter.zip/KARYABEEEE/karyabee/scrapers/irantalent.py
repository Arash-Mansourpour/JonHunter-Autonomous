"""
IranTalent scraper for KARYABEEEE.

Scrapes:
- https://www.irantalent.com/jobs
Extracts:
- title
- company
- location
- salary (if visible)
- description / requirements
- posted_date (best-effort)
- application_url
Pagination:
- Up to 10 pages.

Notes:
- Uses BaseJobScraper utilities for HTTP, dedupe, anti-detection.
- Uses ProxyManager when configured.
- Designed to be resilient to minor DOM changes.
"""

from __future__ import annotations

import datetime as dt
from typing import Dict, Iterable, List, Optional

from bs4 import BeautifulSoup

from karyabee.logging_config import get_logger
from karyabee.scrapers.base import BaseJobScraper, parse_text
from karyabee.scrapers.proxy_manager import proxy_manager

logger = get_logger(__name__)


class IranTalentScraper(BaseJobScraper):
    """Concrete scraper for IranTalent."""

    source = "irantalent"

    BASE_URL = "https://www.irantalent.com/jobs"

    def _listing_urls(self) -> Iterable[str]:
        """
        Generate paginated job listing URLs (max 10 pages).
        """
        yield self.BASE_URL
        for page in range(2, 11):
            yield f"{self.BASE_URL}?page={page}"

    def _parse_listings(self, html: str) -> List[Dict[str, Optional[str]]]:
        """
        Parse list of jobs from IranTalent HTML.

        Returns:
            List of raw job dictionaries.
        """
        soup = BeautifulSoup(html, "lxml")
        cards = (
            soup.select("div.job-item")
            or soup.select("div.job-card")
            or soup.select("div.search-result-item")
        )
        results: List[Dict[str, Optional[str]]] = []

        for card in cards:
            try:
                title_el = (
                    card.select_one("a.job-title")
                    or card.select_one("a.job-title-link")
                    or card.select_one("a[href*='/job/']")
                )
                title = (title_el.get_text(strip=True) if title_el else "") or None

                company_el = (
                    card.select_one(".company-name")
                    or card.select_one("a[href*='/company/']")
                )
                company = (
                    company_el.get_text(strip=True) if company_el else ""
                ) or None

                loc_el = (
                    card.select_one(".job-location")
                    or card.select_one(".location")
                )
                location = (
                    loc_el.get_text(strip=True) if loc_el else ""
                ) or None

                href = (
                    title_el["href"]
                    if title_el is not None and title_el.has_attr("href")
                    else None
                )
                if href and not href.startswith("http"):
                    href = "https://www.irantalent.com" + href
                application_url = href

                # Extract short snippet
                desc_el = (
                    card.select_one(".job-description")
                    or card.select_one(".description")
                )
                description = (
                    desc_el.get_text(" ", strip=True) if desc_el else None
                )

                # Posted date
                date_el = (
                    card.select_one(".posting-date")
                    or card.select_one(".date")
                )
                posted_date = self._parse_posted_date(
                    date_el.get_text(strip=True) if date_el else ""
                )

                if not (title and company and application_url):
                    continue

                full_desc, requirements = self._fetch_detail(application_url)

                results.append(
                    {
                        "title": title,
                        "company": company,
                        "location": location,
                        "salary_min": None,
                        "salary_max": None,
                        "currency": None,
                        "description": full_desc or description,
                        "requirements": requirements,
                        "posted_date": posted_date,
                        "application_url": application_url,
                    }
                )
            except Exception as exc:
                logger.error(
                    "irantalent_parse_card_failed",
                    error=str(exc),
                )

        return results

    @staticmethod
    def _parse_posted_date(text: str) -> Optional[dt.date]:
        """
        Try to parse posted date from visible label.

        Supports:
        - 'Today', 'Yesterday'
        - dd/mm/yyyy, yyyy/mm/dd
        """
        if not text:
            return None
        t = text.strip()
        today = dt.date.today()
        if "today" in t.lower():
            return today
        if "yesterday" in t.lower():
            return today - dt.timedelta(days=1)
        for fmt in ("%Y/%m/%d", "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
            try:
                return dt.datetime.strptime(t, fmt).date()
            except ValueError:
                continue
        return None

    def _fetch_detail(
        self,
        url: str,
    ) -> (Optional[str], Optional[Dict[str, str]]):
        """
        Fetch job detail page to extract richer description/requirements.

        Returns:
            (description_text, requirements_dict)
        """
        try:
            proxy = proxy_manager.get_proxy()
            html = self._get(url, proxy=proxy)
            text = parse_text(html)
            # Simple heuristic segmentation
            # Keep first N chars as description; could later split by headings.
            return text, {"raw": text[:2000]}
        except Exception as exc:
            logger.error(
                "irantalent_detail_fetch_failed",
                url=url,
                error=str(exc),
            )
            return None, None


def scrape_irantalent() -> List[Dict[str, object]]:
    """
    Convenience entrypoint for Celery tasks.

    Returns:
        List of normalized job dictionaries.
    """
    scraper = IranTalentScraper()
    return scraper.scrape()