"""
Base scraper abstractions for KARYABEEEE.

Features:
- Abstract interface for job scrapers
- Anti-detection:
  - Randomized delays (1-4s)
  - Rotating user agents
  - Optional proxy support via ProxyManager
- Rate limiting: max 200 jobs per source per run (from settings)
- Duplicate detection via SHA256 of application_url + title + company
- Raw HTML snapshot storage in Redis (TTL: 7 days)
- Robust error handling with up to 3 retries for transient errors
"""

from __future__ import annotations

import hashlib
import random
import time
from abc import ABC, abstractmethod
from typing import Dict, Iterable, List, Optional

import httpx
from bs4 import BeautifulSoup
from fake_useragent import UserAgent

from karyabee.config import settings
from karyabee.logging_config import get_logger
from karyabee.utils.cache import RedisCache

logger = get_logger(__name__)

RAW_HTML_TTL_SECONDS = 7 * 24 * 60 * 60


class ScraperError(Exception):
    """Base error for scraper failures."""


class BlockedError(ScraperError):
    """Target signaled blocking (e.g., 403, 429, explicit anti-bot)."""


class TemporaryError(ScraperError):
    """Transient error (timeouts, 5xx); safe to retry."""


class PermanentError(ScraperError):
    """Non-retryable error (404, hard parsing issues, etc.)."""


class BaseJobScraper(ABC):
    """
    Abstract base class for all job scrapers.

    Implementations must:
    - Provide `source` attribute (short slug, e.g., "jobvision")
    - Implement `_fetch_listing_pages` and `_parse_listings`
    """

    source: str

    def __init__(
        self,
        max_jobs_per_run: Optional[int] = None,
        client: Optional[httpx.Client] = None,
        cache: Optional[RedisCache] = None,
    ) -> None:
        """
        Initialize scraper.

        Args:
            max_jobs_per_run: Maximum jobs to return in a single run.
            client: Optional httpx.Client for dependency injection/testing.
            cache: RedisCache for raw HTML storage.
        """
        if not getattr(self, "source", None):
            raise ValueError("Scraper must define `source` attribute")
        self.max_jobs_per_run = (
            max_jobs_per_run or settings.rate_limit_jobs_per_source_per_run
        )
        self._ua = UserAgent()
        self._cache = cache or RedisCache(prefix=f"karyabee:scrape:{self.source}:")
        self._client = client or httpx.Client(timeout=20.0, follow_redirects=True)
        self._seen_hashes: set[str] = set()

    # ------------------------------------------------------------------ #
    # Abstracts
    # ------------------------------------------------------------------ #

    @abstractmethod
    def _listing_urls(self) -> Iterable[str]:
        """
        Yield listing page URLs for this source (e.g., pagination URLs).

        Implementations should enforce their own max page limits.
        """
        raise NotImplementedError

    @abstractmethod
    def _parse_listings(
        self, html: str
    ) -> List[Dict[str, Optional[str]]]:
        """
        Parse a listing page HTML into a list of raw job dicts.

        Each job dict SHOULD contain:
            - title
            - company
            - location
            - salary (if exists)
            - description
            - requirements
            - posted_date
            - application_url
        """
        raise NotImplementedError

    # ------------------------------------------------------------------ #
    # HTTP helpers with anti-detection
    # ------------------------------------------------------------------ #

    def _headers(self) -> Dict[str, str]:
        """
        Return realistic headers with rotating user agent.

        Notes:
        - Uses fake-useragent but constrained to modern desktop browsers.
        - Keep headers consistent with a typical browser (zero-cost stealth).
        """
        try:
            ua = self._ua.random
        except Exception:  # pragma: no cover - fallback if provider fails
            ua = (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/123.0.0.0 Safari/537.36"
            )

        return {
            "User-Agent": ua,
            "Accept-Language": "en-US,en;q=0.9,fa-IR;q=0.8",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Encoding": "gzip, deflate, br",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        }

    def _apply_delay(self) -> None:
        """
        Human-like delay between requests (zero-cost anti-detection).

        - Base: normal distribution around ~2s.
        - Jitter: never less than 0.5s.
        - Peak hours (09-17 local server time): ~1.5x slower.
        """
        # Use time.localtime to avoid importing datetime here.
        now = time.localtime()
        base = max(0.5, random.gauss(2.0, 0.5))
        if 9 <= now.tm_hour <= 17:
            base *= 1.5
        time.sleep(base)

    def _hash_job(self, title: str, company: str, application_url: str) -> str:
        """Return SHA256 hash used to deduplicate jobs."""
        h = hashlib.sha256()
        h.update((title or "").strip().lower().encode("utf-8"))
        h.update(b"::")
        h.update((company or "").strip().lower().encode("utf-8"))
        h.update(b"::")
        h.update((application_url or "").strip().lower().encode("utf-8"))
        return h.hexdigest()

    def _store_raw_html(self, key: str, html: str) -> None:
        """Store raw HTML in Redis for observability/debugging."""
        try:
            self._cache.set(f"html:{key}", html, ttl_seconds=RAW_HTML_TTL_SECONDS)
        except Exception as exc:  # pragma: no cover
            logger.error(
                "scraper_store_raw_html_failed",
                source=self.source,
                key=key,
                error=str(exc),
            )

    def _get(
        self,
        url: str,
        proxy: Optional[str] = None,
        max_retries: int = 3,
    ) -> str:
        """
        Perform GET request with retries, anti-detection, and logging.

        Args:
            url: Target URL.
            proxy: Optional HTTP proxy URL.
            max_retries: Number of attempts before failing.

        Returns:
            Response text.

        Raises:
            ScraperError: On persistent network or HTTP errors.
        """
        last_exc: Optional[Exception] = None
        for attempt in range(1, max_retries + 1):
            try:
                # Apply human-like delay before each attempt
                self._apply_delay()

                kwargs: Dict[str, object] = {"headers": self._headers()}
                if proxy:
                    kwargs["proxies"] = {"http://": proxy, "https://": proxy}

                resp = self._client.get(url, **kwargs)  # type: ignore[arg-type]

                # Classify status codes for better upstream handling.
                status = resp.status_code
                if status in (403, 429):
                    raise BlockedError(f"blocked status={status} url={url}")
                if status >= 500:
                    raise TemporaryError(f"server error status={status} url={url}")
                if status == 404:
                    raise PermanentError(f"not found status=404 url={url}")
                if status >= 400:
                    raise ScraperError(f"http status={status} url={url}")

                text = resp.text
                self._store_raw_html(f"{hash(url)}", text)
                return text

            except PermanentError as exc:
                # Immediate abort for non-retryable errors.
                last_exc = exc
                logger.error(
                    "scraper_http_get_permanent_error",
                    source=self.source,
                    url=url,
                    attempt=attempt,
                    error=str(exc),
                )
                break
            except BlockedError as exc:
                last_exc = exc
                logger.error(
                    "scraper_http_get_blocked",
                    source=self.source,
                    url=url,
                    attempt=attempt,
                    error=str(exc),
                )
                # Do not hammer; break so caller can change strategy/persona.
                break
            except TemporaryError as exc:
                last_exc = exc
                logger.warning(
                    "scraper_http_get_temporary_error",
                    source=self.source,
                    url=url,
                    attempt=attempt,
                    error=str(exc),
                )
                # Exponential backoff: 2^attempt seconds (bounded).
                backoff = min(2**attempt, 60)
                time.sleep(backoff)
            except Exception as exc:
                last_exc = exc
                logger.error(
                    "scraper_http_get_unexpected_error",
                    source=self.source,
                    url=url,
                    attempt=attempt,
                    error=str(exc),
                )
        raise ScraperError(
            f"Failed to fetch {url} after {max_retries} attempts: {last_exc}"
        )

    # ------------------------------------------------------------------ #
    # Public scrape orchestrator
    # ------------------------------------------------------------------ #

    def scrape(self) -> List[Dict[str, object]]:
        """
        Run scraper for this source.

        Returns:
            List of normalized job dicts, capped by max_jobs_per_run.
        """
        jobs: List[Dict[str, object]] = []
        try:
            for url in self._listing_urls():
                if len(jobs) >= self.max_jobs_per_run:
                    break
                html = self._get(url)
                raw_listings = self._parse_listings(html)
                for raw in raw_listings:
                    if len(jobs) >= self.max_jobs_per_run:
                        break
                    title = (raw.get("title") or "").strip()
                    company = (raw.get("company") or "").strip()
                    app_url = (raw.get("application_url") or "").strip()
                    if not title or not company or not app_url:
                        continue
                    h = self._hash_job(title, company, app_url)
                    if h in self._seen_hashes:
                        continue
                    self._seen_hashes.add(h)

                    job = {
                        "title": title,
                        "company": company,
                        "location": (raw.get("location") or "").strip() or None,
                        "salary_min": raw.get("salary_min"),
                        "salary_max": raw.get("salary_max"),
                        "currency": raw.get("currency"),
                        "description": raw.get("description") or "",
                        "requirements": raw.get("requirements"),
                        "posted_date": raw.get("posted_date"),
                        "application_url": app_url,
                        "source": self.source,
                    }
                    jobs.append(job)
        except Exception as exc:
            logger.error(
                "scraper_run_failed",
                source=self.source,
                error=str(exc),
            )
        logger.info(
            "scraper_completed",
            source=self.source,
            jobs=len(jobs),
        )
        return jobs


def parse_text(html: str) -> str:
    """
    Helper: extract visible text from HTML (UTF-8 / Persian-friendly).

    Args:
        html: Raw HTML.

    Returns:
        Cleaned text.
    """
    soup = BeautifulSoup(html, "lxml")
    for script in soup(["script", "style", "noscript"]):
        script.extract()
    text = soup.get_text(separator=" ", strip=True)
    return text