"""
JobVision scraper for KARYABEEEE.

Scrapes:
- https://jobvision.ir/jobs
- Extracts:
    - title
    - company
    - location
    - salary (if visible)
    - description / requirements text
    - posted_date (best-effort)
    - application_url
- Handles pagination up to 10 pages
- Persian UTF-8 text safe

Implementation notes:
- Uses BaseJobScraper HTTP helpers for anti-detection
- Parsing is resilient to minor DOM changes; relies on semantic class names/attributes
"""

from __future__ import annotations

import datetime as dt
from typing import Dict, Iterable, List, Optional

from bs4 import BeautifulSoup

from karyabee.logging_config import get_logger
from karyabee.scrapers.base import BaseJobScraper, parse_text
from karyabee.scrapers.proxy_manager import proxy_manager

logger = get_logger(__name__)


class JobVisionScraper(BaseJobScraper):
    """Concrete scraper for JobVision."""

    source = "jobvision"

    BASE_URL = "https://jobvision.ir/jobs"

    def _listing_urls(self) -> Iterable[str]:
        """
        Generate paginated job listing URLs.

        Max 10 pages as per requirements.
        """
        # First page (no page param)
        yield self.BASE_URL
        # Subsequent pages with ?page=2...
        for page in range(2, 11):
            yield f"{self.BASE_URL}?page={page}"

    def _parse_listings(
        self,
        html: str,
    ) -> List[Dict[str, Optional[str]]]:
        """
        Parse JobVision listing page HTML.

        Returns:
            List of raw job dictionaries.
        """
        soup = BeautifulSoup(html, "lxml")
        cards = soup.select("div.job-item, div.c-jobCard, div.job-card") or []
        results: List[Dict[str, Optional[str]]] = []

        for card in cards:
            try:
                # Title
                title_el = (
                    card.select_one("a.job-title")
                    or card.select_one("a.c-jobCard__title-link")
                    or card.select_one("a[href*='/job/']")
                )
                title = (title_el.get_text(strip=True) if title_el else "") or None

                # Company
                company_el = (
                    card.select_one(".company-name")
                    or card.select_one(".c-jobCard__company-name")
                    or card.select_one("a[href*='/company/']")
                )
                company = (company_el.get_text(strip=True) if company_el else "") or None

                # Location
                loc_el = (
                    card.select_one(".job-location")
                    or card.select_one(".c-jobCard__location")
                )
                location = (loc_el.get_text(strip=True) if loc_el else "") or None

                # Application URL
                href = title_el["href"] if title_el and title_el.has_attr("href") else None
                if href and not href.startswith("http"):
                    href = "https://jobvision.ir" + href
                application_url = href

                # Short description / meta
                desc_el = (
                    card.select_one(".job-description")
                    or card.select_one(".c-jobCard__description")
                    or card.select_one(".c-jobCard__intro")
                )
                description = (
                    desc_el.get_text(" ", strip=True) if desc_el else None
                )

                # Posted date best-effort
                date_el = (
                    card.select_one(".job-date")
                    or card.select_one(".c-jobCard__publish-time")
                )
                posted_date = self._parse_posted_date(
                    date_el.get_text(strip=True) if date_el else ""
                )

                if not (title and company and application_url):
                    continue

                # For richer description, optionally fetch job detail lazily
                # within budget using proxy manager.
                full_desc, requirements = self._fetch_detail(application_url)

                results.append(
                    {
                        "title": title,
                        "company": company,
                        "location": location,
                        "salary_min": None,
                        "salary_max": None,
                        "currency": None,
                        "description": full_desc or description,
                        "requirements": requirements,
                        "posted_date": posted_date,
                        "application_url": application_url,
                    }
                )
            except Exception as exc:
                logger.error(
                    "jobvision_parse_card_failed",
                    error=str(exc),
                )

        return results

    @staticmethod
    def _parse_posted_date(text: str) -> Optional[dt.date]:
        """
        Best-effort parse of posted date from Persian/relative text.
        """
        if not text:
            return None
        text = text.strip()
        today = dt.date.today()
        # Very rough patterns (can be refined for Persian localization)
        if "امروز" in text or "today" in text.lower():
            return today
        if "دیروز" in text or "yesterday" in text.lower():
            return today - dt.timedelta(days=1)
        # Numeric date like 2025/01/31
        for fmt in ("%Y/%m/%d", "%Y-%m-%d", "%d/%m/%Y"):
            try:
                return dt.datetime.strptime(text, fmt).date()
            except ValueError:
                continue
        return None

    def _fetch_detail(
        self,
        url: str,
    ) -> (Optional[str], Optional[Dict[str, str]]):
        """
        Optionally fetch job detail page for richer description and requirements.

        Respects:
        - Proxy manager for residential routing
        - Error handling without breaking main scrape
        """
        try:
            proxy = proxy_manager.get_proxy()
            html = self._get(url, proxy=proxy)
            text = parse_text(html)
            # Simple heuristic: treat entire page text as description;
            # future: split into sections.
            return text, {"raw": text[:2000]}
        except Exception as exc:
            logger.error(
                "jobvision_detail_fetch_failed",
                url=url,
                error=str(exc),
            )
            return None, None


# Convenience function for Celery tasks
def scrape_jobvision() -> List[Dict[str, object]]:
    """
    Run JobVision scraper and return job dictionaries.
    """
    scraper = JobVisionScraper()
    return scraper.scrape()