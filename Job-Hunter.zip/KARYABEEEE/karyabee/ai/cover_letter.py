"""
Cover letter generator for KARYABEEEE.

Requirements:
- 250-350 words
- Company research and pain-point matching (based on job description text)
- STAR-style impact narratives
- AI detection resistance:
  - Vary sentence length
  - Natural tone, small imperfections
- Gemini-powered with robust fallbacks
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict

from karyabee.ai.gemini_client import gemini_client
from karyabee.logging_config import get_logger

logger = get_logger(__name__)


CANDIDATE_NAME = "Arash Mansourpour"
CANDIDATE_EMAIL = "arash_mansourpour@proton.me"
CANDIDATE_PORTFOLIO = "https://arshava.framer.ai"
CANDIDATE_GITHUB = "https://github.com/Arash-Mansourpour"

BASE_PROFILE_SNIPPET = (
    "Senior AI Developer & Neural Architecture Specialist focused on Transformer-based NLP, "
    "LLMs (BERT/GPT/T5/LLaMA), RAG systems, and self-supervised learning with production impact."
)


@dataclass
class CoverLetterContext:
    """Context data for generating a cover letter."""

    company: str
    role_title: str
    job_description: str
    source: str


def _extract_company_insights(text: str) -> Dict[str, str]:
    """
    Derive light-weight insights from job description as hints.

    This is heuristic; Gemini will refine further.
    """
    lowered = text.lower()
    focus = []
    if "nlp" in lowered or "language model" in lowered or "llm" in lowered:
        focus.append("advanced NLP/LLM research and deployment")
    if "production" in lowered or "scalable" in lowered or "reliability" in lowered:
        focus.append("robust, production-grade AI systems")
    if "research" in lowered:
        focus.append("research-driven experimentation and publication")
    if "startup" in lowered or "fast-paced" in lowered:
        focus.append("fast iteration and ownership in lean teams")
    if "persian" in lowered or "فارسی" in lowered:
        focus.append("Persian-language NLP and localized models")
    if not focus:
        focus.append("end-to-end ownership of impactful AI products")

    pain = []
    if "optimiz" in lowered:
        pain.append("performance and cost optimization for inference")
    if "pipeline" in lowered or "data" in lowered:
        pain.append("reliable data/ML pipelines and observability")
    if "evaluation" in lowered or "metrics" in lowered:
        pain.append("rigorous evaluation frameworks for models")

    return {
        "focus": ", ".join(dict.fromkeys(focus)),
        "pain_points": ", ".join(dict.fromkeys(pain)) if pain else "",
    }


def _fallback_cover_letter(ctx: CoverLetterContext) -> str:
    """
    Deterministic, ATS-safe cover letter used if Gemini is unavailable.

    Length target ~260-300 words.
    """
    insights = _extract_company_insights(ctx.job_description)
    focus = insights["focus"]
    pain = insights["pain_points"]

    lines = []
    lines.append(f"Dear {ctx.company} hiring team,")
    lines.append("")
    lines.append(
        f"I am writing to express my interest in the {ctx.role_title} position. "
        f"As a {BASE_PROFILE_SNIPPET} I have spent the last few years designing "
        f"and shipping systems that move beyond toy models and actually solve real problems."
    )
    if focus:
        lines.append(
            f"What caught my attention in your description is the emphasis on {focus}. "
            "This aligns closely with my experience building RAG pipelines, tuning Transformers, "
            "and hardening them for real-world users."
        )
    if pain:
        lines.append(
            f"In previous work I faced similar challenges around {pain}, and delivered solutions "
            "that improved reliability and clarity for business stakeholders."
        )
    lines.append(
        "Highlights from my background include deploying Persian NLP systems with strong BLEU/ROUGE metrics, "
        "optimizing GPU usage for large models, and architecting LLM-based assistants that run reliably in "
        "production. I enjoy combining clean engineering with careful experimentation."
    )
    lines.append(
        "I value direct communication, fast feedback loops, and working closely with product and research teams. "
        "If you are looking for someone who can read the papers, write the code, debug the failures, and own the "
        "results end-to-end, I would be glad to contribute."
    )
    lines.append(
        f"You can find selected work at {CANDIDATE_PORTFOLIO} and {CANDIDATE_GITHUB}. "
        "Thank you for your time and consideration."
    )
    lines.append("")
    lines.append(f"Best regards,")
    lines.append(f"{CANDIDATE_NAME}")
    return "\n".join(lines)


def generate_cover_letter(ctx: CoverLetterContext) -> str:
    """
    Generate a tailored cover letter using Gemini with fallbacks.

    Ensures:
    - 250-350 words where possible
    - Natural style, varied sentence lengths, light imperfections
    - References portfolio/GitHub
    """
    prompt = f"""
You are generating a tailored cover letter for a senior AI/LLM engineer.

Candidate:
- Name: {CANDIDATE_NAME}
- Email: {CANDIDATE_EMAIL}
- Profile: {BASE_PROFILE_SNIPPET}
- Portfolio: {CANDIDATE_PORTFOLIO}
- GitHub: {CANDIDATE_GITHUB}

Target role:
- Title: {ctx.role_title}
- Company: {ctx.company}
- Source: {ctx.source}

Job description:
\"\"\"{ctx.job_description[:4000]}\"
\"\"\"

Guidelines:
- Length: 250-350 words.
- Tone: confident, sharp, slightly conversational, not robotic.
- Use specific signals from the job description (stack, research focus, product challenges).
- Include at least one STAR-style micro story (Situation, Task, Action, Result).
- Mention relevant strengths: Transformers, LLMs, RAG, evaluation, production systems, Persian NLP when relevant.
- Vary sentence length and rhythm. A few short sentences. A few longer ones.
- Introduce subtle human-like imperfections: one or two minor style quirks or non-critical repetitions.
- Avoid overusing cliches like "passionate", "dynamic", "cutting-edge".
- Avoid generic fluff. Every sentence should either signal competence or fit with the team.
- End with a direct but polite call to action.
- Write in first person singular.
- Do NOT include a subject line.
- Do NOT include placeholders like [Company].

Return ONLY the letter body. No Markdown, no bullet points.
"""
    try:
        resp = gemini_client.generate_content(prompt, use_cache=False)
        letter = (resp.text or "").strip()

        # Safety/length checks
        words = re.findall(r"\w+", letter)
        if len(words) < 220 or len(words) > 380:
            logger.info(
                "cover_letter_length_adjust",
                words=len(words),
            )
            # Soft adjust: if too short/long, trust fallback
            return _fallback_cover_letter(ctx)

        # Ensure signature present
        if CANDIDATE_NAME not in letter:
            letter += f"\n\nBest regards,\n{CANDIDATE_NAME}"

        return letter
    except Exception as exc:
        logger.error(
            "cover_letter_generation_failed",
            error=str(exc),
            company=ctx.company,
            role=ctx.role_title,
        )
        return _fallback_cover_letter(ctx)