"""
Gemini API client wrapper for KARYABEEEE.

Features:
- Centralized configuration from settings
- Rate limiting: 60 req/min (configurable via settings.gemini_max_rpm)
- Redis caching for deterministic prompts (24h TTL)
- Retry with exponential backoff (3 attempts)
- Fallback from primary to fallback model on failures
- Quota monitoring hook (integrated with metrics)

Notes:
- Uses google-generativeai library.
- This client is intentionally minimal and robust; all callers should go through it.
"""

from __future__ import annotations

import hashlib
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

import google.generativeai as genai
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from karyabee.config import settings
from karyabee.logging_config import get_logger
from karyabee.metrics import set_gemini_quota_remaining, track_gemini_latency
from karyabee.utils.cache import RedisCache

logger = get_logger(__name__)


@dataclass
class GeminiResponse:
    """Lightweight wrapper for generated content."""

    text: str


class GeminiRateLimiter:
    """
    Simple per-process rate limiter for Gemini.

    Enforces at most `max_rpm` requests per rolling 60-second window.
    This is a coarse safety net; upstream quotas still apply.
    """

    def __init__(self, max_rpm: int) -> None:
        self.max_rpm = max_rpm
        self._lock = threading.Lock()
        self._window_start = time.time()
        self._count = 0

    def acquire(self) -> None:
        """Block until the request is allowed."""
        with self._lock:
            now = time.time()
            # Reset window if older than 60s
            if now - self._window_start >= 60.0:
                self._window_start = now
                self._count = 0

            if self._count < self.max_rpm:
                self._count += 1
                return

            # Need to sleep until next window
            sleep_for = 60.0 - (now - self._window_start)
            if sleep_for > 0:
                logger.info(
                    "gemini_rate_limit_sleep",
                    sleep_for=round(sleep_for, 2),
                    max_rpm=self.max_rpm,
                )
                time.sleep(sleep_for)
            # Start new window
            self._window_start = time.time()
            self._count = 1


class GeminiClient:
    """
    Production-grade Gemini API client.

    Usage:
        from karyabee.ai.gemini_client import gemini_client
        resp = gemini_client.generate_content("prompt")
        print(resp.text)
    """

    def __init__(self) -> None:
        if not settings.gemini_api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured")
        genai.configure(api_key=settings.gemini_api_key.get_secret_value())
        self.primary_model = settings.gemini_model
        self.fallback_model = settings.gemini_fallback_model
        self.cache = RedisCache(prefix="karyabee:gemini:")
        self.rate_limiter = GeminiRateLimiter(settings.gemini_max_rpm)
        logger.info(
            "gemini_client_initialized",
            model=self.primary_model,
            fallback_model=self.fallback_model,
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _cache_key(prompt: str, model: str, temperature: float) -> str:
        h = hashlib.sha256()
        h.update(prompt.encode("utf-8"))
        h.update(f"|{model}|{temperature}".encode("utf-8"))
        return h.hexdigest()

    def _call_model(self, prompt: str, model: str, temperature: float) -> str:
        """
        Low-level invocation of Gemini model.

        Separated for easier mocking in tests.
        """
        self.rate_limiter.acquire()
        with track_gemini_latency():
            gen_model = genai.GenerativeModel(model)
            resp = gen_model.generate_content(prompt)
        # google-generativeai returns a rich object with .text or .candidates
        if hasattr(resp, "text") and resp.text:
            return str(resp.text)
        if getattr(resp, "candidates", None):
            parts = []
            for c in resp.candidates:
                if getattr(c, "content", None) and getattr(c.content, "parts", None):
                    for p in c.content.parts:
                        if getattr(p, "text", None):
                            parts.append(p.text)
            if parts:
                return "\n".join(parts)
        # Fallback to string representation
        return str(resp)

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=8),
        retry=retry_if_exception_type(Exception),
        reraise=True,
    )
    def generate_content(
        self,
        prompt: str,
        model: Optional[str] = None,
        temperature: float = 0.4,
        use_cache: bool = True,
    ) -> GeminiResponse:
        """
        Generate text content from prompt.

        Args:
            prompt: Prompt text.
            model: Optional model override.
            temperature: Sampling temperature.
            use_cache: If True, use 24h Redis cache.

        Returns:
            GeminiResponse with .text

        Raises:
            Exception if all retries (and fallback) fail.
        """
        effective_model = model or self.primary_model
        cache_key = self._cache_key(prompt, effective_model, temperature)

        if use_cache:
            cached = self.cache.get(cache_key)
            if isinstance(cached, dict) and "text" in cached:
                return GeminiResponse(text=str(cached["text"]))

        try:
            text = self._call_model(prompt, effective_model, temperature)
        except Exception as primary_exc:
            logger.error(
                "gemini_primary_failed",
                model=effective_model,
                error=str(primary_exc),
            )
            # Try fallback model once inside retry context
            try:
                text = self._call_model(prompt, self.fallback_model, temperature)
                effective_model = self.fallback_model
            except Exception as fallback_exc:
                logger.error(
                    "gemini_fallback_failed",
                    model=self.fallback_model,
                    error=str(fallback_exc),
                )
                # Propagate to tenacity retry
                raise

        # Quota monitoring hook (very rough estimate)
        set_gemini_quota_remaining(max(0.0, float(settings.gemini_max_rpm * 60 - 1)))

        resp = GeminiResponse(text=text)

        if use_cache and text:
            try:
                # 24h TTL
                self.cache.set(cache_key, {"text": text}, ttl_seconds=24 * 60 * 60)
            except Exception as exc:  # pragma: no cover
                logger.error("gemini_cache_set_failed", error=str(exc))

        logger.info(
            "gemini_generate_content_success",
            model=effective_model,
        )
        return resp


# Eager singleton for convenience
gemini_client = GeminiClient()