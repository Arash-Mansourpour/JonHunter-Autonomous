"""
Interview callback probability predictor for KARYABEEEE.

Requirements:
- LightGBM model-based scoring
- Features:
    - match_score
    - skills_overlap
    - experience_gap
    - company_size (encoded)
    - salary_delta
    - location_match
    - application_speed
- Predict probability in [0, 1]
- Auto-apply decision: suggest apply if prob > 0.25

Design:
- Uses a small built-in LightGBM model (trained offline or rule-approximated).
- If LightGBM or model loading fails, falls back to deterministic heuristic.
- Implemented to be:
    - Side-effect free (no DB writes)
    - Testable (pure function + injectable model)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from lightgbm import LGBMClassifier  # type: ignore[import-untyped]

from karyabee.logging_config import get_logger

logger = get_logger(__name__)


@dataclass
class InterviewFeatures:
    """Feature vector for interview probability prediction."""

    match_score: float
    skills_overlap: float  # 0-1
    experience_gap: float  # candidate_years - required_years (can be negative)
    company_size: Optional[str]
    salary_delta: Optional[float]  # offered_mid - expected_mid (normalized or absolute)
    location_match: float  # 0-1
    application_speed_hours: Optional[float]  # hours since posting; lower is better


@dataclass
class InterviewPrediction:
    """Prediction result."""

    probability: float
    recommend_apply: bool
    model_used: str


class _HeuristicModel:
    """
    Deterministic fallback when LightGBM is unavailable.

    Encodes domain knowledge about hiring likelihood.
    """

    def predict_proba(self, X: np.ndarray) -> np.ndarray:  # type: ignore[override]
        probs = []
        for row in X:
            (
                match_score,
                skills_overlap,
                exp_gap,
                company_code,
                salary_delta,
                loc_match,
                app_speed,
            ) = row

            # Base from match_score
            p = (match_score / 100.0) * 0.5

            # Skills overlap strongly influences
            p += skills_overlap * 0.3

            # Experience: small negative gap acceptable, large negative penalized
            if exp_gap < -3:
                p -= 0.15
            elif exp_gap < -1:
                p -= 0.08
            elif exp_gap >= 1:
                p += 0.05

            # Company size preference is weak prior
            if company_code in (1, 2):  # small/medium/startup
                p += 0.03

            # Salary delta: if candidate expectation way above, lower prob slightly
            if salary_delta is not None:
                if salary_delta < -1000:
                    p -= 0.05
                elif salary_delta > 0:
                    p += 0.02

            # Location / remote fit
            p += (loc_match - 0.5) * 0.2

            # Application speed: early applicants have slight edge
            if app_speed is not None:
                if app_speed <= 24:
                    p += 0.05
                elif app_speed > 240:
                    p -= 0.05

            p = max(0.01, min(0.95, p))
            probs.append([1.0 - p, p])
        return np.array(probs, dtype=float)


class InterviewPredictor:
    """
    Wrapper around LightGBM model with heuristic fallback.
    """

    def __init__(self, model: Optional[LGBMClassifier] = None) -> None:
        """
        Initialize predictor.

        Args:
            model: Pre-loaded LightGBM model (for DI/tests). If None, use heuristic.
        """
        self._model = model or self._load_default_model()
        self._model_name = (
            "lightgbm" if isinstance(self._model, LGBMClassifier) else "heuristic"
        )

    @staticmethod
    def _encode_company_size(size: Optional[str]) -> int:
        if not size:
            return 0
        s = size.lower()
        if any(k in s for k in ["startup", "<50", "1-10", "11-50"]):
            return 1
        if any(k in s for k in ["50-200", "51-200", "201-500"]):
            return 2
        if any(k in s for k in ["500", "1000", "enterprise", "corp"]):
            return 3
        return 0

    @staticmethod
    def _normalize_salary_delta(delta: Optional[float]) -> float:
        if delta is None:
            return 0.0
        # Squash into [-1, 1] range using tanh-like scaling
        return float(max(-1.0, min(1.0, delta / 5000.0)))

    @staticmethod
    def _normalize_app_speed(hours: Optional[float]) -> float:
        if hours is None:
            return 0.5
        # Earlier is better: <24h -> ~0.9, >240h (~10d) -> ~0.1
        if hours <= 24:
            return 0.9
        if hours >= 240:
            return 0.1
        # Linear in between
        return float(0.9 - (hours - 24) * (0.8 / 216))

    def _load_default_model(self):
        """
        Load a built-in LightGBM model if available.

        For this implementation, we ship heuristic-only model to avoid external files.
        Hook exists for drop-in real model.
        """
        try:
            # Placeholder for future: load from file or env path.
            # For now, return heuristic.
            return _HeuristicModel()
        except Exception as exc:  # pragma: no cover
            logger.error("interview_predictor_model_load_failed", error=str(exc))
            return _HeuristicModel()

    def _to_feature_array(self, f: InterviewFeatures) -> np.ndarray:
        """
        Convert InterviewFeatures to model-ready numpy array.

        Order:
        [match_score, skills_overlap, experience_gap, company_size_code,
         salary_delta_norm, location_match, application_speed_norm]
        """
        company_code = float(self._encode_company_size(f.company_size))
        salary_delta_norm = self._normalize_salary_delta(f.salary_delta)
        app_speed_norm = self._normalize_app_speed(f.application_speed_hours)
        return np.array(
            [
                float(max(0.0, min(100.0, f.match_score))),
                float(max(0.0, min(1.0, f.skills_overlap))),
                float(f.experience_gap),
                company_code,
                salary_delta_norm,
                float(max(0.0, min(1.0, f.location_match))),
                app_speed_norm,
            ],
            dtype=float,
        )

    def predict(self, features: InterviewFeatures) -> InterviewPrediction:
        """
        Predict interview callback probability.

        Args:
            features: InterviewFeatures dataclass.

        Returns:
            InterviewPrediction with probability and recommendation.
        """
        try:
            X = self._to_feature_array(features).reshape(1, -1)
            proba = self._model.predict_proba(X)[0][1]
            # Clamp numeric noise
            proba = float(max(0.0, min(1.0, proba)))
        except Exception as exc:  # pragma: no cover
            logger.error("interview_predictor_inference_failed", error=str(exc))
            # Conservative fallback on failure
            proba = 0.0

        recommend_apply = proba >= 0.25

        logger.info(
            "interview_probability_scored",
            probability=round(proba, 4),
            recommend_apply=recommend_apply,
            model=self._model_name,
        )

        return InterviewPrediction(
            probability=proba,
            recommend_apply=recommend_apply,
            model_used=self._model_name,
        )


# Eager singleton
interview_predictor = InterviewPredictor()