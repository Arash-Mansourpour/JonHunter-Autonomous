"""
ATS-optimized resume builder for KARYABEEEE.

Responsibilities:
- Generate role-tailored resume variants for Arash Mansourpour.
- Inject relevant keywords from job description using TF-IDF-style weighting + Gemini.
- Produce:
    1. Standard 2-page resume (detailed, research/portfolio heavy)
    2. Condensed 1-page resume (startup-friendly)
- Export as:
    - PDF (reportlab)
    - DOCX (python-docx)
- Provide an ATS score estimation for each job.

Design notes:
- This module focuses on deterministic, testable logic.
- Gemini is used for refinement but failures gracefully fall back to rule-based content.
"""

from __future__ import annotations

import io
import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from docx import Document
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas

from karyabee.ai.gemini_client import gemini_client
from karyabee.logging_config import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Candidate base profile (single source of truth)
# ---------------------------------------------------------------------------

CANDIDATE = {
    "name": "Arash Mansourpour",
    "email": "arash_mansourpour@proton.me",
    "phone": "+989203600363",
    "location": "Karaj, Iran (Remote Global)",
    "github": "https://github.com/Arash-Mansourpour",
    "portfolio": "https://arshava.framer.ai",
    "summary": (
        "Senior AI Developer & Neural Architecture Specialist with 3 years of "
        "hands-on experience building Transformer-based NLP/LLM systems, RAG pipelines, "
        "and self-supervised architectures. Persian NLP pioneer, published researcher, "
        "and contributor to national-scale AI initiatives."
    ),
    "core_skills": [
        # Expert
        "PyTorch",
        "Transformers",
        "BERT",
        "GPT",
        "T5",
        "LLaMA",
        "RAG",
        "Multi-Head Attention",
        "Self-Attention",
        "LSTM",
        "NLP",
        "BLEU/ROUGE/METEOR",
        "Self-Supervised Learning",
        "Neural Architecture Design",
        "Reinforcement Learning",
        "Persian NLP",
        "Fine-tuning",
        "Prompt Engineering",
        # Advanced
        "Python",
        "TensorFlow",
        "OpenAI API",
        "Groq",
        "Redis",
        "PostgreSQL",
        "REST APIs",
        "Docker",
        "Git",
        "Data Pipelines",
        "CNN",
        "RNN",
        # Proficient
        "FastAPI",
        "Selenium",
        "Playwright",
        "BeautifulSoup",
        "Scrapy",
        "AWS",
        "GCP",
    ],
    "experience": [
        {
            "title": "Freelance AI Developer",
            "company": "Global Clients",
            "period": "Sep 2025 - Present",
            "details": [
                "Delivered 15+ custom AI/LLM solutions including RAG chatbots, trading bots, and recommendation systems.",
                "Generated $50K+ revenue by designing high-impact neural architectures and optimization strategies.",
                "Specialized in LLM prompt engineering, evaluation, and production deployment on GPU/accelerated hardware.",
            ],
        },
        {
            "title": "AI Developer",
            "company": "Advanced Technology",
            "period": "Jun 2022 - Feb 2025",
            "details": [
                "Built ML optimization models for large-scale water treatment systems using 10M+ data points.",
                "Increased predictive accuracy to 95% and reduced downtime by 30% via real-time inference pipelines.",
                "Implemented robust data ingestion, feature engineering, and monitoring stack, achieving 99.9% uptime.",
            ],
        },
    ],
    "projects": [
        {
            "name": "ultimate-crypto-trading-bot",
            "bullets": [
                "Autonomous Telegram trading engine with multi-exchange data, technical indicators, and risk management.",
                "Integrated AI-driven signal generation and portfolio balancing.",
            ],
        },
        {
            "name": "LSTM-AIChatPersian",
            "bullets": [
                "Persian RAG chatbot using LSTM + Attention + self-supervised learning.",
                "Achieved BLEU 0.78, ROUGE 0.82, METEOR 0.74 on evaluation benchmarks.",
            ],
        },
        {
            "name": "VortexAI-Persian",
            "bullets": [
                "Hybrid Transformer (LLaMA/T5) + LSTM architecture with multi-head attention.",
                "Optimized GPU usage, reducing latency by 30% for generative workloads.",
            ],
        },
        {
            "name": "Reinforcement-Learning_AD-Optimization",
            "bullets": [
                "DQN-based ad optimization engine deployed on Groq hardware.",
                "Improved CTR by 45% and ROI by 38% through reward-shaping and policy tuning.",
            ],
        },
        {
            "name": "MultiAgent-Chain-of-Expert",
            "bullets": [
                "Multi-agent system orchestrating Gemma+LLaMA models with self-propagating research loops.",
                "Built modern GUI for interactive experiment control and evaluation.",
            ],
        },
    ],
    "education": [
        "BSc Computer Engineering - Software, Azad University Karaj, 2025 (GPA 17.17/20)",
    ],
    "certifications": [
        "CS50P Python, Harvard (2024)",
        "IBM AI Engineering / Training (2024)",
    ],
    "publications": [
        '"Eternal Codex Infinitus", Zenodo 2025, DOI: 10.5281/zenodo.16938780 (12+ citations)',
    ],
}


logger.info("resume_builder_profile_loaded")


@dataclass
class ResumeContent:
    """Structured resume content before rendering."""

    headline: str
    summary: str
    skills: List[str]
    experience_blocks: List[Dict[str, List[str]]]
    projects: List[Dict[str, List[str]]]
    education: List[str]
    certifications: List[str]
    publications: List[str]
    ats_score: float


# ---------------------------------------------------------------------------
# Keyword/ATS helpers
# ---------------------------------------------------------------------------


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9+#_.\-]+", (text or "").lower())


def _rank_keywords(job_description: str, skills: List[str]) -> List[str]:
    """
    Rank candidate skills by presence/frequency in job description.

    Simple TF-style weighting:
    - Count skill token occurrences
    - Sort descending
    """
    jd_tokens = _tokenize(job_description)
    if not jd_tokens:
        return skills

    freq = {}
    for tok in jd_tokens:
        freq[tok] = freq.get(tok, 0) + 1

    def weight(skill: str) -> int:
        base = 1
        tokens = _tokenize(skill)
        return sum(freq.get(t, 0) for t in tokens) + base

    ranked = sorted(skills, key=weight, reverse=True)
    return ranked


def estimate_ats_score(job_description: str, resume_keywords: List[str]) -> float:
    """
    Rough ATS score: percentage of job tokens covered by resume keywords.

    Returns:
        Score in [0, 100].
    """
    jd_tokens = set(_tokenize(job_description))
    if not jd_tokens:
        return 80.0
    kw_tokens = set(_tokenize(" ".join(resume_keywords)))
    if not kw_tokens:
        return 20.0
    overlap = jd_tokens & kw_tokens
    coverage = len(overlap) / max(len(jd_tokens), 1)
    score = 40.0 + 60.0 * coverage
    return max(0.0, min(100.0, score))


def _ai_refine_summary(job_title: str, job_company: str, job_description: str) -> str:
    """
    Use Gemini to refine a targeted summary; fallback to deterministic if fails.
    """
    base = (
        f"Senior AI/LLM Engineer targeting {job_title} at {job_company}. "
        f"Expert in Transformer-based NLP, LLM fine-tuning, RAG, and neural architecture design."
    )
    prompt = (
        "You are optimizing a resume summary for ATS + human appeal. "
        "Given the job description, generate a concise 2-3 sentence summary highlighting "
        "Arash Mansourpour's strongest relevant skills, impact, and Persian NLP/LLM expertise. "
        "Avoid buzzword stuffing; keep it direct.\n\n"
        f"JOB DESCRIPTION:\n{job_description}\n\n"
        "Return ONLY the summary text."
    )
    try:
        resp = gemini_client.generate_content(prompt, use_cache=True)
        text = (resp.text or "").strip()
        if 100 <= len(text) <= 600:
            return text
    except Exception as exc:  # pragma: no cover - best-effort
        logger.error("resume_ai_summary_failed", error=str(exc))
    return base


# ---------------------------------------------------------------------------
# Core builder
# ---------------------------------------------------------------------------


def build_resume_content(job_title: str, job_company: str, job_description: str) -> ResumeContent:
    """
    Build structured resume content tailored to a specific job.

    Args:
        job_title: Job title.
        job_company: Company name.
        job_description: Job description text.

    Returns:
        ResumeContent object.
    """
    ranked_skills = _rank_keywords(job_description, CANDIDATE["core_skills"])
    ats_score = estimate_ats_score(job_description, ranked_skills)

    summary = _ai_refine_summary(job_title, job_company, job_description)

    # Copy experiences and projects; could be filtered or re-ordered later
    experience_blocks = [
        {
            "header": f"{exp['title']} | {exp['company']} | {exp['period']}",
            "bullets": list(exp["details"]),
        }
        for exp in CANDIDATE["experience"]
    ]
    project_blocks = [
        {
            "header": proj["name"],
            "bullets": list(proj["bullets"]),
        }
        for proj in CANDIDATE["projects"]
    ]

    headline = f"{CANDIDATE['name']} — Senior AI / LLM Engineer"

    return ResumeContent(
        headline=headline,
        summary=summary,
        skills=ranked_skills,
        experience_blocks=experience_blocks,
        projects=project_blocks,
        education=list(CANDIDATE["education"]),
        certifications=list(CANDIDATE["certifications"]),
        publications=list(CANDIDATE["publications"]),
        ats_score=round(ats_score, 2),
    )


# ---------------------------------------------------------------------------
# Render: DOCX
# ---------------------------------------------------------------------------


def render_docx(
    content: ResumeContent,
    condensed: bool = False,
) -> bytes:
    """
    Render resume content as DOCX.

    Args:
        content: ResumeContent structure.
        condensed: If True, generates 1-page optimized variant.

    Returns:
        DOCX file as bytes.
    """
    doc = Document()

    # Header
    doc.add_heading(content.headline, level=0)
    p = doc.add_paragraph()
    p.add_run(CANDIDATE["location"]).bold = False
    p.add_run(f" | {CANDIDATE['email']} | {CANDIDATE['phone']} | ")
    p.add_run(f"GitHub: {CANDIDATE['github']} | Portfolio: {CANDIDATE['portfolio']}")

    # Summary
    doc.add_heading("Summary", level=1)
    doc.add_paragraph(content.summary)

    # Skills
    doc.add_heading("Core Skills", level=1)
    skills_to_show = content.skills[:25] if condensed else content.skills[:40]
    doc.add_paragraph(", ".join(skills_to_show))

    # Experience
    doc.add_heading("Experience", level=1)
    for exp in content.experience_blocks:
        doc.add_paragraph(exp["header"], style="Intense Quote")
        bullets = exp["bullets"][:3] if condensed else exp["bullets"]
        for b in bullets:
            doc.add_paragraph(b, style="List Bullet")

    # Projects (condense if needed)
    doc.add_heading("Selected Projects", level=1)
    max_projects = 3 if condensed else len(content.projects)
    for proj in content.projects[:max_projects]:
        doc.add_paragraph(proj["header"], style="Intense Quote")
        bullets = proj["bullets"][:2] if condensed else proj["bullets"]
        for b in bullets:
            doc.add_paragraph(b, style="List Bullet")

    # Education, Certifications, Publications
    doc.add_heading("Education", level=1)
    for e in content.education:
        doc.add_paragraph(e)

    doc.add_heading("Certifications", level=1)
    for c in content.certifications:
        doc.add_paragraph(c)

    if not condensed:
        doc.add_heading("Publications", level=1)
        for pub in content.publications:
            doc.add_paragraph(pub)

    # Serialize
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Render: PDF (ATS-safe)
# ---------------------------------------------------------------------------


def render_pdf(
    content: ResumeContent,
    condensed: bool = False,
) -> bytes:
    """
    Render resume content as a simple, ATS-friendly PDF.

    Args:
        content: ResumeContent structure.
        condensed: Whether to use condensed layout.

    Returns:
        PDF file as bytes.
    """
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    width, height = A4

    styles = getSampleStyleSheet()
    normal = styles["Normal"]
    normal.leading = 13
    header_style = ParagraphStyle(
        "Header",
        parent=normal,
        fontSize=14,
        leading=16,
        spaceAfter=8,
    )

    x_margin = 2 * cm
    y = height - 2 * cm

    def draw_line(text: str, style: ParagraphStyle = normal) -> None:
        nonlocal y
        # Simplified text draw to keep ATS-friendly (no complex layout)
        max_width = width - 2 * x_margin
        for line in _wrap_text(text, max_chars=110):
            if y < 3 * cm:
                c.showPage()
                y = height - 2 * cm
            c.setFont("Helvetica", style.fontSize)
            c.drawString(x_margin, y, line)
            y -= style.leading

    # Header
    c.setFont("Helvetica-Bold", 16)
    c.drawString(x_margin, y, content.headline)
    y -= 18
    c.setFont("Helvetica", 9)
    draw_line(
        f"{CANDIDATE['location']} | {CANDIDATE['email']} | {CANDIDATE['phone']} | "
        f"GitHub: {CANDIDATE['github']} | Portfolio: {CANDIDATE['portfolio']}"
    )
    y -= 6

    # Summary
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, "Summary")
    y -= 14
    draw_line(content.summary)

    # Skills
    y -= 6
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, "Core Skills")
    y -= 14
    skills_to_show = content.skills[:25] if condensed else content.skills[:40]
    draw_line(", ".join(skills_to_show))

    # Experience
    y -= 6
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, "Experience")
    y -= 14
    for exp in content.experience_blocks:
        draw_line(exp["header"])
        bullets = exp["bullets"][:3] if condensed else exp["bullets"]
        for b in bullets:
            draw_line(f"- {b}")

    # Projects
    y -= 6
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, "Selected Projects")
    y -= 14
    max_projects = 3 if condensed else len(content.projects)
    for proj in content.projects[:max_projects]:
        draw_line(proj["header"])
        bullets = proj["bullets"][:2] if condensed else proj["bullets"]
        for b in bullets:
            draw_line(f"- {b}")

    # Education
    y -= 6
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, "Education")
    y -= 14
    for e in content.education:
        draw_line(e)

    # Certifications
    y -= 6
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x_margin, y, "Certifications")
    y -= 14
    for cert in content.certifications:
        draw_line(cert)

    # Publications (only for standard)
    if not condensed:
        y -= 6
        c.setFont("Helvetica-Bold", 11)
        c.drawString(x_margin, y, "Publications")
        y -= 14
        for pub in content.publications:
            draw_line(pub)

    c.showPage()
    c.save()
    return buf.getvalue()


def _wrap_text(text: str, max_chars: int) -> List[str]:
    """Simple word-wrap utility for PDF rendering."""
    words = (text or "").split()
    if not words:
        return []
    lines: List[str] = []
    cur: List[str] = []
    for w in words:
        if sum(len(x) for x in cur) + len(cur) + len(w) > max_chars:
            lines.append(" ".join(cur))
            cur = [w]
        else:
            cur.append(w)
    if cur:
        lines.append(" ".join(cur))
    return lines


# ---------------------------------------------------------------------------
# Public convenience API
# ---------------------------------------------------------------------------


def generate_resumes(
    job_title: str,
    job_company: str,
    job_description: str,
) -> Dict[str, Dict[str, bytes]]:
    """
    Generate both standard and condensed resume variants for a job.

    Returns:
        {
          "standard": {"pdf": <bytes>, "docx": <bytes>, "ats_score": float},
          "condensed": {"pdf": <bytes>, "docx": <bytes>, "ats_score": float},
        }
    """
    content = build_resume_content(job_title, job_company, job_description)

    # Standard: use as-is
    std_pdf = render_pdf(content, condensed=False)
    std_docx = render_docx(content, condensed=False)

    # Condensed: reuse content but with rendering toggles
    cond_pdf = render_pdf(content, condensed=True)
    cond_docx = render_docx(content, condensed=True)

    logger.info(
        "resume_generated",
        job_title=job_title,
        job_company=job_company,
        ats_score=content.ats_score,
    )

    return {
        "standard": {
            "pdf": std_pdf,
            "docx": std_docx,
            "ats_score": content.ats_score,
        },
        "condensed": {
            "pdf": cond_pdf,
            "docx": cond_docx,
            "ats_score": content.ats_score,
        },
    }