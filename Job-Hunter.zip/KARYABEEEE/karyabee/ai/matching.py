"""
Job matching and scoring engine for KARYABEEEE.

Implements:
- Semantic similarity using a sentence-transformers-style encoder (pluggable)
- Skill extraction via Gemini (NER-style prompting) + rule-based heuristics
- Experience, skills, location features
- Final match score:
    score = 0.4 * semantic
          + 0.3 * skills
          + 0.2 * experience
          + 0.1 * location
- Threshold-based apply_decision (default: 72)

Design:
- Pure Python with dependency injection for embedding model (for testability)
- Resilient to AI/embedding failures (fallback to conservative scores)
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Protocol, Tuple

import numpy as np

from karyabee.config import settings
from karyabee.logging_config import get_logger
from karyabee.models import Job
from karyabee.ai.gemini_client import gemini_client

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Candidate profile (fixed for this deployment)
# ---------------------------------------------------------------------------

CANDIDATE_PROFILE_TEXT = """
Name: Arash Mansourpour
Role: Senior AI Developer & Neural Architecture Specialist
Location: Karaj, Iran (Remote Global preferred)
Summary: Senior AI Developer & Neural Architecture Specialist with 3 years experience.
Expert in Transformers, LLMs (BERT/GPT/T5/LLaMA), RAG, Attention, Self-Supervised Learning.
Persian NLP pioneer, published researcher, national AI association member, nuclear research collaborator.

Skills:
- Expert: PyTorch, Transformers, BERT, GPT, T5, LLaMA, RAG, Multi-Head Attention, Self-Attention,
          LSTM, NLP (BLEU/ROUGE/METEOR), Self-Supervised Learning, Neural Architecture Design,
          Reinforcement Learning, Persian NLP, Fine-tuning, Prompt Engineering
- Advanced: Python, TensorFlow, OpenAI API, Groq API, Google API, Redis, PostgreSQL, REST APIs,
            Docker, Git, Data Pipelines, CNNs, RNNs
- Proficient: FastAPI, Selenium, Playwright, BeautifulSoup, Scrapy, AWS/GCP basics

Experience:
- 3+ years hands-on in AI/ML, LLM-based systems, production-grade deployments.
"""

CANDIDATE_LOCATION = "Karaj, Iran"
CANDIDATE_REMOTE_PREFERRED = True
CANDIDATE_EXPERIENCE_YEARS = 3.0


# ---------------------------------------------------------------------------
# Embedding interface
# ---------------------------------------------------------------------------


class EmbeddingModel(Protocol):
    """Protocol for embedding models used for semantic similarity."""

    def encode(self, texts: List[str]) -> np.ndarray:  # pragma: no cover - interface
        """
        Encode one or more texts into a 2D numpy array [n, d].

        Implementations must:
        - Return float32 or float64 array
        - Be deterministic for same input
        """
        raise NotImplementedError


class SimpleTFIDFEmbedder:
    """
    Lightweight fallback embedding model using bag-of-words / TF-style weighting.

    This avoids heavy model downloads while still giving stable similarity for tests.
    Not a real sentence-transformer, but satisfies the Protocol.
    """

    def __init__(self) -> None:
        self._vocab: Dict[str, int] = {}

    def _tokenize(self, text: str) -> List[str]:
        text = text.lower()
        return re.findall(r"[a-zA-Z\u0600-\u06FF]+", text)

    def _vectorize(self, text: str) -> np.ndarray:
        tokens = self._tokenize(text)
        if not tokens:
            return np.zeros((len(self._vocab) or 1,), dtype=np.float32)
        # Build/update vocab
        for t in tokens:
            if t not in self._vocab:
                self._vocab[t] = len(self._vocab)
        vec = np.zeros((len(self._vocab),), dtype=np.float32)
        for t in tokens:
            idx = self._vocab[t]
            vec[idx] += 1.0
        # Normalize
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec /= norm
        return vec

    def encode(self, texts: List[str]) -> np.ndarray:
        return np.stack([self._vectorize(t) for t in texts], axis=0)


# Global singleton embedder (can be swapped in tests)
_default_embedder: EmbeddingModel = SimpleTFIDFEmbedder()


def set_embedding_model(model: EmbeddingModel) -> None:
    """
    Override the global embedding model.

    Useful for injecting a real sentence-transformers model in production.
    """
    global _default_embedder
    _default_embedder = model
    logger.info("matching_embedding_model_overridden", model_class=type(model).__name__)


# ---------------------------------------------------------------------------
# Skill extraction
# ---------------------------------------------------------------------------


def extract_skills(text: str) -> List[str]:
    """
    Extract normalized skill tokens from job text using heuristics + Gemini.

    Steps:
    1. Basic regex/keyword extraction for robustness.
    2. Best-effort Gemini JSON extraction; merged with heuristics if successful.

    Returns:
        List of unique, lowercase skills.
    """
    text = text or ""
    base_candidates = set(
        s.lower()
        for s in [
            "pytorch",
            "tensorflow",
            "python",
            "transformer",
            "bert",
            "gpt",
            "t5",
            "llama",
            "rag",
            "attention",
            "nlp",
            "docker",
            "kubernetes",
            "fastapi",
            "rest",
            "redis",
            "postgresql",
            "aws",
            "gcp",
            "azure",
            "linux",
            "selenium",
            "playwright",
            "scrapy",
            "beautifulsoup",
        ]
        if s in text.lower()
    )

    try:
        instruction = (
            "Extract key technical skills, frameworks, and tools from the job "
            "description as a JSON list under 'skills'. Use lowercase tokens."
        )
        result = gemini_client.extract_structured(instruction, text)
        if isinstance(result, dict):
            skills = result.get("skills") or result.get("keywords")
            if isinstance(skills, list):
                for s in skills:
                    if isinstance(s, str) and s.strip():
                        base_candidates.add(s.strip().lower())
    except Exception as exc:  # pragma: no cover - best-effort AI call
        logger.error("matching_skill_extraction_ai_failed", error=str(exc))

    return sorted(base_candidates)


# ---------------------------------------------------------------------------
# Scoring helpers
# ---------------------------------------------------------------------------


def _cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    if a.shape != b.shape:
        # Pad shorter to longer
        if a.size < b.size:
            a = np.pad(a, (0, b.size - a.size))
        elif b.size < a.size:
            b = np.pad(b, (0, a.size - b.size))
    denom = (np.linalg.norm(a) * np.linalg.norm(b))
    if denom == 0:
        return 0.0
    return float(np.clip(np.dot(a, b) / denom, -1.0, 1.0))


def compute_semantic_similarity(job_text: str) -> float:
    """
    Compute semantic similarity between job text and candidate profile.

    Returns:
        Similarity in [0, 100].
    """
    try:
        embeddings = _default_embedder.encode([CANDIDATE_PROFILE_TEXT, job_text])
        cand_vec, job_vec = embeddings[0], embeddings[1]
        sim = _cosine_similarity(cand_vec, job_vec)
        return max(0.0, min(100.0, (sim + 1.0) / 2.0 * 100.0))
    except Exception as exc:  # pragma: no cover
        logger.error("matching_semantic_similarity_failed", error=str(exc))
        return 0.0


def compute_skills_score(job_skills: Iterable[str]) -> Tuple[float, Dict[str, Any]]:
    """
    Compute skill overlap score between candidate and job.

    Returns:
        (score_0_100, details)
    """
    job_set = {s.lower().strip() for s in job_skills if s}
    if not job_set:
        return 50.0, {"note": "no_skills_listed"}

    candidate_skills = {
        # Core expert skills
        "pytorch",
        "transformers",
        "bert",
        "gpt",
        "t5",
        "llama",
        "rag",
        "attention",
        "multi-head attention",
        "self-attention",
        "lstm",
        "nlp",
        "self-supervised learning",
        "neural architecture design",
        "reinforcement learning",
        "persian nlp",
        "fine-tuning",
        "prompt engineering",
        # Supporting stack
        "python",
        "tensorflow",
        "openai",
        "groq",
        "redis",
        "postgresql",
        "rest",
        "docker",
        "git",
        "fastapi",
        "selenium",
        "playwright",
        "beautifulsoup",
        "scrapy",
        "aws",
        "gcp",
    }

    overlap = job_set & candidate_skills
    if not overlap:
        return 25.0, {"missing": sorted(job_set)}

    ratio = len(overlap) / max(len(job_set), 1)
    # Non-linear to reward strong overlap
    score = 40.0 + 60.0 * ratio
    score = max(0.0, min(100.0, score))
    gaps = sorted(job_set - overlap)
    return score, {"overlap": sorted(overlap), "gaps": gaps}


def compute_experience_score(required_years: Optional[float]) -> float:
    """
    Compute experience alignment score.

    Args:
        required_years: Parsed required years of experience (if any).

    Returns:
        Score in [0, 100].
    """
    if required_years is None or required_years <= 0:
        return 80.0
    # Ratio of candidate experience to required
    ratio = CANDIDATE_EXPERIENCE_YEARS / required_years
    if ratio >= 1.0:
        return 95.0
    if ratio >= 0.7:
        return 80.0
    if ratio >= 0.5:
        return 60.0
    return 30.0


def parse_required_experience(text: str) -> Optional[float]:
    """
    Naive extraction of required experience in years from job text.

    Returns:
        Float years if found, else None.
    """
    if not text:
        return None
    m = re.search(r"(\d+)\+?\s*(?:years|yrs|سال)", text, flags=re.IGNORECASE)
    if m:
        try:
            return float(m.group(1))
        except ValueError:
            return None
    return None


def compute_location_score(job_location: Optional[str]) -> float:
    """
    Compute location compatibility score.

    Rules:
    - If remote in description: high score
    - If same country/region: medium-high
    - Otherwise: lower but non-zero if remote friendly

    Returns:
        Score in [0, 100].
    """
    if not job_location:
        return 70.0  # unknown location - moderate neutral
    loc = job_location.lower()
    if "remote" in loc or "ریموت" in loc:
        return 95.0
    if "iran" in loc or "تهران" in loc or "karaj" in loc:
        return 85.0
    if CANDIDATE_REMOTE_PREFERRED and any(
        k in loc for k in ["europe", "usa", "germany", "canada", "uk", "australia"]
    ):
        # Remote from Iran to major tech hubs is acceptable
        return 70.0
    return 40.0


# ---------------------------------------------------------------------------
# Public match API
# ---------------------------------------------------------------------------


@dataclass
class MatchResult:
    """Container for match scoring outputs."""

    semantic_score: float
    skills_score: float
    experience_score: float
    location_score: float
    final_score: float
    apply_decision: bool
    skill_gaps: Dict[str, Any]


def calculate_match_score(
    job: Job,
    embedding_model: Optional[EmbeddingModel] = None,
    threshold: Optional[float] = None,
) -> MatchResult:
    """
    Calculate comprehensive match score for a Job.

    Args:
        job: SQLAlchemy Job instance.
        embedding_model: Optional custom embedding model (for tests/overrides).
        threshold: Score threshold for apply_decision; default from settings.

    Returns:
        MatchResult with detailed breakdown.
    """
    global _default_embedder
    if embedding_model is not None:
        _prev = _default_embedder
        _default_embedder = embedding_model

    try:
        description = (job.description or "") + "\n" + " ".join(
            (job.company or "", job.title or "")
        )

        job_skills = set(extract_skills(description))
        if job.tech_stack:
            job_skills.update(s.lower() for s in job.tech_stack if s)

        semantic = compute_semantic_similarity(description)
        skills_score, skills_detail = compute_skills_score(job_skills)
        required_years = parse_required_experience(description)
        experience = compute_experience_score(required_years)
        location = compute_location_score(job.location)

        final = (
            0.4 * semantic
            + 0.3 * skills_score
            + 0.2 * experience
            + 0.1 * location
        )

        thr = float(threshold if threshold is not None else settings.match_score_threshold)
        apply_decision = final >= thr

        result = MatchResult(
            semantic_score=round(semantic, 2),
            skills_score=round(skills_score, 2),
            experience_score=round(experience, 2),
            location_score=round(location, 2),
            final_score=round(final, 2),
            apply_decision=apply_decision,
            skill_gaps=skills_detail,
        )

        logger.info(
            "job_match_scored",
            job_id=str(getattr(job, "id", "")),
            title=job.title,
            company=job.company,
            final_score=result.final_score,
            apply_decision=result.apply_decision,
        )

        return result
    except Exception as exc:
        logger.error(
            "job_match_calculation_failed",
            job_id=str(getattr(job, "id", "")),
            error=str(exc),
        )
        # On failure, return conservative result (no auto-apply)
        return MatchResult(
            semantic_score=0.0,
            skills_score=0.0,
            experience_score=0.0,
            location_score=0.0,
            final_score=0.0,
            apply_decision=False,
            skill_gaps={"error": "matching_failed"},
        )
    finally:
        if embedding_model is not None:
            _default_embedder = _prev  # type: ignore[name-defined]