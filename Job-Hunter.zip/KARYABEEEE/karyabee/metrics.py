"""
Prometheus metrics helpers for KARYABEEEE.

Critical fix for your environment (Windows 11 + Docker Desktop):

- Completely disable Prometheus multiprocess/mmap usage that was causing:
    FileNotFoundError: '/tmp/prometheus/gauge_all_*.db'
- Force a simple, single-process registry inside the app container, which:
    - Works with uvicorn's default master/worker model in this compose setup.
    - Is stable and sufficient for your current stack.

If you later need true multiprocess metrics:
- You must explicitly implement proper multiprocess wiring (PROMETHEUS_MULTIPROC_DIR,
  gunicorn/uvicorn workers, shared volume). This file is intentionally conservative.
"""

from __future__ import annotations

from prometheus_client import (
    REGISTRY,
    Counter,
    Gauge,
    Histogram,
    generate_latest,
)

from karyabee.logging_config import get_logger

logger = get_logger(__name__)

# -----------------------------------------------------------------------------
# Registry (SINGLE PROCESS ONLY)
# -----------------------------------------------------------------------------
# We intentionally use the default REGISTRY only.
# No multiprocess mode. No PROMETHEUS_MULTIPROC_DIR. No mmap_dict.
# This guarantees no '/tmp/prometheus/*.db' errors.

_REGISTRY = REGISTRY

# Emit a one-time log so we can verify behavior from container logs.
logger.info("prometheus_metrics_initialized_single_process_registry")

# -----------------------------------------------------------------------------
# Metric definitions
# -----------------------------------------------------------------------------

JOBS_SCRAPED_TOTAL = Counter(
    "karyabee_jobs_scraped_total",
    "Total number of jobs scraped",
    ["source"],
    registry=_REGISTRY,
)

APPLICATIONS_SENT_TOTAL = Counter(
    "karyabee_applications_sent_total",
    "Total number of applications sent",
    ["source"],
    registry=_REGISTRY,
)

APPLICATIONS_SUCCESS_TOTAL = Counter(
    "karyabee_applications_success_total",
    "Total number of successful applications (no immediate error)",
    ["source"],
    registry=_REGISTRY,
)

APPLICATIONS_FAILED_TOTAL = Counter(
    "karyabee_applications_failed_total",
    "Total number of failed application attempts",
    ["source", "reason"],
    registry=_REGISTRY,
)

SCRAPER_RUNTIME_SECONDS = Histogram(
    "karyabee_scraper_runtime_seconds",
    "Scraper runtime duration in seconds",
    ["source"],
    registry=_REGISTRY,
)

AI_MATCH_SCORE = Histogram(
    "karyabee_ai_match_score",
    "Distribution of AI match scores (0.0-1.0)",
    ["model"],
    buckets=[i / 20.0 for i in range(21)],  # 0.0, 0.05, ..., 1.0
    registry=_REGISTRY,
)

HEALTH_STATUS = Gauge(
    "karyabee_health_status",
    "Overall health status of the application (1=healthy,0=unhealthy)",
    registry=_REGISTRY,
)

# -----------------------------------------------------------------------------
# Export helper
# -----------------------------------------------------------------------------

def export_metrics() -> bytes:
    """
    Export all metrics in Prometheus text format.

    Used by FastAPI /api/metrics endpoint.

    Returns:
        Raw bytes in Prometheus text exposition format.
    """
    return generate_latest(_REGISTRY)