"""
KARYABEEEE - Autonomous Job Application Engine

Top-level package initialization.
Provides:
- Version metadata
- Early, centralized logging configuration
"""

from __future__ import annotations

from .logging_config import get_logger  # noqa: F401

__all__ = ["__version__", "get_logger"]

__version__ = "0.1.0"

# Initialize a root logger for early importers
get_logger(__name__).info("karyabee_package_imported", version=__version__)