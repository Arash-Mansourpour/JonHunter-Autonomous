"""
SQLAlchemy ORM models for KARYABEEEE.

Implements:
- jobs
- applications
- analytics
- follow_ups

All models:
- Use UUID primary keys
- Include created_at / updated_at audit fields
- Are aligned with the provided system specification
"""

from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import (
    ARRAY,
    JSON,
    Boolean,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    """Base declarative class with UUID PK and timestamps."""

    id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),  # SQLAlchemy/DB-side function; pylint false positive
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
        onupdate=func.now(),
    )


class Job(Base):
    """
    Job posting entity.

    Mirrors the spec:

    TABLE jobs:
      id UUID PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      company VARCHAR(255) NOT NULL,
      location VARCHAR(255),
      salary_min INT,
      salary_max INT,
      currency VARCHAR(10),
      description TEXT,
      requirements JSONB,
      tech_stack TEXT[],
      benefits TEXT[],
      company_size VARCHAR(50),
      posted_date DATE,
      scraped_at TIMESTAMP DEFAULT NOW(),
      application_url TEXT UNIQUE,
      source VARCHAR(50),
      match_score FLOAT,
      skill_gaps JSONB,
      apply_decision BOOLEAN,
      status VARCHAR(50) DEFAULT 'pending',
      INDEX idx_match_score ON (match_score DESC),
      INDEX idx_status ON (status),
      INDEX idx_posted_date ON (posted_date DESC)
    """

    __tablename__ = "jobs"

    title: Mapped[str] = mapped_column(String(255), nullable=False)
    company: Mapped[str] = mapped_column(String(255), nullable=False)
    location: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)

    salary_min: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    salary_max: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    currency: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)

    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # requirements: structured JSON (e.g., {"must": [], "nice": []})
    requirements: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSON, nullable=True
    )

    # tech_stack & benefits as arrays of text
    tech_stack: Mapped[Optional[List[str]]] = mapped_column(
        ARRAY(String), nullable=True
    )
    benefits: Mapped[Optional[List[str]]] = mapped_column(
        ARRAY(String), nullable=True
    )

    company_size: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    posted_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    scraped_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    application_url: Mapped[Optional[str]] = mapped_column(
        Text,
        unique=True,
        nullable=True,
    )

    source: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    match_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    skill_gaps: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSON, nullable=True
    )
    apply_decision: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)

    status: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="pending",
        server_default="pending",
    )

    applications: Mapped[List["Application"]] = relationship(
        back_populates="job",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        Index("idx_jobs_match_score_desc", match_score.desc()),
        Index("idx_jobs_status", status),
        Index("idx_jobs_posted_date_desc", posted_date.desc()),
    )


class Application(Base):
    """
    Application entity.

    Mirrors the spec:

    TABLE applications:
      id UUID PRIMARY KEY,
      job_id UUID REFERENCES jobs(id),
      applied_at TIMESTAMP DEFAULT NOW(),
      resume_version VARCHAR(255),
      cover_letter TEXT,
      account_used VARCHAR(100),
      confirmation_number VARCHAR(255),
      screenshot_path VARCHAR(500),
      response_received BOOLEAN DEFAULT FALSE,
      response_date TIMESTAMP,
      response_type VARCHAR(50),
      interview_scheduled BOOLEAN DEFAULT FALSE,
      interview_date TIMESTAMP,
      outcome VARCHAR(50) DEFAULT 'pending',
      notes TEXT,
      INDEX idx_job_id ON (job_id),
      INDEX idx_outcome ON (outcome),
      INDEX idx_applied_at ON (applied_at DESC)
    """

    __tablename__ = "applications"

    job_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("jobs.id", ondelete="CASCADE"),
        nullable=False,
    )

    applied_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        server_default=func.now(),
    )

    resume_version: Mapped[Optional[str]] = mapped_column(
        String(255), nullable=True
    )
    cover_letter: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    account_used: Mapped[Optional[str]] = mapped_column(
        String(100), nullable=True
    )

    confirmation_number: Mapped[Optional[str]] = mapped_column(
        String(255), nullable=True
    )
    screenshot_path: Mapped[Optional[str]] = mapped_column(
        String(500), nullable=True
    )

    response_received: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
    )
    response_date: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    response_type: Mapped[Optional[str]] = mapped_column(
        String(50), nullable=True
    )

    interview_scheduled: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
    )
    interview_date: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    outcome: Mapped[str] = mapped_column(
        String(50),
        nullable=False,
        default="pending",
        server_default="pending",
    )

    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    job: Mapped[Job] = relationship(back_populates="applications")

    __table_args__ = (
        Index("idx_applications_job_id", job_id),
        Index("idx_applications_outcome", outcome),
        Index("idx_applications_applied_at_desc", applied_at.desc()),
    )


class Analytics(Base):
    """
    Daily aggregated analytics.

    Mirrors the spec:

    TABLE analytics:
      date DATE PRIMARY KEY,
      jobs_scraped INT DEFAULT 0,
      applications_sent INT DEFAULT 0,
      responses_received INT DEFAULT 0,
      interviews_scheduled INT DEFAULT 0,
      offers_received INT DEFAULT 0,
      rejection_rate FLOAT,
      avg_response_time_hours FLOAT,
      top_skills_demanded JSONB,
      top_companies_hiring JSONB,
      avg_salary_offered INT,
      success_rate_by_platform JSONB
    """

    __tablename__ = "analytics"

    # date as natural unique key for rollups
    date: Mapped[date] = mapped_column(
        Date,
        nullable=False,
        unique=True,
    )

    jobs_scraped: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )
    applications_sent: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )
    responses_received: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )
    interviews_scheduled: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )
    offers_received: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
        default=0,
        server_default="0",
    )

    rejection_rate: Mapped[Optional[float]] = mapped_column(
        Float, nullable=True
    )
    avg_response_time_hours: Mapped[Optional[float]] = mapped_column(
        Float, nullable=True
    )

    top_skills_demanded: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSON, nullable=True
    )
    top_companies_hiring: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSON, nullable=True
    )
    avg_salary_offered: Mapped[Optional[int]] = mapped_column(
        Integer, nullable=True
    )
    success_rate_by_platform: Mapped[Optional[Dict[str, Any]]] = mapped_column(
        JSON, nullable=True
    )


class FollowUp(Base):
    """
    Follow-up tracking.

    Mirrors the spec:

    TABLE follow_ups:
      id UUID PRIMARY KEY,
      application_id UUID REFERENCES applications(id),
      scheduled_for TIMESTAMP,
      sent_at TIMESTAMP,
      message TEXT,
      response_received BOOLEAN DEFAULT FALSE
    """

    __tablename__ = "follow_ups"

    application_id: Mapped[uuid.UUID] = mapped_column(
        PG_UUID(as_uuid=True),
        ForeignKey("applications.id", ondelete="CASCADE"),
        nullable=False,
    )

    scheduled_for: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    sent_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    response_received: Mapped[bool] = mapped_column(
        Boolean,
        nullable=False,
        default=False,
        server_default="false",
    )

    application: Mapped[Application] = relationship()

    __table_args__ = (
        Index("idx_follow_ups_application_id", application_id),
    )