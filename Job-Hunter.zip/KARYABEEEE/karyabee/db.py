"""
Database engine, session management, and initialization utilities for KARYABEEEE.

Features:
- Centralized SQLAlchemy engine creation using env config
- Scoped async/session helpers
- Safe initialization hook to create tables (for early bootstrap / tests)
- Designed for PostgreSQL with psycopg2 and Alembic migrations
"""

from __future__ import annotations

import contextlib
from typing import Generator

from sqlalchemy import Engine, create_engine
from sqlalchemy.engine import URL
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, sessionmaker

from .config import settings
from .logging_config import get_logger
from .models import Base

logger = get_logger(__name__)

# Engine configuration:
# - Use settings.sql_database_url which already resolves DATABASE_URL or POSTGRES_*.
# - pool_pre_ping: detect stale connections
# - pool_size / max_overflow tuned but conservative for memory
# - future-style engine for SQLAlchemy 2.x


def _create_engine() -> Engine:
    """
    Create the SQLAlchemy engine with production-safe, memory-aware defaults.
    """
    # Prefer the derived, validated URL from settings
    db_url = settings.sql_database_url

    # Let SQLAlchemy parse the URL string directly; avoid ad-hoc parsing logic.
    # This is both safer and avoids subtle bugs with multi-part URLs.
    engine = create_engine(
        db_url,
        pool_pre_ping=True,
        pool_size=settings.db_pool_size,
        max_overflow=settings.db_max_overflow,
        pool_timeout=30,
        pool_recycle=1800,
        echo=settings.sqlalchemy_echo,
        future=True,
    )
    return engine


engine: Engine = _create_engine()

SessionLocal = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
    expire_on_commit=False,
    class_=Session,
)


def get_db_session() -> Generator[Session, None, None]:
    """
    Dependency-style session provider (FastAPI/Celery tasks).

    Usage:
        with next(get_db_session()) as db:
            ...
    Or in FastAPI:
        def endpoint(db: Session = Depends(get_db_session)): ...
    """
    db: Session = SessionLocal()
    try:
        yield db
        db.commit()
    except SQLAlchemyError as exc:
        db.rollback()
        logger.error(
            "db_session_error",
            error=str(exc),
        )
        raise
    finally:
        db.close()


@contextlib.contextmanager
def session_scope() -> Generator[Session, None, None]:
    """
    Context manager providing a transactional scope.

    Usage:
        with session_scope() as db:
            db.add(obj)
    """
    session: Session = SessionLocal()
    try:
        yield session
        session.commit()
    except SQLAlchemyError as exc:
        session.rollback()
        logger.error(
            "db_session_scope_error",
            error=str(exc),
        )
        raise
    finally:
        session.close()


def init_db(create_all: bool = False) -> None:
    """
    Initialize database connection and optionally create tables.

    Notes:
    - In production, schema changes MUST be handled via Alembic migrations.
    - This helper is mainly for:
        * local development bootstrap
        * unit/integration tests

    Args:
        create_all: If True, create all tables as defined in models.Base.
    """
    try:
        # Use a lightweight "SELECT 1" to validate connectivity.
        with engine.connect() as conn:
            conn.exec_driver_sql("SELECT 1")
        logger.info("db_connection_ok")
    except SQLAlchemyError as exc:
        logger.error("db_connection_failed", error=str(exc))
        raise

    if create_all:
        try:
            Base.metadata.create_all(bind=engine)
            logger.info("db_schema_created")
        except SQLAlchemyError as exc:
            logger.error("db_schema_create_failed", error=str(exc))
            raise