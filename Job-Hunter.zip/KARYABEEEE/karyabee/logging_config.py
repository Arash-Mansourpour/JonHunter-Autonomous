"""
Structured, security-aware, production-grade logging for KARYABEEEE.

Goals:
- JSON logs via structlog + orjson
- Consistent format across:
    - FastAPI app
    - Celery workers / beat
    - Scrapers, AI, bots, utilities
- Context-rich:
    - service, environment, hostname, process id
    - correlation_id / request_id (if present)
    - job_id / application_id / user_id when bound upstream
- Strict PII hygiene:
    - Mask emails and phone numbers
    - Avoid leaking secrets / tokens in logs
- Robust error logging:
    - Full exception info with types
    - Safe serialization of non-JSONable values
- Environment-driven configuration:
    - LOG_LEVEL (DEBUG/INFO/WARNING/ERROR)
    - LOG_FORMAT=json|pretty
    - SENTRY_DSN for centralized error tracking (optional)
    - LOG_FILE (optional) for file-based logs inside container
"""

from __future__ import annotations

import json
import logging
import logging.config
import os
import re
import socket
import sys
from typing import Any, Dict

import orjson
import sentry_sdk
import structlog

from karyabee.config import settings

# ---------------------------------------------------------------------------
# PII masking
# ---------------------------------------------------------------------------

_EMAIL_PATTERN = re.compile(r"([a-zA-Z0-9_.+-]+)@([a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)")
_PHONE_PATTERN = re.compile(r"\+?\d[\d\s\-()]{7,}\d")
_SECRET_KEYS = {"password", "pass", "passwd", "secret", "token", "apikey", "api_key", "authorization"}


def _mask_email(match: re.Match[str]) -> str:
    local, domain = match.group(1), match.group(2)
    if len(local) <= 2:
        return "***@" + domain
    return local[0] + "***@" + domain


def _mask_phone(match: re.Match[str]) -> str:
    text = match.group(0)
    digits = re.sub(r"\D", "", text)
    if len(digits) <= 4:
        return "***"
    # Keep last 3-4 digits, mask the rest
    return "***" + digits[-4:]


def _mask_pii_in_str(value: str) -> str:
    if not value:
        return value
    value = _EMAIL_PATTERN.sub(_mask_email, value)
    value = _PHONE_PATTERN.sub(_mask_phone, value)
    return value


def _sanitize_value(key: str, value: Any) -> Any:
    # Explicit secret-like keys: fully mask
    lowered = key.lower()
    if any(sk in lowered for sk in _SECRET_KEYS):
        return "***redacted***"

    if isinstance(value, str):
        return _mask_pii_in_str(value)
    if isinstance(value, dict):
        return {k: _sanitize_value(k, v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_sanitize_value(key, v) for v in value]
    return value


def pii_sanitizer_processor(_: Any, __: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Processor that masks PII and secrets in log event values."""
    sanitized: Dict[str, Any] = {}
    for key, value in event_dict.items():
        sanitized[key] = _sanitize_value(key, value)
    return sanitized


# ---------------------------------------------------------------------------
# Structlog helpers
# ---------------------------------------------------------------------------


def add_log_level(logger: Any, method_name: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    event_dict["level"] = method_name
    return event_dict


def add_logger_name(logger: Any, _: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    name = getattr(logger, "name", None)
    if name:
        event_dict["logger"] = name
    return event_dict


def add_service_context(_: Any, __: str, event_dict: Dict[str, Any]) -> Dict[str, Any]:
    """Attach static service-level context."""
    event_dict.setdefault("app", "karyabee")
    # settings.env is expected from config; fallback safe.
    event_dict.setdefault("env", getattr(settings, "env", "unknown"))
    event_dict.setdefault("host", socket.gethostname())
    event_dict.setdefault("pid", os.getpid())
    return event_dict


def json_renderer(_: Any, __: str, event_dict: Dict[str, Any]) -> str:
    """
    Render logs as JSON string using orjson.

    - Non-JSON-serializable objects are converted via repr().
    - Keeps output compact and machine friendly.
    """
    try:
        return orjson.dumps(event_dict, option=orjson.OPT_NON_STR_KEYS).decode("utf-8")
    except TypeError:
        safe_event: Dict[str, Any] = {}
        for k, v in event_dict.items():
            if isinstance(v, (str, int, float, bool, list, dict)) or v is None:
                safe_event[k] = v
            else:
                safe_event[k] = repr(v)
        return orjson.dumps(safe_event, option=orjson.OPT_NON_STR_KEYS).decode("utf-8")


def pretty_renderer(_: Any, __: str, event_dict: Dict[str, Any]) -> str:
    """Human-readable pretty renderer for local development."""
    try:
        return json.dumps(event_dict, ensure_ascii=False, indent=2, sort_keys=True)
    except TypeError:
        safe_event: Dict[str, Any] = {}
        for k, v in event_dict.items():
            if isinstance(v, (str, int, float, bool, list, dict)) or v is None:
                safe_event[k] = v
            else:
                safe_event[k] = repr(v)
        return json.dumps(safe_event, ensure_ascii=False, indent=2, sort_keys=True)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


def configure_stdlib_logging(level: int, log_file: str | None = None) -> None:
    """
    Configure stdlib logging.

    - Root logger sends to stderr by default.
    - Optional file handler if LOG_FILE is provided.
    """
    handlers: Dict[str, Any] = {
        "default": {
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stderr",
        },
    }

    root_handlers = ["default"]

    if log_file:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        handlers["file"] = {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": log_file,
            "maxBytes": 10 * 1024 * 1024,
            "backupCount": 5,
            "encoding": "utf-8",
        }
        root_handlers.append("file")

    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "handlers": handlers,
            "root": {
                "level": level,
                "handlers": root_handlers,
            },
        }
    )


def configure_structlog(level: int, renderer: str) -> None:
    """
    Configure structlog processors.

    renderer:
        - "json": production JSON logs
        - "pretty": dev-friendly pretty JSON
    """
    if renderer == "pretty":
        renderer_fn = pretty_renderer
    else:
        renderer_fn = json_renderer

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            add_log_level,
            add_logger_name,
            add_service_context,
            pii_sanitizer_processor,
            structlog.processors.UnicodeDecoder(),
            renderer_fn,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def configure_sentry_if_enabled() -> None:
    """
    Initialize Sentry if SENTRY_DSN is configured.

    - Captures unhandled exceptions and error-level logs.
    - Environment and release populated from settings.
    """
    dsn = os.getenv("SENTRY_DSN", "").strip()
    if not dsn:
        return

    sentry_sdk.init(
        dsn=dsn,
        environment=getattr(settings, "env", "unknown"),
        release=f"karyabee@{getattr(settings, 'version', '0.1.0')}",
        traces_sample_rate=float(os.getenv("SENTRY_TRACES_SAMPLE_RATE", "0.0")),
        profiles_sample_rate=float(os.getenv("SENTRY_PROFILES_SAMPLE_RATE", "0.0")),
    )


def configure_logging() -> None:
    """
    Configure logging stack (idempotent).

    Reads:
        - LOG_LEVEL: default INFO
        - LOG_FORMAT: json|pretty (default json)
        - LOG_FILE: optional file path

    Notes:
        - settings.log_level may be a Pydantic field; resolve defensively.
    """
    if os.getenv("KARYABEEEE_LOGGING_CONFIGURED") == "1":
        return

    # Resolve base level from settings without assuming plain string
    settings_log_level = getattr(settings, "log_level", "INFO")
    if not isinstance(settings_log_level, str):
        settings_log_level = "INFO"

    log_level_str = os.getenv("LOG_LEVEL", settings_log_level).upper()
    log_format = os.getenv("LOG_FORMAT", "json").lower()
    log_file = os.getenv("LOG_FILE", "").strip() or None

    level = getattr(logging, log_level_str, logging.INFO)

    configure_stdlib_logging(level, log_file)
    configure_structlog(level, renderer=log_format)
    configure_sentry_if_enabled()

    os.environ["KARYABEEEE_LOGGING_CONFIGURED"] = "1"

    # Simple bootstrap message to confirm configuration
    logger = structlog.get_logger("karyabee.bootstrap")
    logger.info("logging_config_initialized", level=log_level_str, format=log_format)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """
    Return a configured structlog logger.

    - Ensures global configuration is applied once.
    - Binds static context: app="karyabee".
    - Callers can further bind context: logger.bind(job_id=..., request_id=...)
    """
    if os.getenv("KARYABEEEE_LOGGING_CONFIGURED") != "1":
        configure_logging()
    logger = structlog.get_logger(name)
    return logger.bind(app="karyabee")


# Eager initialization for early imports (safe & idempotent)
get_logger(__name__).info("logging_module_imported")