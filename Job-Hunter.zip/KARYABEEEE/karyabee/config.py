"""
Centralized configuration for KARYABEEEE.

- Uses pydantic-settings for type-safe env parsing
- Provides strongly-typed access to all critical settings
- No secrets are hardcoded; everything flows from environment/.env
"""

from __future__ import annotations

from functools import lru_cache
from typing import Optional

from pydantic import AnyHttpUrl, Field, SecretStr
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Core
    env: str = Field("production", alias="ENV")
    log_level: str = Field("INFO", alias="LOG_LEVEL")
    secret_key: SecretStr = Field(..., alias="SECRET_KEY")
    encryption_key: SecretStr = Field(..., alias="ENCRYPTION_KEY")

    # Database
    postgres_db: str = Field("karyabee", alias="POSTGRES_DB")
    postgres_user: str = Field("karyabee", alias="POSTGRES_USER")
    postgres_password: SecretStr = Field(..., alias="POSTGRES_PASSWORD")
    postgres_host: str = Field("db", alias="POSTGRES_HOST")
    postgres_port: int = Field(5432, alias="POSTGRES_PORT")

    database_url: str = Field(
        default="",
        alias="DATABASE_URL",
        description="If set, overrides individual POSTGRES_* fields.",
    )

    db_pool_size: int = Field(10, alias="DB_POOL_SIZE")
    db_max_overflow: int = Field(20, alias="DB_MAX_OVERFLOW")
    sqlalchemy_echo: bool = Field(False, alias="SQLALCHEMY_ECHO")

    # Redis
    redis_url: str = Field("redis://redis:6379/0", alias="REDIS_URL")

    # RabbitMQ / Celery
    rabbitmq_user: str = Field("karyabee", alias="RABBITMQ_DEFAULT_USER")
    rabbitmq_pass: SecretStr = Field(
        SecretStr("karyabee"), alias="RABBITMQ_DEFAULT_PASS"
    )
    rabbitmq_host: str = Field("rabbitmq", alias="RABBITMQ_HOST")
    rabbitmq_port: int = Field(5672, alias="RABBITMQ_PORT")

    celery_broker_url: str = Field(
        "",
        alias="CELERY_BROKER_URL",
        description="If empty, will be composed from RabbitMQ settings.",
    )
    celery_result_backend: str = Field(
        "redis://redis:6379/1",
        alias="CELERY_RESULT_BACKEND",
    )

    # AI / Gemini
    gemini_api_key: SecretStr = Field(..., alias="GEMINI_API_KEY")
    gemini_model: str = Field("gemini-2.0-flash-exp", alias="GEMINI_MODEL")
    gemini_fallback_model: str = Field(
        "gemini-1.5-pro", alias="GEMINI_FALLBACK_MODEL"
    )
    gemini_max_rpm: int = Field(60, alias="GEMINI_MAX_RPM")

    # Application policy / limits
    apply_limit_per_cycle: int = Field(25, alias="APPLY_LIMIT_PER_CYCLE")
    max_applications_per_day: int = Field(
        100, alias="MAX_APPLICATIONS_PER_DAY"
    )
    match_score_threshold: int = Field(
        72, alias="MATCH_SCORE_THRESHOLD"
    )
    scrape_interval_hours: int = Field(
        4, alias="SCRAPE_INTERVAL_HOURS"
    )

    # Telegram
    telegram_bot_token: Optional[SecretStr] = Field(
        None, alias="TELEGRAM_BOT_TOKEN"
    )
    telegram_chat_id: Optional[str] = Field(
        None, alias="TELEGRAM_CHAT_ID"
    )

    # Email
    email_host: str = Field("smtp.protonmail.com", alias="EMAIL_HOST")
    email_port: int = Field(587, alias="EMAIL_PORT")
    email_use_tls: bool = Field(True, alias="EMAIL_USE_TLS")
    email_user: Optional[str] = Field(None, alias="EMAIL_USER")
    email_password: Optional[SecretStr] = Field(
        None, alias="EMAIL_PASSWORD"
    )
    email_from: Optional[str] = Field(None, alias="EMAIL_FROM")

    # 2Captcha / Proxy
    twocaptcha_api_key: Optional[SecretStr] = Field(
        None, alias="TWOCAPTCHA_API_KEY"
    )
    twocaptcha_max_daily_spend_usd: float = Field(
        10.0, alias="TWOCAPTCHA_MAX_DAILY_SPEND_USD"
    )

    proxy_url: Optional[str] = Field(None, alias="PROXY_URL")
    proxy_rotation: bool = Field(True, alias="PROXY_ROTATION")
    proxy_rotation_requests: int = Field(
        5, alias="PROXY_ROTATION_REQUESTS"
    )

    # Monitoring / Sentry / Grafana
    sentry_dsn: Optional[AnyHttpUrl] = Field(None, alias="SENTRY_DSN")
    prometheus_multiproc_dir: str = Field(
        "/tmp/prometheus", alias="PROMETHEUS_MULTIPROC_DIR"
    )
    grafana_admin_user: str = Field(
        "admin", alias="GRAFANA_ADMIN_USER"
    )
    grafana_admin_password: str = Field(
        "admin", alias="GRAFANA_ADMIN_PASSWORD"
    )

    # Tuning / Safety
    rate_limit_jobs_per_source_per_run: int = Field(
        200, alias="RATE_LIMIT_JOBS_PER_SOURCE_PER_RUN"
    )
    max_parallel_scrapers: int = Field(
        10, alias="MAX_PARALLEL_SCRAPERS"
    )
    max_parallel_applications: int = Field(
        5, alias="MAX_PARALLEL_APPLICATIONS"
    )
    max_captcha_solves_per_day: int = Field(
        20, alias="MAX_CAPTCHA_SOLVES_PER_DAY"
    )

    class Config:
        env_file = "env/.env"
        env_file_encoding = "utf-8"
        case_sensitive = True

    @property
    def sql_database_url(self) -> str:
        """Return effective DATABASE_URL (explicit or composed)."""
        if self.database_url:
            return self.database_url
        return (
            f"postgresql+psycopg2://{self.postgres_user}:"
            f"{self.postgres_password.get_secret_value()}"
            f"@{self.postgres_host}:{self.postgres_port}/{self.postgres_db}"
        )

    @property
    def effective_celery_broker_url(self) -> str:
        """Return broker URL for Celery."""
        if self.celery_broker_url:
            return self.celery_broker_url
        return (
            f"amqp://{self.rabbitmq_user}:"
            f"{self.rabbitmq_pass.get_secret_value()}"
            f"@{self.rabbitmq_host}:{self.rabbitmq_port}//"
        )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Singleton-style accessor."""
    return Settings()


# Eager singleton for simple imports
settings: Settings = get_settings()