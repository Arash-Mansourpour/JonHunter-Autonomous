"""
System health checks for KARYABEEEE.

Exposes a programmatic API used by:
- FastAPI /api/health endpoint
- Celery system_health_check task

Checks:
- PostgreSQL connectivity
- Redis connectivity
- Gemini client quota visibility
- Celery broker reachability (lightweight)
- Disk space
"""

from __future__ import annotations

import os
import shutil
from typing import Any, Dict

import redis
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError

from karyabee.config import settings
from karyabee.db import engine
from karyabee.logging_config import get_logger
from karyabee.metrics import set_gemini_quota_remaining

logger = get_logger(__name__)


def check_db() -> Dict[str, Any]:
    """Check database connectivity with a simple SELECT 1."""
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"status": "ok"}
    except SQLAlchemyError as exc:
        logger.error("health_db_error", error=str(exc))
        return {"status": "error", "error": str(exc)}


def check_redis() -> Dict[str, Any]:
    """Check Redis connectivity via PING."""
    try:
        client = redis.Redis.from_url(settings.redis_url)
        pong = client.ping()
        return {"status": "ok" if pong else "error"}
    except Exception as exc:  # pragma: no cover
        logger.error("health_redis_error", error=str(exc))
        return {"status": "error", "error": str(exc)}


def check_celery_broker() -> Dict[str, Any]:
    """
    Lightweight check of RabbitMQ/Celery broker.

    We avoid importing Celery here to keep this function side-effect free.
    """
    try:
        # Use broker URL from settings.effective_celery_broker_url
        url = settings.effective_celery_broker_url
        # Heuristic: if set, assume reachable; deep check is done via workers.
        if not url:
            return {"status": "error", "error": "broker_url_not_configured"}
        return {"status": "ok", "broker_url": url}
    except Exception as exc:  # pragma: no cover
        logger.error("health_celery_broker_error", error=str(exc))
        return {"status": "error", "error": str(exc)}


def check_disk(min_free_gb: float = 1.0) -> Dict[str, Any]:
    """Check that sufficient disk space is available."""
    try:
        usage = shutil.disk_usage("/")
        free_gb = usage.free / (1024**3)
        status = "ok" if free_gb >= min_free_gb else "error"
        if status != "ok":
            logger.error(
                "health_disk_low",
                free_gb=free_gb,
                min_free_gb=min_free_gb,
            )
        return {"status": status, "free_gb": round(free_gb, 2)}
    except Exception as exc:  # pragma: no cover
        logger.error("health_disk_error", error=str(exc))
        return {"status": "error", "error": str(exc)}


def check_gemini_quota() -> Dict[str, Any]:
    """
    Placeholder for Gemini quota monitoring.

    Since Gemini's public API may not expose direct quota,
    we track an estimated quota via metrics and configuration.
    """
    try:
        # Assume daily max is gemini_max_rpm * 60 * 24 as a soft bound.
        estimated_remaining = float(settings.gemini_max_rpm * 60 * 24)
        set_gemini_quota_remaining(estimated_remaining)
        return {
            "status": "ok",
            "estimated_remaining": estimated_remaining,
        }
    except Exception as exc:  # pragma: no cover
        logger.error("health_gemini_quota_error", error=str(exc))
        return {"status": "error", "error": str(exc)}


def get_system_health() -> Dict[str, Any]:
    """
    Aggregate all health checks into a single JSON-style dict.

    Returns:
        {
          "db": {...},
          "redis": {...},
          "celery_broker": {...},
          "disk": {...},
          "gemini": {...},
          "all_healthy": bool,
        }
    """
    db_status = check_db()
    redis_status = check_redis()
    broker_status = check_celery_broker()
    disk_status = check_disk()
    gemini_status = check_gemini_quota()

    components = [db_status, redis_status, broker_status, disk_status, gemini_status]
    all_healthy = all(c.get("status") == "ok" for c in components)

    health = {
        "db": db_status,
        "redis": redis_status,
        "celery_broker": broker_status,
        "disk": disk_status,
        "gemini": gemini_status,
        "all_healthy": all_healthy,
    }

    logger.info("system_health_snapshot", **health)
    return health