"""
Prometheus metrics exporter integration for KARYABEEEE.

This module exposes utilities to integrate Prometheus metrics with FastAPI
or any ASGI/WSGI app. It delegates metric definitions to karyabee.metrics.

Usage in FastAPI:
    from fastapi import FastAPI, Response
    from karyabee.monitoring.prometheus_exporter import metrics_endpoint

    app = FastAPI()

    @app.get("/metrics")
    def prometheus_metrics():
        data, content_type = metrics_endpoint()
        return Response(content=data, media_type=content_type)
"""

from __future__ import annotations

from typing import Tuple

from karyabee.logging_config import get_logger
from karyabee.metrics import export_metrics

logger = get_logger(__name__)


def metrics_endpoint() -> Tuple[bytes, str]:
    """
    Return Prometheus metrics payload and content type.

    Returns:
        (payload_bytes, content_type)
    """
    try:
        payload = export_metrics()
        return payload, "text/plain; version=0.0.4; charset=utf-8"
    except Exception as exc:  # pragma: no cover
        logger.error("prometheus_export_failed", error=str(exc))
        # Never break scraping; expose empty payload on failure.
        return b"", "text/plain; charset=utf-8"