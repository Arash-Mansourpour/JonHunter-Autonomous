"""
FastAPI application entrypoint for KARYABEEEE.

Features:
- JWT auth for admin endpoints
- CORS configuration
- Global exception handling
- Rate limiting (Redis-backed, lightweight)
- Mounts:
    - /api/health
    - /api/stats
    - /api/jobs
    - /api/applications
    - /api/analytics
    - /api/admin/*
    - /metrics (Prometheus)
"""

from __future__ import annotations

import datetime as dt
from typing import Any, Dict, Optional

import jwt
from fastapi import Depends, FastAPI, HTTPException, Request, Response, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from karyabee.config import settings
from karyabee.db import get_db_session
from karyabee.logging_config import get_logger
from karyabee.metrics import export_metrics
from karyabee.monitoring.health import get_system_health
from karyabee.utils.rate_limiter import RateLimitConfig, rate_limiter

from .routes import analytics as analytics_routes
from .routes import applications as applications_routes
from .routes import jobs as jobs_routes

logger = get_logger(__name__)
security = HTTPBearer(auto_error=False)

# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------


def _create_admin_token() -> str:
    """
    Utility for ops/tests to mint a short-lived admin JWT.

    Not exposed as public API.
    """
    now = dt.datetime.utcnow()
    payload = {
        "sub": "admin",
        "role": "admin",
        "iat": int(now.timestamp()),
        "exp": int((now + dt.timedelta(hours=6)).timestamp()),
    }
    return jwt.encode(
        payload,
        settings.secret_key.get_secret_value(),
        algorithm="HS256",
    )


def get_current_admin(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> Dict[str, Any]:
    """
    Dependency for admin-protected endpoints.

    Expects:
        Authorization: Bearer <JWT>
    """
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing credentials",
        )
    token = credentials.credentials
    try:
        data = jwt.decode(
            token,
            settings.secret_key.get_secret_value(),
            algorithms=["HS256"],
        )
        if data.get("role") != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient privileges",
            )
        return data
    except jwt.PyJWTError as exc:  # type: ignore[attr-defined]
        logger.error("admin_jwt_invalid", error=str(exc))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
        ) from exc


# ---------------------------------------------------------------------------
# Rate limiting dependency
# ---------------------------------------------------------------------------


def rate_limit_dependency(request: Request) -> None:
    """
    Simple per-IP, per-path rate limit.

    Uses Redis-backed token bucket; fail-open if Redis unavailable.
    """
    client_host = request.client.host if request.client else "unknown"
    key = f"api:{request.url.path}:{client_host}"
    # Example: 60 req/min per IP per path
    cfg = RateLimitConfig(capacity=60, refill_rate_per_sec=1.0)
    if not rate_limiter.allow(key, cfg):
        logger.warn("rate_limit_exceeded", ip=client_host, path=request.url.path)
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too Many Requests",
        )


# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------


app = FastAPI(
    title="KARYABEEEE API",
    version="1.0.0",
    docs_url="/api/docs",
    openapi_url="/api/openapi.json",
    default_response_class=JSONResponse,
)


# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # can be restricted via env in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Exception handlers
# ---------------------------------------------------------------------------


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(
    request: Request,
    exc: RequestValidationError,
) -> JSONResponse:
    logger.error(
        "request_validation_error",
        path=str(request.url),
        errors=exc.errors(),
    )
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": exc.errors()},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(
    request: Request,
    exc: Exception,
) -> JSONResponse:
    logger.error(
        "unhandled_exception",
        path=str(request.url),
        error=str(exc),
    )
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Internal server error"},
    )


# ---------------------------------------------------------------------------
# Core endpoints
# ---------------------------------------------------------------------------


@app.get("/api/health", dependencies=[Depends(rate_limit_dependency)])
def api_health() -> Dict[str, Any]:
    """Aggregated system health."""
    return get_system_health()


@app.get("/api/metrics")
def api_metrics() -> Response:
    """Prometheus metrics endpoint."""
    payload = export_metrics()
    return PlainTextResponse(
        content=payload.decode("utf-8"),
        media_type="text/plain; version=0.0.4; charset=utf-8",
    )


@app.get("/api/stats", dependencies=[Depends(rate_limit_dependency)])
def api_stats(db=Depends(get_db_session)) -> Dict[str, Any]:
    """
    High-level statistics for dashboards and Telegram /stats.

    Returns:
        Aggregated counters over recent period.
    """
    from karyabee.models import Application, Job

    # Today window
    today = dt.date.today()
    start = dt.datetime.combine(today, dt.time.min)
    end = dt.datetime.combine(today, dt.time.max)

    jobs_scraped_today = (
        db.query(Job).filter(Job.created_at.between(start, end)).count()
    )
    applications_sent_today = (
        db.query(Application)
        .filter(Application.applied_at.between(start, end))
        .count()
    )
    responses_today = (
        db.query(Application)
        .filter(
            Application.response_received.is_(True),
            Application.response_date.between(start, end),
        )
        .count()
    )
    interviews_today = (
        db.query(Application)
        .filter(
            Application.interview_scheduled.is_(True),
            Application.interview_date.between(start, end),
        )
        .count()
    )
    offers_today = (
        db.query(Application)
        .filter(Application.outcome == "offer", Application.response_date.between(start, end))
        .count()
    )
    total_jobs = db.query(Job).count()
    total_applications = db.query(Application).count()
    total_offers = (
        db.query(Application).filter(Application.outcome == "offer").count()
    )

    def safe_rate(num: int, denom: int) -> float:
        return float(num) / float(denom) if denom > 0 else 0.0

    return {
        "jobs_scraped_today": jobs_scraped_today,
        "applications_sent_today": applications_sent_today,
        "responses_today": responses_today,
        "interviews_today": interviews_today,
        "offers_today": offers_today,
        "total_jobs": total_jobs,
        "total_applications": total_applications,
        "total_offers": total_offers,
        "response_rate": safe_rate(responses_today, applications_sent_today),
        "interview_rate": safe_rate(interviews_today, applications_sent_today),
        "offer_rate": safe_rate(offers_today, applications_sent_today),
    }


# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------


app.include_router(
    jobs_routes.router,
    prefix="/api/jobs",
    tags=["jobs"],
    dependencies=[Depends(rate_limit_dependency)],
)
app.include_router(
    applications_routes.router,
    prefix="/api/applications",
    tags=["applications"],
    dependencies=[Depends(rate_limit_dependency)],
)
app.include_router(
    analytics_routes.router,
    prefix="/api/analytics",
    tags=["analytics"],
    dependencies=[Depends(rate_limit_dependency)],
)


# ---------------------------------------------------------------------------
# Admin endpoints
# ---------------------------------------------------------------------------


@app.post(
    "/api/admin/pause",
    dependencies=[Depends(get_current_admin)],
)
def admin_pause() -> Dict[str, Any]:
    """
    Pause automation for 24 hours.

    Implemented via a shared key in Redis.
    """
    from karyabee.utils.cache import RedisCache

    cache = RedisCache(prefix="karyabee:admin:")
    pause_until = (dt.datetime.utcnow() + dt.timedelta(hours=24)).isoformat()
    cache.set("paused_until", pause_until, ttl_seconds=24 * 3600)
    logger.info("system_paused_until", pause_until=pause_until)
    return {"status": "ok", "paused_until": pause_until}


@app.post(
    "/api/admin/resume",
    dependencies=[Depends(get_current_admin)],
)
def admin_resume() -> Dict[str, Any]:
    """Resume automation immediately."""
    from karyabee.utils.cache import RedisCache

    cache = RedisCache(prefix="karyabee:admin:")
    cache.delete("paused_until")
    logger.info("system_resumed")
    return {"status": "ok"}


@app.on_event("startup")
def on_startup() -> None:
    """Log startup event."""
    logger.info("fastapi_app_started")


@app.on_event("shutdown")
def on_shutdown() -> None:
    """Log shutdown event."""
    logger.info("fastapi_app_stopped")