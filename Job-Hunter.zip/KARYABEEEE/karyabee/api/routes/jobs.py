"""
Jobs API routes for KARYABEEEE.

Endpoints:
- GET /api/jobs
    - Query params:
        - status: filter by job status
        - match_score_min: float
        - source: platform/source
        - page, page_size
        - sort_by: match_score|posted_date|created_at
        - sort_order: asc|desc
- GET /api/jobs/{job_id}
"""

from __future__ import annotations

import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import and_, desc
from sqlalchemy.orm import Session

from karyabee.db import get_db_session
from karyabee.logging_config import get_logger
from karyabee.models import Job
from karyabee.schemas import JobListResponse, JobResponse

router = APIRouter()
logger = get_logger(__name__)


def _apply_filters(
    query,
    status_filter: Optional[str],
    match_score_min: Optional[float],
    source: Optional[str],
):
    conditions = []
    if status_filter:
        conditions.append(Job.status == status_filter)
    if match_score_min is not None:
        conditions.append((Job.match_score is not None) & (Job.match_score >= match_score_min))
    if source:
        conditions.append(Job.source == source)
    if conditions:
        query = query.filter(and_(*conditions))
    return query


def _apply_sorting(query, sort_by: Optional[str], sort_order: str):
    if not sort_by:
        return query.order_by(desc(Job.created_at))
    mapping = {
        "match_score": Job.match_score,
        "posted_date": Job.posted_date,
        "created_at": Job.created_at,
    }
    col = mapping.get(sort_by, Job.created_at)
    if sort_order == "asc":
        return query.order_by(col.asc().nullslast())
    return query.order_by(col.desc().nullslast())


@router.get("", response_model=JobListResponse)
def list_jobs(
    status_filter: Optional[str] = Query(None, alias="status"),
    match_score_min: Optional[float] = Query(None, ge=0, le=100),
    source: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
    sort_by: Optional[str] = Query(
        None,
        pattern="^(match_score|posted_date|created_at)$",
    ),
    sort_order: str = Query("desc", pattern="^(asc|desc)$"),
    db: Session = Depends(get_db_session),
) -> JobListResponse:
    """
    List jobs with filtering, sorting, and pagination.
    """
    base_query = db.query(Job)
    base_query = _apply_filters(base_query, status_filter, match_score_min, source)
    total = base_query.count()

    query = _apply_sorting(base_query, sort_by, sort_order)
    items: List[Job] = (
        query.offset((page - 1) * page_size).limit(page_size).all()
    )

    logger.info(
        "api_jobs_list",
        total=total,
        page=page,
        page_size=page_size,
    )

    return JobListResponse(
        total=total,
        page=page,
        page_size=page_size,
        items=[JobResponse.model_validate(j) for j in items],
    )


@router.get("/{job_id}", response_model=JobResponse)
def get_job(
    job_id: uuid.UUID,
    db: Session = Depends(get_db_session),
) -> JobResponse:
    """
    Retrieve a single job by ID.
    """
    job: Optional[Job] = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found",
        )
    logger.info("api_job_get", job_id=str(job_id))
    return JobResponse.model_validate(job)