"""
Applications API routes for KARYABEEEE.

Endpoints:
- GET /api/applications
    - Filters:
        - outcome
        - date_from, date_to
        - page, page_size
- GET /api/applications/{app_id}
    - Single application details
- PATCH /api/applications/{app_id}
    - Update outcome / notes / response flags
"""

from __future__ import annotations

import uuid
from datetime import date, datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import and_
from sqlalchemy.orm import Session

from karyabee.db import get_db_session
from karyabee.logging_config import get_logger
from karyabee.models import Application
from karyabee.schemas import (
    ApplicationListResponse,
    ApplicationResponse,
    ApplicationUpdate,
)

router = APIRouter()
logger = get_logger(__name__)


@router.get("", response_model=ApplicationListResponse)
def list_applications(
    outcome: Optional[str] = Query(None),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
    db: Session = Depends(get_db_session),
) -> ApplicationListResponse:
    """
    List applications with optional filters and pagination.
    """
    query = db.query(Application)

    conditions = []
    if outcome:
        conditions.append(Application.outcome == outcome)
    if date_from:
        conditions.append(Application.applied_at >= datetime.combine(date_from, datetime.min.time()))
    if date_to:
        conditions.append(Application.applied_at <= datetime.combine(date_to, datetime.max.time()))
    if conditions:
        query = query.filter(and_(*conditions))

    total = query.count()
    apps: List[Application] = (
        query.order_by(Application.applied_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    logger.info(
        "api_applications_list",
        total=total,
        page=page,
        page_size=page_size,
    )

    return ApplicationListResponse(
        total=total,
        page=page,
        page_size=page_size,
        items=[ApplicationResponse.model_validate(a) for a in apps],
    )


@router.get("/{app_id}", response_model=ApplicationResponse)
def get_application(
    app_id: uuid.UUID,
    db: Session = Depends(get_db_session),
) -> ApplicationResponse:
    """
    Retrieve application details by ID.
    """
    app: Optional[Application] = (
        db.query(Application).filter(Application.id == app_id).first()
    )
    if not app:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Application not found",
        )
    logger.info("api_application_get", application_id=str(app_id))
    return ApplicationResponse.model_validate(app)


@router.patch("/{app_id}", response_model=ApplicationResponse)
def update_application(
    app_id: uuid.UUID,
    payload: ApplicationUpdate,
    db: Session = Depends(get_db_session),
) -> ApplicationResponse:
    """
    Update mutable application fields (response/outcome/notes).
    """
    app: Optional[Application] = (
        db.query(Application).filter(Application.id == app_id).first()
    )
    if not app:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Application not found",
        )

    data = payload.model_dump(exclude_unset=True)
    for field, value in data.items():
        setattr(app, field, value)

    db.add(app)
    db.commit()
    db.refresh(app)

    logger.info(
        "api_application_updated",
        application_id=str(app_id),
        changes=list(data.keys()),
    )

    return ApplicationResponse.model_validate(app)