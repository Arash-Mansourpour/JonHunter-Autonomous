"""
Analytics API routes for KARYABEEEE.

Endpoints:
- GET /api/analytics
    - Query params:
        - period: daily|weekly|monthly
        - start_date, end_date (optional)
- GET /api/analytics/raw
    - Return raw Analytics rows for given range
"""

from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import and_, func
from sqlalchemy.orm import Session

from karyabee.db import get_db_session
from karyabee.logging_config import get_logger
from karyabee.models import Analytics
from karyabee.schemas import AnalyticsListResponse, AnalyticsRange, AnalyticsResponse

router = APIRouter()
logger = get_logger(__name__)


def _parse_dates(
    start_date: Optional[date],
    end_date: Optional[date],
    default_days: int,
) -> (date, date):
    today = date.today()
    if not end_date:
        end_date = today
    if not start_date:
        start_date = end_date - timedelta(days=default_days)
    if start_date > end_date:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="start_date cannot be after end_date",
        )
    return start_date, end_date


@router.get("", response_model=dict)
def get_analytics(
    period: str = Query(
        "daily",
        pattern="^(daily|weekly|monthly)$",
        description="Aggregation period",
    ),
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None),
    db: Session = Depends(get_db_session),
) -> dict:
    """
    Aggregated analytics over a time range.

    For now this returns:
    - totals (jobs_scraped, applications_sent, responses_received, interviews_scheduled, offers_received)
    - rates (response_rate, interview_rate, offer_rate)
    - by_period buckets depending on period
    """
    start_date, end_date = _parse_dates(start_date, end_date, default_days=7)

    q = db.query(Analytics).filter(
        and_(
            Analytics.date >= start_date,
            Analytics.date <= end_date,
        )
    )
    rows: List[Analytics] = q.order_by(Analytics.date.asc()).all()
    if not rows:
        return {
            "period": period,
            "start_date": start_date,
            "end_date": end_date,
            "totals": {},
            "buckets": [],
        }

    def accum(field: str) -> int:
        return int(sum(getattr(r, field) or 0 for r in rows))

    totals = {
        "jobs_scraped": accum("jobs_scraped"),
        "applications_sent": accum("applications_sent"),
        "responses_received": accum("responses_received"),
        "interviews_scheduled": accum("interviews_scheduled"),
        "offers_received": accum("offers_received"),
    }

    def safe_rate(num: int, denom: int) -> float:
        return float(num) / float(denom) if denom > 0 else 0.0

    totals["response_rate"] = safe_rate(
        totals["responses_received"], totals["applications_sent"]
    )
    totals["interview_rate"] = safe_rate(
        totals["interviews_scheduled"], totals["applications_sent"]
    )
    totals["offer_rate"] = safe_rate(
        totals["offers_received"], totals["applications_sent"]
    )

    # Bucketing
    buckets = []
    if period == "daily":
        for r in rows:
            buckets.append(
                {
                    "date": r.date,
                    "jobs_scraped": r.jobs_scraped,
                    "applications_sent": r.applications_sent,
                    "responses_received": r.responses_received,
                    "offers_received": r.offers_received,
                }
            )
    elif period == "weekly":
        # Group by ISO week
        week_map = {}
        for r in rows:
            year, week, _ = r.date.isocalendar()
            key = f"{year}-W{week}"
            w = week_map.setdefault(
                key,
                {
                    "label": key,
                    "jobs_scraped": 0,
                    "applications_sent": 0,
                    "responses_received": 0,
                    "offers_received": 0,
                },
            )
            w["jobs_scraped"] += r.jobs_scraped or 0
            w["applications_sent"] += r.applications_sent or 0
            w["responses_received"] += r.responses_received or 0
            w["offers_received"] += r.offers_received or 0
        buckets = list(week_map.values())
    else:  # monthly
        month_map = {}
        for r in rows:
            key = f"{r.date.year}-{r.date.month:02d}"
            m = month_map.setdefault(
                key,
                {
                    "label": key,
                    "jobs_scraped": 0,
                    "applications_sent": 0,
                    "responses_received": 0,
                    "offers_received": 0,
                },
            )
            m["jobs_scraped"] += r.jobs_scraped or 0
            m["applications_sent"] += r.applications_sent or 0
            m["responses_received"] += r.responses_received or 0
            m["offers_received"] += r.offers_received or 0
        buckets = list(month_map.values())

    logger.info(
        "api_analytics_get",
        period=period,
        start_date=str(start_date),
        end_date=str(end_date),
    )

    return {
        "period": period,
        "start_date": start_date,
        "end_date": end_date,
        "totals": totals,
        "buckets": buckets,
    }


@router.get("/raw", response_model=AnalyticsListResponse)
def get_raw_analytics(
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None),
    db: Session = Depends(get_db_session),
) -> AnalyticsListResponse:
    """
    Return raw Analytics rows for a date range.
    """
    start_date, end_date = _parse_dates(start_date, end_date, default_days=30)

    rows: List[Analytics] = (
        db.query(Analytics)
        .filter(
            and_(
                Analytics.date >= start_date,
                Analytics.date <= end_date,
            )
        )
        .order_by(Analytics.date.asc())
        .all()
    )

    return AnalyticsListResponse(
        items=[AnalyticsResponse.model_validate(r) for r in rows],
    )