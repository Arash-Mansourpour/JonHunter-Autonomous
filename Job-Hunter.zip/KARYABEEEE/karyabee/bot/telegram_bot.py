"""
Telegram control and monitoring bot for KARYABEEEE.

Implements commands:
- /start: Welcome + system status
- /stats: Today's metrics
- /pipeline: Summary of pending/interviewing/offers
- /best: Top 5 matches with inline [Apply] [Skip] buttons
- /apply {job_id}: Trigger manual apply for a job
- /pause: Pause automation for 24h
- /resume: Resume automation
- /report daily|weekly: Send detailed report
- /settings: Show current thresholds and allow adjustment (basic)

Notes:
- Uses polling mode by default for simplicity; webhook can be wired externally.
- Reads config via settings and uses same Redis-based pause flag as API.
- Uses python-telegram-bot v21+ (async API).
"""

from __future__ import annotations

import asyncio
import datetime as dt
import uuid
from typing import Optional

from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Update,
)
from telegram.constants import ParseMode
from telegram.ext import (
    AIORateLimiter,
    Application,
    ApplicationBuilder,
    CallbackContext,
    CallbackQueryHandler,
    CommandHandler,
)

from karyabee.config import settings
from karyabee.db import SessionLocal
from karyabee.logging_config import get_logger
from karyabee.models import Application as ApplicationModel
from karyabee.models import Job
from karyabee.notifications.telegram_notifier import telegram_notifier
from karyabee.utils.cache import RedisCache

logger = get_logger(__name__)

ADMIN_CACHE = RedisCache(prefix="karyabee:admin:")
BOT_STATE_CACHE = RedisCache(prefix="karyabee:bot:")


def _is_paused() -> bool:
    """Check if system is currently paused."""
    paused_until = ADMIN_CACHE.get("paused_until")
    if not paused_until:
        return False
    try:
        ts = dt.datetime.fromisoformat(paused_until)
        if dt.datetime.utcnow() < ts:
            return True
        # Expired, clear
        ADMIN_CACHE.delete("paused_until")
        return False
    except Exception:
        return False


def _pause_24h() -> str:
    """Pause for 24h and return ISO timestamp."""
    until = (dt.datetime.utcnow() + dt.timedelta(hours=24)).isoformat()
    ADMIN_CACHE.set("paused_until", until, ttl_seconds=24 * 3600)
    return until


def _resume_now() -> None:
    """Clear pause flag."""
    ADMIN_CACHE.delete("paused_until")


async def cmd_start(update: Update, context: CallbackContext) -> None:
    """Handle /start."""
    paused = _is_paused()
    health = "⏸ Paused" if paused else "✅ Active"
    msg = (
        "🤖 KARYABEEEE Bot Online\n"
        f"Status: {health}\n"
        "I monitor and optimize Arash's autonomous job applications.\n"
        "Commands:\n"
        "/stats - Today's metrics\n"
        "/pipeline - Pipeline summary\n"
        "/best - Top 5 matches\n"
        "/apply <job_id> - Apply manually\n"
        "/pause - Pause automation 24h\n"
        "/resume - Resume automation\n"
        "/report daily|weekly - Detailed reports\n"
        "/settings - View current thresholds"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)


async def cmd_stats(update: Update, context: CallbackContext) -> None:
    """Handle /stats."""
    from karyabee.api.main import api_stats  # reuse logic

    # Use a DB session directly
    with SessionLocal() as db:
        stats = api_stats(db=db)  # type: ignore[arg-type]
    msg = (
        "📊 *Today*\n"
        f"Jobs scraped: `{stats['jobs_scraped_today']}`\n"
        f"Applications sent: `{stats['applications_sent_today']}`\n"
        f"Responses: `{stats['responses_today']}`\n"
        f"Interviews: `{stats['interviews_today']}`\n"
        f"Offers: `{stats['offers_today']}`\n"
        f"Total applications: `{stats['total_applications']}`\n"
        f"Response rate: `{stats['response_rate']:.2%}`"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)


async def cmd_pipeline(update: Update, context: CallbackContext) -> None:
    """Handle /pipeline: pending/interview/offer counts."""
    with SessionLocal() as db:
        pending = db.query(ApplicationModel).filter(
            ApplicationModel.outcome == "pending"
        ).count()
        interviewing = db.query(ApplicationModel).filter(
            ApplicationModel.outcome == "interview"
        ).count()
        offers = db.query(ApplicationModel).filter(
            ApplicationModel.outcome == "offer"
        ).count()

    msg = (
        "📂 *Pipeline*\n"
        f"Pending: `{pending}`\n"
        f"Interviewing: `{interviewing}`\n"
        f"Offers: `{offers}`"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)


async def cmd_best(update: Update, context: CallbackContext) -> None:
    """Handle /best: show top 5 matches."""
    with SessionLocal() as db:
        jobs = (
            db.query(Job)
            .filter(Job.match_score.isnot(None))
            .order_by(Job.match_score.desc())
            .limit(5)
            .all()
        )
    if not jobs:
        await update.message.reply_text("No scored jobs available yet.")
        return

    for job in jobs:
        keyboard = InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "✅ Apply", callback_data=f"apply:{job.id}"
                    ),
                    InlineKeyboardButton(
                        "⏭ Skip", callback_data=f"skip:{job.id}"
                    ),
                ]
            ]
        )
        text = (
            f"*{job.title}* at *{job.company}*\n"
            f"Score: `{job.match_score}` | Source: `{job.source}`\n"
            f"Location: `{job.location or 'N/A'}`"
        )
        await update.message.reply_text(
            text,
            reply_markup=keyboard,
            parse_mode=ParseMode.MARKDOWN,
        )


async def cmd_apply(update: Update, context: CallbackContext) -> None:
    """Handle /apply {job_id} manual trigger."""
    if not context.args:
        await update.message.reply_text("Usage: /apply <job_id>")
        return
    try:
        job_id = uuid.UUID(context.args[0])
    except ValueError:
        await update.message.reply_text("Invalid job_id format.")
        return

    # Enqueue Celery auto_apply_top_matches or a dedicated single-job task
    from karyabee.orchestration.tasks import auto_apply_top_matches

    # Current implementation uses global auto_apply; for a single job,
    # we can rely on match/apply logic to pick it up on next run.
    auto_apply_top_matches.delay()  # type: ignore[attr-defined]
    await update.message.reply_text(
        f"Queued apply workflow. If eligible, job `{job_id}` will be applied.",
        parse_mode=ParseMode.MARKDOWN,
    )


async def cmd_pause(update: Update, context: CallbackContext) -> None:
    """Handle /pause: pause system for 24h."""
    until = _pause_24h()
    await update.message.reply_text(
        f"⏸ Automation paused until `{until}` (UTC).",
        parse_mode=ParseMode.MARKDOWN,
    )


async def cmd_resume(update: Update, context: CallbackContext) -> None:
    """Handle /resume: resume immediately."""
    _resume_now()
    await update.message.reply_text(
        "▶️ Automation resumed.",
        parse_mode=ParseMode.MARKDOWN,
    )


async def cmd_report(update: Update, context: CallbackContext) -> None:
    """Handle /report daily|weekly."""
    arg = (context.args[0].lower() if context.args else "daily")
    with SessionLocal() as db:
        if arg == "weekly":
            from karyabee.analytics.report_generator import build_weekly_summary

            end = dt.date.today()
            start = end - dt.timedelta(days=7)
            html, summary = build_weekly_summary(db, start, end)
            await update.message.reply_text(
                f"📈 Weekly report:\n{summary}",
                parse_mode=ParseMode.MARKDOWN,
            )
        else:
            from karyabee.analytics.report_generator import build_daily_report

            today = dt.date.today()
            html, summary = build_daily_report(db, today)
            await update.message.reply_text(
                f"📊 Daily report:\n{summary}",
                parse_mode=ParseMode.MARKDOWN,
            )


async def cmd_settings(update: Update, context: CallbackContext) -> None:
    """Show current tunable settings."""
    msg = (
        "⚙️ *Current Settings*\n"
        f"Match threshold: `{settings.match_score_threshold}`\n"
        f"Apply limit/cycle: `{settings.apply_limit_per_cycle}`\n"
        f"Max applications/day: `{settings.max_applications_per_day}`\n"
    )
    await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN)


async def on_callback(update: Update, context: CallbackContext) -> None:
    """Handle inline button callbacks for /best."""
    query = update.callback_query
    await query.answer()
    data = query.data or ""
    if data.startswith("apply:"):
        job_id = data.split(":", 1)[1]
        await query.edit_message_text(
            f"Queued apply workflow for job `{job_id}`.",
            parse_mode=ParseMode.MARKDOWN,
        )
        from karyabee.orchestration.tasks import auto_apply_top_matches

        auto_apply_top_matches.delay()  # type: ignore[attr-defined]
    elif data.startswith("skip:"):
        job_id = data.split(":", 1)[1]
        await query.edit_message_text(
            f"Skipped job `{job_id}`.",
            parse_mode=ParseMode.MARKDOWN,
        )


def build_application() -> Optional[Application]:
    """
    Build telegram Application if token/chat_id configured.

    Returns:
        Application instance or None if disabled.
    """
    if not (settings.telegram_bot_token and settings.telegram_chat_id):
        logger.warn("telegram_bot_not_configured")
        return None

    app = (
        ApplicationBuilder()
        .token(settings.telegram_bot_token.get_secret_value())
        .rate_limiter(AIORateLimiter())
        .build()
    )

    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CommandHandler("pipeline", cmd_pipeline))
    app.add_handler(CommandHandler("best", cmd_best))
    app.add_handler(CommandHandler("apply", cmd_apply))
    app.add_handler(CommandHandler("pause", cmd_pause))
    app.add_handler(CommandHandler("resume", cmd_resume))
    app.add_handler(CommandHandler("report", cmd_report))
    app.add_handler(CommandHandler("settings", cmd_settings))
    app.add_handler(CallbackQueryHandler(on_callback))

    return app


async def run_bot_polling() -> None:
    """
    Run Telegram bot in long-polling mode.

    Intended for standalone execution:
        python -m karyabee.bot.telegram_bot
    """
    app = build_application()
    if not app:
        return
    logger.info("telegram_bot_starting_polling")
    await app.run_polling()


if __name__ == "__main__":
    asyncio.run(run_bot_polling())